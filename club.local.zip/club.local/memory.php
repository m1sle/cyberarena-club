<?php
require_once __DIR__ . '/bootstrap.php';
require_login('login.php');
refresh_user_session($conn, current_user()['id']);

$pageTitle = 'Корзина | CyberArena';
$bodyClass = 'memory-page';
$current_user = current_user();
$today = date('Y-m-d');
$edit_id = raw_clean($_GET['edit'] ?? '');

function format_date_ru(string $date): string
{
    if ($date === '' || $date === '0000-00-00') {
        return '';
    }

    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d ? $d->format('d.m.Y') : htmlspecialchars($date);
}

function format_service_name(string $service_name): string
{
    $parts = array_map('trim', explode('/', $service_name));
    $safe_parts = array_map('htmlspecialchars', $parts);
    return implode('<br>', $safe_parts);
}

function is_future_or_today_booking(string $date, string $today): bool
{
    return is_valid_date($date) && $date >= $today;
}

function resolve_computer_id(mysqli $conn, string $serviceName): ?int
{
    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT c.id
        FROM computers c
        JOIN zones z ON c.zone_id = z.id
        JOIN tariffs t ON c.tariff_id = t.id
        WHERE CONCAT(c.pc_name, ' / ', z.zone_name, ' / ', t.tariff_name) = ?
        LIMIT 1
        "
    );

    if (!$stmt) {
        return null;
    }

    mysqli_stmt_bind_param($stmt, 's', $serviceName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    return $row ? (int) $row['id'] : null;
}

function insert_booking_from_cart_item(mysqli $conn, int $userId, array $cartItem, string $today): void
{
    $bookingDate = (string) ($cartItem['booking_date'] ?? '');
    $hours = (int) ($cartItem['hours'] ?? 0);
    $serviceName = (string) ($cartItem['service_name'] ?? '');

    if ($userId <= 0 || $hours <= 0 || !is_future_or_today_booking($bookingDate, $today)) {
        throw new RuntimeException('В корзине есть позиции с некорректной или прошедшей датой.');
    }

    $computerId = resolve_computer_id($conn, $serviceName);
    if (!$computerId) {
        throw new RuntimeException('Не удалось найти одно из выбранных игровых мест в базе.');
    }

    $stmtInsert = mysqli_prepare($conn, 'INSERT INTO bookings (user_id, computer_id, booking_date, hours) VALUES (?, ?, ?, ?)');
    if (!$stmtInsert) {
        throw new RuntimeException('Не удалось подготовить запись бронирования.');
    }

    mysqli_stmt_bind_param($stmtInsert, 'iisi', $userId, $computerId, $bookingDate, $hours);
    mysqli_stmt_execute($stmtInsert);
    mysqli_stmt_close($stmtInsert);
}

$service_options = [];
$service_prices = [];
$service_options_query = "
SELECT
    c.pc_name,
    z.zone_name,
    t.tariff_name,
    t.price_per_hour
FROM computers c
JOIN zones z ON c.zone_id = z.id
JOIN tariffs t ON c.tariff_id = t.id
ORDER BY c.pc_name ASC
";
$service_options_result = mysqli_query($conn, $service_options_query);
if ($service_options_result && mysqli_num_rows($service_options_result) > 0) {
    while ($service = mysqli_fetch_assoc($service_options_result)) {
        $option_value = $service['pc_name'] . ' / ' . $service['zone_name'] . ' / ' . $service['tariff_name'];
        $option_text_full = $service['pc_name'] . ' — ' . $service['zone_name'] . ' — ' . $service['tariff_name'] . ' (' . $service['price_per_hour'] . ' руб./час)';
        $option_text_short = $service['pc_name'] . ' — ' . $service['zone_name'];

        $service_options[] = [
            'value' => $option_value,
            'text_full' => $option_text_full,
            'text_short' => $option_text_short,
        ];
        $service_prices[$option_value] = (float) $service['price_per_hour'];
    }
}

if (isset($_POST['add'])) {
    $service_name = raw_clean($_POST['service_name'] ?? '');
    $booking_date = raw_clean($_POST['booking_date'] ?? '');
    $hours = (int) ($_POST['hours'] ?? 0);

    if ($service_name !== '' && $hours > 0 && is_future_or_today_booking($booking_date, $today)) {
        add_cart_item([
            'client_name' => $current_user['full_name'],
            'phone' => $current_user['phone'],
            'service_name' => $service_name,
            'booking_date' => $booking_date,
            'hours' => $hours,
        ]);
        set_flash('success', 'Игровое место добавлено в корзину.');
    } else {
        set_flash('error', 'Не удалось добавить позицию в корзину. Проверьте дату и количество часов.');
    }

    header('Location: memory.php');
    exit;
}

if (isset($_POST['save_update'])) {
    $cart_id = raw_clean($_POST['cart_id'] ?? '');
    $service_name = raw_clean($_POST['service_name'] ?? '');
    $booking_date = raw_clean($_POST['booking_date'] ?? '');
    $hours = (int) ($_POST['hours'] ?? 0);

    if ($cart_id !== '' && $service_name !== '' && $hours > 0 && is_future_or_today_booking($booking_date, $today)) {
        update_cart_item($cart_id, [
            'service_name' => $service_name,
            'booking_date' => $booking_date,
            'hours' => $hours,
        ]);
        set_flash('success', 'Позиция корзины обновлена.');
    } else {
        set_flash('error', 'Не удалось сохранить изменения. Прошедшие даты выбирать нельзя.');
    }

    header('Location: memory.php');
    exit;
}

if (isset($_GET['delete'])) {
    $cart_id = raw_clean($_GET['delete']);
    if ($cart_id !== '') {
        remove_cart_item($cart_id);
        set_flash('info', 'Позиция удалена из корзины.');
    }
    header('Location: memory.php');
    exit;
}

if (isset($_POST['delete_all'])) {
    clear_cart_items();
    set_flash('info', 'Корзина полностью очищена.');
    header('Location: memory.php');
    exit;
}

if (isset($_POST['confirm'])) {
    $cart_id = raw_clean($_POST['cart_id'] ?? '');
    $cart_item = get_cart_item($cart_id);

    if ($cart_item) {
        try {
            insert_booking_from_cart_item($conn, (int) $current_user['id'], $cart_item, $today);
            remove_cart_item($cart_id);
            set_flash('success', 'Бронирование оформлено.');
        } catch (Throwable $e) {
            set_flash('error', $e->getMessage());
            header('Location: memory.php');
            exit;
        }
    }

    header('Location: bookings.php');
    exit;
}

if (isset($_POST['confirm_all'])) {
    $cart_items_to_confirm = get_cart_items();

    if (empty($cart_items_to_confirm)) {
        set_flash('info', 'Корзина уже пуста.');
        header('Location: memory.php');
        exit;
    }

    mysqli_begin_transaction($conn);

    try {
        foreach ($cart_items_to_confirm as $cart_item) {
            insert_booking_from_cart_item($conn, (int) $current_user['id'], $cart_item, $today);
        }

        mysqli_commit($conn);
        clear_cart_items();
        set_flash('success', 'Все позиции из корзины успешно оформлены.');
        header('Location: bookings.php');
        exit;
    } catch (Throwable $e) {
        mysqli_rollback($conn);
        set_flash('error', $e->getMessage());
        header('Location: memory.php');
        exit;
    }
}

$cart_items = get_cart_items();
$cartTotalHours = 0;
$cartTotalPrice = 0.0;
foreach ($cart_items as $cartItem) {
    $hours = (int) ($cartItem['hours'] ?? 0);
    $service = (string) ($cartItem['service_name'] ?? '');
    $pricePerHour = $service_prices[$service] ?? 0;
    $cartTotalHours += $hours;
    $cartTotalPrice += $pricePerHour * $hours;
}

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container">
        <div class="booking-card">
            <h1>Корзина бронирований</h1>
            <p class="note">
                Добавляйте в корзину одно или несколько игровых мест, а затем оформляйте их в свои бронирования.
                Незавершённые позиции можно редактировать или удалить до подтверждения.
            </p>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="filter-card">
            <h2>Добавить место в корзину</h2>

            <form method="post" class="basket-add-form">
                <div>
                    <label for="client_name">Ваше имя</label>
                    <input type="text" id="client_name" value="<?= htmlspecialchars($current_user['full_name']) ?>" readonly>
                </div>

                <div>
                    <label for="phone">Телефон</label>
                    <input type="text" id="phone" value="<?= htmlspecialchars($current_user['phone']) ?>" readonly>
                </div>

                <div class="basket-service-field">
                    <label for="service_name">Игровое место</label>
                    <select name="service_name" id="service_name" required>
                        <option value="">Выберите место</option>
                        <?php foreach ($service_options as $option) { ?>
                            <option value="<?= htmlspecialchars($option['value']) ?>">
                                <?= htmlspecialchars($option['text_full']) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div>
                    <label for="booking_date">Дата</label>
                    <input type="date" name="booking_date" id="booking_date" value="<?= $today ?>" min="<?= $today ?>" required>
                </div>

                <div>
                    <label for="hours">Часы</label>
                    <input type="number" name="hours" id="hours" min="1" max="24" value="2" required>
                </div>

                <div class="basket-add-btn-wrap">
                    <button type="submit" name="add" class="btn btn-primary">Добавить в корзину</button>
                </div>
            </form>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="table-card">
            <h2>Позиции в корзине</h2>

            <div class="table-responsive">
                <table class="drafts-table">
                    <thead>
                    <tr>
                        <th class="col-id">№</th>
                        <th class="col-client">Клиент</th>
                        <th class="col-phone">Телефон</th>
                        <th class="col-service">Игровое место</th>
                        <th class="col-date">Дата</th>
                        <th class="col-hours">Часы</th>
                        <th class="col-edit">Редактировать</th>
                        <th class="col-confirm">Подтвердить</th>
                        <th class="col-delete">Удалить</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (!empty($cart_items)) { ?>
                        <?php foreach ($cart_items as $index => $row) { ?>
                            <?php $rowCartId = $row['cart_id'] ?? ''; ?>
                            <?php if ($edit_id !== '' && $edit_id === $rowCartId) { ?>
                                <?php $editDateValue = $row['booking_date'] < $today ? $today : $row['booking_date']; ?>
                                <tr class="editing-row">
                                    <form method="post">
                                        <td><?= $index + 1 ?></td>
                                        <td><?= htmlspecialchars($row['client_name']) ?></td>
                                        <td class="cell-phone"><?= htmlspecialchars($row['phone']) ?></td>
                                        <td class="cell-service cell-service-edit">
                                            <select name="service_name" required>
                                                <?php foreach ($service_options as $option) { ?>
                                                    <option value="<?= htmlspecialchars($option['value']) ?>" <?= $option['value'] === $row['service_name'] ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($option['text_short']) ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </td>
                                        <td class="cell-date">
                                            <input type="date" name="booking_date" value="<?= htmlspecialchars($editDateValue) ?>" min="<?= $today ?>" required>
                                        </td>
                                        <td>
                                            <input type="number" name="hours" min="1" max="24" value="<?= (int) $row['hours'] ?>" required>
                                        </td>
                                        <td>
                                            <input type="hidden" name="cart_id" value="<?= htmlspecialchars($rowCartId) ?>">
                                            <button type="submit" name="save_update" class="btn btn-success btn-compact">Сохранить</button>
                                        </td>
                                        <td>
                                            <a class="btn btn-secondary btn-compact" href="memory.php">Отмена</a>
                                        </td>
                                        <td>
                                            <span class="table-placeholder"></span>
                                        </td>
                                    </form>
                                </tr>
                            <?php } else { ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($row['client_name']) ?></td>
                                    <td class="cell-phone"><?= htmlspecialchars($row['phone']) ?></td>
                                    <td class="cell-service"><?= format_service_name($row['service_name']) ?></td>
                                    <td class="cell-date"><?= format_date_ru($row['booking_date']) ?></td>
                                    <td><?= (int) $row['hours'] ?></td>
                                    <td>
                                        <a class="btn btn-primary btn-compact" href="memory.php?edit=<?= urlencode($rowCartId) ?>">Редактировать</a>
                                    </td>
                                    <td>
                                        <form method="post" class="table-actions">
                                            <input type="hidden" name="cart_id" value="<?= htmlspecialchars($rowCartId) ?>">
                                            <button type="submit" name="confirm" class="btn btn-success btn-compact">Оформить</button>
                                        </form>
                                    </td>
                                    <td>
                                        <a class="btn btn-danger btn-compact" href="memory.php?delete=<?= urlencode($rowCartId) ?>">Удалить</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="9">Корзина пока пустая.</td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>

        </div>

        <?php if (!empty($cart_items)) { ?>
            <div class="cart-summary-outside-row">
                <div class="cart-summary-outside-card">
                    <div class="cart-summary-top">
                        <div class="cart-summary-kicker cart-summary-kicker-big">Итог</div>
                        <div class="cart-summary-total"><?= number_format($cartTotalPrice, 2, '.', ' ') ?> руб.</div>
                        <div class="cart-summary-meta">Позиций: <?= count($cart_items) ?> · Часов: <?= $cartTotalHours ?></div>
                    </div>

                    <div class="cart-summary-actions">
                        <form method="post">
                            <button type="submit" name="confirm_all" class="btn btn-success">Оформить всё</button>
                        </form>
                        <form method="post">
                            <button type="submit" name="delete_all" class="btn btn-danger">Удалить всё</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<?php require_once __DIR__ . '/footer.php'; ?>
