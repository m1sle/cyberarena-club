<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function clean_text(string $value): string
{
    return trim(htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
}

function raw_clean(string $value): string
{
    return trim($value);
}

function normalize_phone_ru(string $phone)
{
    $digits = preg_replace('/\D+/', '', $phone);

    if (strlen($digits) === 11 && ($digits[0] === '7' || $digits[0] === '8')) {
        $digits = '7' . substr($digits, 1);
    } elseif (strlen($digits) === 10) {
        $digits = '7' . $digits;
    } else {
        return false;
    }

    if (strlen($digits) !== 11 || $digits[0] !== '7') {
        return false;
    }

    return '+7 (' . substr($digits, 1, 3) . ') ' . substr($digits, 4, 3) . '-' . substr($digits, 7, 2) . '-' . substr($digits, 9, 2);
}

function is_valid_date(string $date): bool
{
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function is_valid_login_name(string $login): bool
{
    return (bool) preg_match('/^[A-Za-z0-9_]{4,12}$/', $login);
}

function is_valid_full_name(string $fullName): bool
{
    return (bool) preg_match('/^[\p{L}\s\-]{3,100}$/u', $fullName);
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function refresh_user_session(mysqli $conn, int $userId): bool
{
    $sql = "
        SELECT 
            u.id,
            u.full_name,
            u.phone,
            u.login,
            u.email,
            u.registered_at
        FROM users u
        WHERE u.id = ?
        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$user) {
        unset($_SESSION['user']);
        clear_cart_items();
        return false;
    }

    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'full_name' => $user['full_name'],
        'phone' => $user['phone'],
        'login' => $user['login'],
        'email' => $user['email'],
        'registered_at' => $user['registered_at'],
    ];

    return true;
}

function get_cart_items(): array
{
    if (empty($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        return [];
    }

    return array_values($_SESSION['cart']);
}

function save_cart_items(array $items): void
{
    $_SESSION['cart'] = array_values($items);
}

function clear_cart_items(): void
{
    unset($_SESSION['cart']);
}

function get_user_cart_count($conn = null, $userId = null): int
{
    return count(get_cart_items());
}

function add_cart_item(array $item): string
{
    $items = get_cart_items();
    $cartId = uniqid('cart_', true);

    $items[] = [
        'cart_id' => $cartId,
        'client_name' => (string) ($item['client_name'] ?? ''),
        'phone' => (string) ($item['phone'] ?? ''),
        'service_name' => (string) ($item['service_name'] ?? ''),
        'booking_date' => (string) ($item['booking_date'] ?? ''),
        'hours' => (int) ($item['hours'] ?? 0),
    ];

    save_cart_items($items);
    return $cartId;
}

function get_cart_item(string $cartId): ?array
{
    foreach (get_cart_items() as $item) {
        if (($item['cart_id'] ?? '') === $cartId) {
            return $item;
        }
    }

    return null;
}

function update_cart_item(string $cartId, array $newData): bool
{
    $items = get_cart_items();

    foreach ($items as $index => $item) {
        if (($item['cart_id'] ?? '') === $cartId) {
            $items[$index]['service_name'] = (string) ($newData['service_name'] ?? $item['service_name']);
            $items[$index]['booking_date'] = (string) ($newData['booking_date'] ?? $item['booking_date']);
            $items[$index]['hours'] = (int) ($newData['hours'] ?? $item['hours']);
            save_cart_items($items);
            return true;
        }
    }

    return false;
}

function remove_cart_item(string $cartId): void
{
    $filtered = [];

    foreach (get_cart_items() as $item) {
        $itemCartId = isset($item['cart_id']) ? $item['cart_id'] : '';

        if ($itemCartId !== $cartId) {
            $filtered[] = $item;
        }
    }

    save_cart_items($filtered);
}

function require_login(string $redirect = 'login.php'): void
{
    if (!is_logged_in()) {
        set_flash('error', 'Сначала войдите в аккаунт, чтобы пользоваться этой страницей.');
        header('Location: ' . $redirect);
        exit;
    }
}

function logout_user(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}