<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function clean_text(string $value): string
{
    return trim(htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
}

function raw_clean(string $value): string
{
    return trim($value);
}

function normalize_phone_ru(string $phone)
{
    $digits = preg_replace('/\D+/', '', $phone);

    if (strlen($digits) === 11 && ($digits[0] === '7' || $digits[0] === '8')) {
        $digits = '7' . substr($digits, 1);
    } elseif (strlen($digits) === 10) {
        $digits = '7' . $digits;
    } else {
        return false;
    }

    if (strlen($digits) !== 11 || $digits[0] !== '7') {
        return false;
    }

    return '+7 (' . substr($digits, 1, 3) . ') ' . substr($digits, 4, 3) . '-' . substr($digits, 7, 2) . '-' . substr($digits, 9, 2);
}

function is_valid_date(string $date): bool
{
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function is_valid_booking_time(string $time): bool
{
    return (bool) preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time);
}


function normalize_booking_time_sql(string $time): string
{
    $shortTime = substr($time, 0, 5);
    return is_valid_booking_time($shortTime) ? $shortTime . ':00' : '12:00:00';
}

function get_booking_start_datetime(string $date, string $time): ?DateTime
{
    $time = substr(normalize_booking_time_sql($time), 0, 5);
    $dateTime = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $time);
    return $dateTime instanceof DateTime ? $dateTime : null;
}

function format_booking_interval_ru(string $date, string $time, int $hours): string
{
    $start = get_booking_start_datetime($date, $time);
    if (!$start || $hours <= 0) {
        return trim($date . ' ' . substr($time, 0, 5));
    }

    $end = clone $start;
    $end->modify('+' . $hours . ' hour');

    return $start->format('d.m.Y H:i') . ' — ' . $end->format('H:i') . ' (' . $hours . ' ч.)';
}

function get_booking_interval_conflict(mysqli $conn, int $computerId, string $date, string $time, int $hours): ?array
{
    if ($computerId <= 0 || !is_valid_date($date) || !is_valid_booking_time(substr($time, 0, 5)) || $hours <= 0) {
        return ['id' => 0, 'booking_date' => $date, 'booking_time' => $time, 'hours' => $hours];
    }

    $timeSql = normalize_booking_time_sql($time);
    $sql = "
        SELECT
            b.id,
            b.booking_date,
            COALESCE(b.booking_time, '12:00:00') AS booking_time,
            b.hours,
            u.login,
            u.email
        FROM bookings b
        LEFT JOIN users u ON b.user_id = u.id
        WHERE b.computer_id = ?
          AND TIMESTAMP(b.booking_date, COALESCE(b.booking_time, '12:00:00')) < DATE_ADD(TIMESTAMP(?, ?), INTERVAL ? HOUR)
          AND DATE_ADD(TIMESTAMP(b.booking_date, COALESCE(b.booking_time, '12:00:00')), INTERVAL b.hours HOUR) > TIMESTAMP(?, ?)
        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
        return ['id' => 0, 'booking_date' => $date, 'booking_time' => $timeSql, 'hours' => $hours];
    }

    if (!mysqli_stmt_bind_param($stmt, 'ississ', $computerId, $date, $timeSql, $hours, $date, $timeSql)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_bind_param', $sql, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return ['id' => 0, 'booking_date' => $date, 'booking_time' => $timeSql, 'hours' => $hours];
    }

    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return ['id' => 0, 'booking_date' => $date, 'booking_time' => $timeSql, 'hours' => $hours];
    }

    $result = mysqli_stmt_get_result($stmt);
    if ($result === false) {
        logMysqliStmtError($stmt, 'mysqli_stmt_get_result', $sql, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return ['id' => 0, 'booking_date' => $date, 'booking_time' => $timeSql, 'hours' => $hours];
    }

    $conflict = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    return $conflict ?: null;
}

function is_booking_interval_free(mysqli $conn, int $computerId, string $date, string $time, int $hours): bool
{
    return get_booking_interval_conflict($conn, $computerId, $date, $time, $hours) === null;
}

function cart_has_interval_conflict(string $serviceName, string $date, string $time, int $hours, string $excludeCartId = ''): bool
{
    $newStart = get_booking_start_datetime($date, $time);
    if (!$newStart || $hours <= 0) {
        return true;
    }

    $newEnd = clone $newStart;
    $newEnd->modify('+' . $hours . ' hour');

    foreach (get_cart_items() as $cartItem) {
        if ($excludeCartId !== '' && (string) ($cartItem['cart_id'] ?? '') === $excludeCartId) {
            continue;
        }

        if ((string) ($cartItem['service_name'] ?? '') !== $serviceName) {
            continue;
        }

        $oldDate = (string) ($cartItem['booking_date'] ?? '');
        $oldTime = (string) ($cartItem['booking_time'] ?? '12:00');
        $oldHours = (int) ($cartItem['hours'] ?? 0);
        $oldStart = get_booking_start_datetime($oldDate, $oldTime);
        if (!$oldStart || $oldHours <= 0) {
            continue;
        }

        $oldEnd = clone $oldStart;
        $oldEnd->modify('+' . $oldHours . ' hour');

        if ($oldStart < $newEnd && $oldEnd > $newStart) {
            return true;
        }
    }

    return false;
}

function is_valid_login_name(string $login): bool
{
    return (bool) preg_match('/^[A-Za-z0-9_]{4,12}$/', $login);
}

function is_valid_full_name(string $fullName): bool
{
    return (bool) preg_match('/^[\p{L}\s\-]{3,100}$/u', $fullName);
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_admin(): bool
{
    return false;
}

function is_super_admin(): bool
{
    return false;
}

function refresh_user_session(mysqli $conn, int $userId): bool
{
    $sql = "
        SELECT
            u.id,
            u.full_name,
            u.phone,
            u.login,
            u.email,
            u.registered_at,
            u.last_login_at
        FROM users u
        WHERE u.id = ?
        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return false;
    }

    if (!mysqli_stmt_bind_param($stmt, 'i', $userId)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return false;
    }

    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return false;
    }

    $result = mysqli_stmt_get_result($stmt);
    if ($result === false) {
        logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        return false;
    }

    $user = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$user) {
        unset($_SESSION['user']);
        clear_cart_items();
        return false;
    }

    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'full_name' => $user['full_name'],
        'phone' => $user['phone'],
        'login' => $user['login'],
        'email' => $user['email'],
        'registered_at' => $user['registered_at'],
        'last_login_at' => $user['last_login_at'] ?? null,
    ];

    return true;
}

function get_cart_items(): array
{
    if (empty($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        return [];
    }

    return array_values($_SESSION['cart']);
}

function save_cart_items(array $items): void
{
    $_SESSION['cart'] = array_values($items);
    sync_cart_items_to_database();
}

function clear_cart_items(): void
{
    unset($_SESSION['cart']);
    sync_cart_items_to_database(true);
}

function sync_cart_items_to_database(bool $forceClear = false): void
{
    global $conn;

    if (!isset($conn) || !($conn instanceof mysqli) || !is_logged_in()) {
        return;
    }

    $user = current_user();
    $userId = (int) ($user['id'] ?? 0);
    if ($userId <= 0) {
        return;
    }

    $stmtDelete = mysqli_prepare($conn, 'DELETE FROM cart_items WHERE user_id = ?');
    if (!$stmtDelete) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return;
    }

    if (!mysqli_stmt_bind_param($stmtDelete, 'i', $userId)) {
        logMysqliStmtError($stmtDelete, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmtDelete);
        return;
    }

    if (!mysqli_stmt_execute($stmtDelete)) {
        logMysqliStmtError($stmtDelete, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmtDelete);
        return;
    }
    mysqli_stmt_close($stmtDelete);

    if ($forceClear) {
        return;
    }

    $items = get_cart_items();
    if (!$items) {
        return;
    }

    $stmtInsert = mysqli_prepare($conn, 'INSERT INTO cart_items (user_id, cart_id, client_name, phone, service_name, booking_date, booking_time, hours, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())');
    if (!$stmtInsert) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return;
    }

    foreach ($items as $item) {
        $cartId = (string) ($item['cart_id'] ?? '');
        $clientName = (string) ($item['client_name'] ?? '');
        $phone = (string) ($item['phone'] ?? '');
        $serviceName = (string) ($item['service_name'] ?? '');
        $bookingDate = (string) ($item['booking_date'] ?? '');
        $bookingTime = (string) ($item['booking_time'] ?? '12:00');
        $hours = (int) ($item['hours'] ?? 0);

        if (!is_valid_booking_time($bookingTime)) {
            $bookingTime = '12:00';
        }

        if ($cartId === '' || $serviceName === '' || $bookingDate === '' || $hours <= 0) {
            continue;
        }

        if (!mysqli_stmt_bind_param($stmtInsert, 'issssssi', $userId, $cartId, $clientName, $phone, $serviceName, $bookingDate, $bookingTime, $hours)) {
            logMysqliStmtError($stmtInsert, 'mysqli_stmt_error', '', __FILE__, __LINE__);
            continue;
        }

        if (!mysqli_stmt_execute($stmtInsert)) {
            logMysqliStmtError($stmtInsert, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        }
    }

    mysqli_stmt_close($stmtInsert);
}

function get_user_cart_count(): int
{
    return count(get_cart_items());
}

function add_cart_item(array $item): string
{
    $items = get_cart_items();
    $cartId = uniqid('cart_', true);

    $items[] = [
        'cart_id' => $cartId,
        'client_name' => (string) ($item['client_name'] ?? ''),
        'phone' => (string) ($item['phone'] ?? ''),
        'service_name' => (string) ($item['service_name'] ?? ''),
        'booking_date' => (string) ($item['booking_date'] ?? ''),
        'booking_time' => is_valid_booking_time((string) ($item['booking_time'] ?? '12:00')) ? (string) ($item['booking_time'] ?? '12:00') : '12:00',
        'hours' => (int) ($item['hours'] ?? 0),
    ];

    save_cart_items($items);
    return $cartId;
}

function get_cart_item(string $cartId): ?array
{
    foreach (get_cart_items() as $item) {
        if (($item['cart_id'] ?? '') === $cartId) {
            return $item;
        }
    }

    return null;
}

function update_cart_item(string $cartId, array $newData): bool
{
    $items = get_cart_items();

    foreach ($items as $index => $item) {
        if (($item['cart_id'] ?? '') === $cartId) {
            $items[$index]['service_name'] = (string) ($newData['service_name'] ?? $item['service_name']);
            $items[$index]['booking_date'] = (string) ($newData['booking_date'] ?? $item['booking_date']);
            $newBookingTime = (string) ($newData['booking_time'] ?? ($item['booking_time'] ?? '12:00'));
            $items[$index]['booking_time'] = is_valid_booking_time($newBookingTime) ? $newBookingTime : '12:00';
            $items[$index]['hours'] = (int) ($newData['hours'] ?? $item['hours']);
            save_cart_items($items);
            return true;
        }
    }

    return false;
}

function remove_cart_item(string $cartId): void
{
    $filtered = [];

    foreach (get_cart_items() as $item) {
        $itemCartId = isset($item['cart_id']) ? $item['cart_id'] : '';

        if ($itemCartId !== $cartId) {
            $filtered[] = $item;
        }
    }

    save_cart_items($filtered);
}

function require_login(string $redirect = 'login.php'): void
{
    if (!is_logged_in()) {
        set_flash('error', 'Сначала войдите в аккаунт, чтобы пользоваться этой страницей.');
        header('Location: ' . $redirect);
        exit;
    }
}

function logout_user(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}
