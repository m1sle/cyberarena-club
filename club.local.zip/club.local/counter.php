<?php
function ensure_counter_exists(mysqli $conn): void
{
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS site_stats (
        id TINYINT NOT NULL PRIMARY KEY,
        visit_count INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    mysqli_query($conn, "INSERT IGNORE INTO site_stats (id, visit_count) VALUES (1, 0)");
}

function count_visit_once_per_session(mysqli $conn): void
{
    ensure_counter_exists($conn);

    if (empty($_SESSION['visit_counted'])) {
        mysqli_query($conn, "UPDATE site_stats SET visit_count = visit_count + 1 WHERE id = 1");
        $_SESSION['visit_counted'] = true;
    }
}

function get_visit_count(mysqli $conn): int
{
    ensure_counter_exists($conn);
    $result = mysqli_query($conn, "SELECT visit_count FROM site_stats WHERE id = 1 LIMIT 1");
    $row = $result ? mysqli_fetch_assoc($result) : null;
    return $row ? (int) $row['visit_count'] : 0;
}
