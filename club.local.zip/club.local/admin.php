<?php
require_once __DIR__ . '/admin_auth.php';
admin_require_login();
require_once __DIR__ . '/error_handler.php';
registerErrorHandler();
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db_connect.php';

function a_text(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function a_clean(string $value): string
{
    return trim($value);
}

function a_date(?string $value): string
{
    if (!$value || $value === '0000-00-00' || $value === '0000-00-00 00:00:00') {
        return '-';
    }
    $time = strtotime($value);
    return $time ? date('d.m.Y H:i', $time) : $value;
}

function a_short_date(?string $value): string
{
    if (!$value || $value === '0000-00-00') {
        return '-';
    }
    $time = strtotime($value);
    return $time ? date('d.m.Y', $time) : $value;
}

function a_short_time(?string $value): string
{
    if (!$value || $value === '00:00:00') {
        return '12:00';
    }
    return substr($value, 0, 5);
}

function a_booking_end_time(?string $bookingDate, ?string $bookingTime, int $hours): string
{
    $datePart = ($bookingDate && $bookingDate !== '0000-00-00') ? $bookingDate : date('Y-m-d');
    $timePart = (!$bookingTime || $bookingTime === '00:00:00') ? '12:00:00' : $bookingTime;
    if (strlen($timePart) === 5) {
        $timePart .= ':00';
    }

    $startTimestamp = strtotime($datePart . ' ' . $timePart);
    if ($startTimestamp === false) {
        return '-';
    }

    $endTimestamp = strtotime('+' . max(0, $hours) . ' hour', $startTimestamp);
    if ($endTimestamp === false) {
        return '-';
    }

    $result = date('H:i', $endTimestamp);
    $dayDiff = (int) floor((strtotime(date('Y-m-d', $endTimestamp)) - strtotime(date('Y-m-d', $startTimestamp))) / 86400);
    if ($dayDiff > 0) {
        $result .= ' (+' . $dayDiff . ' д.)';
    }

    return $result;
}

function a_count(int $number, string $one, string $few, string $many): string
{
    $n = abs($number) % 100;
    $last = $n % 10;
    if ($n > 10 && $n < 20) return $number . ' ' . $many;
    if ($last === 1) return $number . ' ' . $one;
    if ($last >= 2 && $last <= 4) return $number . ' ' . $few;
    return $number . ' ' . $many;
}

function admin_redirect(int $userId = 0, string $search = '', string $section = 'clients', array $extraParams = []): void
{
    $url = 'admin.php';
    $params = ['section' => $section];
    if ($userId > 0) $params['user_id'] = $userId;
    if ($search !== '') $params['q'] = $search;
    foreach ($extraParams as $key => $value) {
        if ($value !== '' && $value !== null) $params[$key] = $value;
    }
    $url .= '?' . http_build_query($params);
    header('Location: ' . $url);
    exit;
}

function admin_section_url(string $section, array $params = []): string
{
    $params = array_merge(['section' => $section], $params);
    return 'admin.php?' . http_build_query($params);
}

function admin_active_class(string $current, string $section): string
{
    return $current === $section ? 'active' : '';
}

function admin_email_domain_allowed(string $email): bool
{
    $domain = strtolower(substr(strrchr($email, '@') ?: '', 1));
    return in_array($domain, ['gmail.com', 'yandex.ru'], true);
}

function admin_update_user_field(mysqli $conn, int $clientId, string $fieldName, string $fieldValue): void
{
    $allowedFields = [
        'full_name' => 'full_name',
        'login' => 'login',
        'email' => 'email',
        'phone' => 'phone',
    ];

    if ($clientId <= 0) {
        throw new RuntimeException('Пользователь не выбран.');
    }

    if (!isset($allowedFields[$fieldName])) {
        throw new RuntimeException('Недопустимое поле для изменения.');
    }

    $dbField = $allowedFields[$fieldName];
    $newValue = a_clean($fieldValue);

    if ($fieldName === 'full_name') {
        if (!is_valid_full_name($newValue)) {
            throw new RuntimeException('ФИО должно содержать 3–100 символов: буквы, пробелы или дефис.');
        }
    }

    if ($fieldName === 'login') {
        if (!is_valid_login_name($newValue)) {
            throw new RuntimeException('Логин должен содержать 4–12 символов: латиница, цифры или _.');
        }
    }

    if ($fieldName === 'email') {
        $newValue = strtolower($newValue);
        if (!filter_var($newValue, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Введите корректный e-mail.');
        }
        if (!admin_email_domain_allowed($newValue)) {
            throw new RuntimeException('Разрешены только домены gmail.com и yandex.ru.');
        }
    }

    if ($fieldName === 'phone') {
        $phone = normalize_phone_ru($newValue);
        if ($phone === false) {
            throw new RuntimeException('Введите корректный номер телефона.');
        }
        $newValue = $phone;
    }

    if (in_array($fieldName, ['login', 'email', 'phone'], true)) {
        $sqlDuplicate = 'SELECT id FROM users WHERE ' . $dbField . ' = ? AND id <> ? LIMIT 1';
        $stmt = mysqli_prepare($conn, $sqlDuplicate);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sqlDuplicate, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось проверить уникальность поля.');
        }
        mysqli_stmt_bind_param($stmt, 'si', $newValue, $clientId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sqlDuplicate, __FILE__, __LINE__);
            mysqli_stmt_close($stmt);
            throw new RuntimeException('Не удалось выполнить проверку уникальности.');
        }
        $duplicate = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($duplicate) {
            throw new RuntimeException('Такое значение уже используется другим пользователем.');
        }
    }

    $sqlUpdate = 'UPDATE users SET ' . $dbField . ' = ? WHERE id = ?';
    $stmt = mysqli_prepare($conn, $sqlUpdate);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sqlUpdate, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить обновление профиля.');
    }
    mysqli_stmt_bind_param($stmt, 'si', $newValue, $clientId);
    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sqlUpdate, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Не удалось обновить данные клиента.');
    }
    mysqli_stmt_close($stmt);
}

function admin_send_new_password_email(string $email, string $fullName, string $login, string $newPassword): bool
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $subject = 'Новый пароль CyberArena';
    $body = "Здравствуйте" . ($fullName !== '' ? ', ' . $fullName : '') . "!\n\n"
        . "Администратор обработал вашу заявку на восстановление доступа.\n"
        . "Логин: " . $login . "\n"
        . "Новый пароль: " . $newPassword . "\n\n"
        . "После входа рекомендуем изменить пароль в личном кабинете.\n\n"
        . "CyberArena";
    $headers = "From: no-reply@cyberarena.local\r\n"
        . "Content-Type: text/plain; charset=UTF-8";

    return @mail($email, $subject, $body, $headers);
}

function admin_update_password_from_reset_request(mysqli $conn, int $requestId, string $newPassword): int
{
    $newPassword = trim($newPassword);

    if ($requestId <= 0) {
        throw new RuntimeException('Заявка не выбрана.');
    }

    if (mb_strlen($newPassword) < 6) {
        throw new RuntimeException('Новый пароль должен содержать минимум 6 символов.');
    }

    $sqlRequest = 'SELECT id, user_id, login_or_email, phone, registered_at FROM password_reset_requests WHERE id = ? AND status = \'new\' LIMIT 1';
    $stmt = mysqli_prepare($conn, $sqlRequest);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sqlRequest, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить получение заявки.');
    }

    mysqli_stmt_bind_param($stmt, 'i', $requestId);
    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sqlRequest, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Не удалось получить заявку.');
    }

    $request = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$request) {
        throw new RuntimeException('Новая заявка на восстановление не найдена.');
    }

    $clientId = (int) ($request['user_id'] ?? 0);

    if ($clientId <= 0) {
        $loginOrEmail = (string) $request['login_or_email'];
        $phone = (string) $request['phone'];
        $registeredAt = (string) $request['registered_at'];
        $sqlFindUser = 'SELECT id FROM users WHERE (login = ? OR email = ?) AND phone = ? AND registered_at = ? LIMIT 1';
        $stmtFind = mysqli_prepare($conn, $sqlFindUser);
        if (!$stmtFind) {
            logMysqliError($conn, 'mysqli_prepare', $sqlFindUser, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить поиск пользователя по заявке.');
        }

        mysqli_stmt_bind_param($stmtFind, 'ssss', $loginOrEmail, $loginOrEmail, $phone, $registeredAt);
        if (!mysqli_stmt_execute($stmtFind)) {
            logMysqliStmtError($stmtFind, 'mysqli_stmt_execute', $sqlFindUser, __FILE__, __LINE__);
            mysqli_stmt_close($stmtFind);
            throw new RuntimeException('Не удалось найти пользователя по заявке.');
        }

        $userRow = mysqli_fetch_assoc(mysqli_stmt_get_result($stmtFind));
        mysqli_stmt_close($stmtFind);

        if (!$userRow) {
            throw new RuntimeException('Пользователь по данным заявки не найден. Проверьте логин/e-mail, телефон и дату регистрации.');
        }

        $clientId = (int) $userRow['id'];
    }

    $sqlUserForMail = 'SELECT id, full_name, login, email FROM users WHERE id = ? LIMIT 1';
    $stmtUserMail = mysqli_prepare($conn, $sqlUserForMail);
    if (!$stmtUserMail) {
        logMysqliError($conn, 'mysqli_prepare', $sqlUserForMail, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить получение e-mail пользователя.');
    }

    mysqli_stmt_bind_param($stmtUserMail, 'i', $clientId);
    if (!mysqli_stmt_execute($stmtUserMail)) {
        logMysqliStmtError($stmtUserMail, 'mysqli_stmt_execute', $sqlUserForMail, __FILE__, __LINE__);
        mysqli_stmt_close($stmtUserMail);
        throw new RuntimeException('Не удалось получить e-mail пользователя.');
    }

    $userForMail = mysqli_fetch_assoc(mysqli_stmt_get_result($stmtUserMail));
    mysqli_stmt_close($stmtUserMail);
    if (!$userForMail) {
        throw new RuntimeException('Пользователь для отправки нового пароля не найден.');
    }

    $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    if ($passwordHash === false) {
        throw new RuntimeException('Не удалось сформировать хэш нового пароля.');
    }

    $sqlUpdatePassword = 'UPDATE users SET password_hash = ? WHERE id = ?';
    $stmtUpdate = mysqli_prepare($conn, $sqlUpdatePassword);
    if (!$stmtUpdate) {
        logMysqliError($conn, 'mysqli_prepare', $sqlUpdatePassword, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить смену пароля.');
    }

    mysqli_stmt_bind_param($stmtUpdate, 'si', $passwordHash, $clientId);
    if (!mysqli_stmt_execute($stmtUpdate)) {
        logMysqliStmtError($stmtUpdate, 'mysqli_stmt_execute', $sqlUpdatePassword, __FILE__, __LINE__);
        mysqli_stmt_close($stmtUpdate);
        throw new RuntimeException('Не удалось изменить пароль пользователя.');
    }
    mysqli_stmt_close($stmtUpdate);

    $sqlProcessRequest = "UPDATE password_reset_requests SET user_id = ?, status = 'processed', processed_at = NOW() WHERE id = ?";
    $stmtProcess = mysqli_prepare($conn, $sqlProcessRequest);
    if (!$stmtProcess) {
        logMysqliError($conn, 'mysqli_prepare', $sqlProcessRequest, __FILE__, __LINE__);
        throw new RuntimeException('Пароль изменён, но не удалось подготовить закрытие заявки.');
    }

    mysqli_stmt_bind_param($stmtProcess, 'ii', $clientId, $requestId);
    if (!mysqli_stmt_execute($stmtProcess)) {
        logMysqliStmtError($stmtProcess, 'mysqli_stmt_execute', $sqlProcessRequest, __FILE__, __LINE__);
        mysqli_stmt_close($stmtProcess);
        throw new RuntimeException('Пароль изменён, но заявку не удалось отметить обработанной.');
    }
    mysqli_stmt_close($stmtProcess);

    $mailSent = admin_send_new_password_email(
        (string) $userForMail['email'],
        (string) $userForMail['full_name'],
        (string) $userForMail['login'],
        $newPassword
    );

    if (!$mailSent) {
        throw new RuntimeException('Пароль изменён, но письмо пользователю не удалось отправить. Проверьте настройки почты Open Server.');
    }

    return $clientId;
}

$errors = [];
$allowedSections = ['clients', 'requests', 'computers'];
$section = a_clean($_GET['section'] ?? $_POST['section'] ?? 'clients');
if (!in_array($section, $allowedSections, true)) {
    $section = 'clients';
}

$search = a_clean($_GET['q'] ?? $_POST['q'] ?? '');
$selectedUserId = isset($_GET['user_id']) && is_numeric($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['client_id'])) {
    $selectedUserId = (int) $_POST['client_id'];
}

$computerSearch = a_clean($_GET['c_q'] ?? $_POST['c_q'] ?? '');
$computerZone = isset($_GET['c_zone']) || isset($_POST['c_zone']) ? (int) ($_GET['c_zone'] ?? $_POST['c_zone'] ?? 0) : 0;
$computerVip = a_clean($_GET['c_vip'] ?? $_POST['c_vip'] ?? '');
$computerStatus = a_clean($_GET['c_status'] ?? $_POST['c_status'] ?? '');
$computerPriceMinRaw = a_clean($_GET['c_price_min'] ?? $_POST['c_price_min'] ?? '');
$computerPriceMaxRaw = a_clean($_GET['c_price_max'] ?? $_POST['c_price_max'] ?? '');
$computerPriceMin = $computerPriceMinRaw !== '' && is_numeric($computerPriceMinRaw) ? (float) $computerPriceMinRaw : null;
$computerPriceMax = $computerPriceMaxRaw !== '' && is_numeric($computerPriceMaxRaw) ? (float) $computerPriceMaxRaw : null;

$computerFilterParams = [
    'c_q' => $computerSearch,
    'c_zone' => $computerZone > 0 ? (string) $computerZone : '',
    'c_vip' => in_array($computerVip, ['0', '1'], true) ? $computerVip : '',
    'c_status' => in_array($computerStatus, ['available', 'maintenance'], true) ? $computerStatus : '',
    'c_price_min' => $computerPriceMinRaw,
    'c_price_max' => $computerPriceMaxRaw,
];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_client_field'])) {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $fieldName = a_clean($_POST['field_name'] ?? '');
        $fieldValue = a_clean($_POST['field_value'] ?? '');
        admin_update_user_field($conn, $clientId, $fieldName, $fieldValue);
        admin_redirect($clientId, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        if ($clientId <= 0) throw new RuntimeException('Пользователь не выбран.');

        $stmt = mysqli_prepare($conn, 'UPDATE password_reset_requests SET user_id = NULL WHERE user_id = ?');
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', 'UPDATE password_reset_requests SET user_id = NULL WHERE user_id = ?', __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить очистку заявок пользователя.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $clientId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', 'UPDATE password_reset_requests SET user_id = NULL WHERE user_id = ?', __FILE__, __LINE__);
            throw new RuntimeException('Не удалось обновить заявки пользователя.');
        }
        mysqli_stmt_close($stmt);

        foreach (['DELETE FROM cart_items WHERE user_id = ?', 'DELETE FROM bookings WHERE user_id = ?', 'DELETE FROM users WHERE id = ?'] as $sql) {
            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) {
                logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
                throw new RuntimeException('Не удалось подготовить удаление данных пользователя.');
            }
            mysqli_stmt_bind_param($stmt, 'i', $clientId);
            if (!mysqli_stmt_execute($stmt)) {
                logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
                mysqli_stmt_close($stmt);
                throw new RuntimeException('Не удалось удалить данные пользователя.');
            }
            mysqli_stmt_close($stmt);
        }

        admin_redirect(0, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
        $bookingId = (int) ($_POST['booking_id'] ?? 0);
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $sql = 'DELETE FROM bookings WHERE id = ? AND user_id = ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить отмену бронирования.');
        }
        mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $clientId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось отменить бронирование.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($clientId, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_all_bookings'])) {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $sql = 'DELETE FROM bookings WHERE user_id = ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить отмену всех бронирований.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $clientId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось отменить все бронирования.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($clientId, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_bookings_range'])) {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $dateFrom = a_clean((string) ($_POST['date_from'] ?? ''));
        $dateTo = a_clean((string) ($_POST['date_to'] ?? ''));

        if ($clientId <= 0 || !is_valid_date($dateFrom) || !is_valid_date($dateTo) || $dateFrom > $dateTo) {
            throw new RuntimeException('Укажите корректный диапазон дат для удаления бронирований клиента.');
        }

        $sql = 'DELETE FROM bookings WHERE user_id = ? AND booking_date BETWEEN ? AND ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить удаление бронирований по диапазону.');
        }
        mysqli_stmt_bind_param($stmt, 'iss', $clientId, $dateFrom, $dateTo);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось удалить бронирования по диапазону.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($clientId, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_bookings_range_all'])) {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $dateFrom = a_clean((string) ($_POST['date_from'] ?? ''));
        $dateTo = a_clean((string) ($_POST['date_to'] ?? ''));

        if (!is_valid_date($dateFrom) || !is_valid_date($dateTo) || $dateFrom > $dateTo) {
            throw new RuntimeException('Укажите корректный диапазон дат для массового удаления бронирований.');
        }

        $sql = 'DELETE FROM bookings WHERE booking_date BETWEEN ? AND ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить массовое удаление бронирований.');
        }
        mysqli_stmt_bind_param($stmt, 'ss', $dateFrom, $dateTo);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось удалить бронирования у всех пользователей.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($clientId, $search, 'clients');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_user_password'])) {
        $requestId = (int) ($_POST['request_id'] ?? 0);
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $clientId = admin_update_password_from_reset_request($conn, $requestId, $newPassword);
        admin_redirect($clientId, $search, 'requests');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_request'])) {
        $requestId = (int) ($_POST['request_id'] ?? 0);
        $sql = "UPDATE password_reset_requests SET status = 'processed', processed_at = NOW() WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить обработку заявки.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $requestId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось отметить заявку как обработанную.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($selectedUserId, $search, 'requests');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_maintenance'])) {
        $computerId = (int) ($_POST['computer_id'] ?? 0);
        $status = ((int) ($_POST['maintenance_status'] ?? 0)) === 1 ? 1 : 0;
        $sql = 'UPDATE computers SET is_maintenance = ? WHERE id = ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить изменение статуса места.');
        }
        mysqli_stmt_bind_param($stmt, 'ii', $status, $computerId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось изменить статус места.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($selectedUserId, $search, 'computers', $computerFilterParams);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_computer'])) {
        $computerId = (int) ($_POST['computer_id'] ?? 0);
        if ($computerId <= 0) throw new RuntimeException('Игровое место не выбрано.');
        $sql = 'UPDATE computers SET is_active = 0 WHERE id = ?';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить удаление игрового места.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $computerId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось удалить игровое место.');
        }
        mysqli_stmt_close($stmt);
        admin_redirect($selectedUserId, $search, 'computers', $computerFilterParams);
    }
} catch (Throwable $e) {
    $errors[] = $e->getMessage();
}

if ($search !== '') {
    $like = '%' . $search . '%';
    $sql = "SELECT u.id,u.full_name,u.phone,u.login,u.email,u.registered_at,u.last_login_at,(SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.id) AS bookings_count FROM users u WHERE u.full_name LIKE ? OR u.login LIKE ? OR u.email LIKE ? OR u.phone LIKE ? ORDER BY u.id DESC";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить поиск клиентов.');
    }
    mysqli_stmt_bind_param($stmt, 'ssss', $like, $like, $like, $like);
    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось выполнить поиск клиентов.');
    }
    $usersResult = mysqli_stmt_get_result($stmt);
} else {
    $usersResult = mysqli_query($conn, "SELECT u.id,u.full_name,u.phone,u.login,u.email,u.registered_at,u.last_login_at,(SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.id) AS bookings_count FROM users u ORDER BY u.id DESC");
}

$users = [];
if ($usersResult) while ($row = mysqli_fetch_assoc($usersResult)) $users[] = $row;
if ($selectedUserId <= 0 && $users) $selectedUserId = (int) $users[0]['id'];

$selectedUser = null;
$clientBookings = [];
$clientBookingsTotal = 0.0;
$clientBookingsHours = 0;

if ($selectedUserId > 0) {
    $sql = 'SELECT id,full_name,phone,login,email,registered_at,created_at,last_login_at FROM users WHERE id=? LIMIT 1';
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось подготовить получение клиента.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $selectedUserId);
    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
        throw new RuntimeException('Не удалось получить клиента.');
    }
    $selectedUser = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if ($selectedUser) {
        $sql = "SELECT b.id,b.booking_date,COALESCE(b.booking_time,'12:00:00') AS booking_time,b.hours,b.price_per_hour_snapshot,c.pc_name,z.zone_name,cl.club_name,t.tariff_name FROM bookings b JOIN computers c ON b.computer_id=c.id JOIN zones z ON c.zone_id=z.id JOIN clubs cl ON z.club_id=cl.id JOIN tariffs t ON c.tariff_id=t.id WHERE b.user_id=? ORDER BY b.booking_date DESC,b.booking_time DESC,b.id DESC";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось подготовить получение бронирований.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $selectedUserId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
            throw new RuntimeException('Не удалось получить бронирования.');
        }
        $bookingsResult = mysqli_stmt_get_result($stmt);
        while ($booking = mysqli_fetch_assoc($bookingsResult)) {
            $booking['item_total'] = (float) $booking['price_per_hour_snapshot'] * (int) $booking['hours'];
            $clientBookingsTotal += $booking['item_total'];
            $clientBookingsHours += (int) $booking['hours'];
            $clientBookings[] = $booking;
        }
        mysqli_stmt_close($stmt);
    }
}

$requests = [];
$requestsResult = mysqli_query($conn, "SELECT id,user_id,login_or_email,phone,registered_at,message_text,status,created_at FROM password_reset_requests WHERE status='new' ORDER BY created_at DESC");
if ($requestsResult) while ($row = mysqli_fetch_assoc($requestsResult)) $requests[] = $row;

$zonesForFilter = [];
$zonesFilterResult = mysqli_query($conn, 'SELECT id, zone_name FROM zones ORDER BY zone_name ASC');
if ($zonesFilterResult) {
    while ($row = mysqli_fetch_assoc($zonesFilterResult)) {
        $zonesForFilter[] = $row;
    }
}

$computers = [];
$computerWhere = ['c.is_active = 1'];
$computerTypes = '';
$computerValues = [];

if ($computerSearch !== '') {
    $computerWhere[] = '(c.pc_name LIKE ? OR c.cpu LIKE ? OR c.gpu LIKE ? OR c.short_description LIKE ? OR z.zone_name LIKE ? OR t.tariff_name LIKE ?)';
    $likeComputer = '%' . $computerSearch . '%';
    for ($i = 0; $i < 6; $i++) {
        $computerTypes .= 's';
        $computerValues[] = $likeComputer;
    }
}

if ($computerZone > 0) {
    $computerWhere[] = 'c.zone_id = ?';
    $computerTypes .= 'i';
    $computerValues[] = $computerZone;
}

if (in_array($computerVip, ['0', '1'], true)) {
    $computerWhere[] = 'c.is_vip = ?';
    $computerTypes .= 'i';
    $computerValues[] = (int) $computerVip;
}

if ($computerStatus === 'available') {
    $computerWhere[] = 'c.is_maintenance = 0';
} elseif ($computerStatus === 'maintenance') {
    $computerWhere[] = 'c.is_maintenance = 1';
}

if ($computerPriceMin !== null) {
    $computerWhere[] = 't.price_per_hour >= ?';
    $computerTypes .= 'd';
    $computerValues[] = $computerPriceMin;
}

if ($computerPriceMax !== null) {
    $computerWhere[] = 't.price_per_hour <= ?';
    $computerTypes .= 'd';
    $computerValues[] = $computerPriceMax;
}

$computerSql = "
    SELECT
        c.id,
        c.pc_name,
        c.short_description,
        c.photo,
        c.is_vip,
        c.is_maintenance,
        z.zone_name,
        t.tariff_name,
        t.price_per_hour,
        (SELECT COUNT(*) FROM bookings b WHERE b.computer_id = c.id) AS bookings_count
    FROM computers c
    JOIN zones z ON c.zone_id = z.id
    JOIN tariffs t ON c.tariff_id = t.id
    WHERE " . implode(' AND ', $computerWhere) . "
    ORDER BY c.id ASC
";

$stmtComputers = mysqli_prepare($conn, $computerSql);
if ($stmtComputers) {
    if ($computerValues) {
        $computerBindParams = [$computerTypes];
        foreach ($computerValues as $key => $value) {
            $computerBindParams[] = &$computerValues[$key];
        }
        call_user_func_array('mysqli_stmt_bind_param', array_merge([$stmtComputers], $computerBindParams));
    }
    if (mysqli_stmt_execute($stmtComputers)) {
        $computersResult = mysqli_stmt_get_result($stmtComputers);
        while ($row = mysqli_fetch_assoc($computersResult)) {
            $computers[] = $row;
        }
    } else {
        logMysqliStmtError($stmtComputers, 'mysqli_stmt_execute', $computerSql, __FILE__, __LINE__);
        $errors[] = 'Не удалось выполнить фильтрацию игровых мест.';
    }
    mysqli_stmt_close($stmtComputers);
} else {
    logMysqliError($conn, 'mysqli_prepare', $computerSql, __FILE__, __LINE__);
    $errors[] = 'Не удалось подготовить фильтрацию игровых мест.';
}
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Административная панель</title>
    <style>
        :root{
            --page:#f4f6f8;
            --panel:#ffffff;
            --panel-soft:#f8fafc;
            --line:#d7dde6;
            --line-strong:#aeb8c6;
            --text:#1f2937;
            --muted:#64748b;
            --head:#e9eef5;
            --accent:#334155;
            --accent-soft:#e2e8f0;
            --danger:#8a2c2c;
            --danger-soft:#f3dddd;
            --ok-soft:#e4f3ea;
        }
        body{margin:0;font-family:Arial,sans-serif;background:var(--page);color:var(--text);font-size:15px;line-height:1.45}
        a{color:var(--accent)}
        .top{border-bottom:1px solid var(--line-strong);background:var(--head);padding:18px 20px 16px;display:flex;justify-content:center;align-items:center;gap:8px;position:relative;text-align:center;box-shadow:0 2px 8px rgba(31,41,55,.06)}
        .top strong{font-size:28px;color:#111827;line-height:1.15}.top-meta{position:absolute;right:20px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:14px}.top a{font-weight:bold;text-decoration:none}.top a:hover{text-decoration:underline}
        .wrap{padding:20px;max-width:1480px;margin:0 auto}
        .section{border:1px solid var(--line);border-radius:14px;margin-bottom:18px;padding:16px;background:var(--panel);box-shadow:0 8px 20px rgba(31,41,55,.05)}
        .section h2{margin:0 0 10px;font-size:22px;color:#111827}.section h3{margin:14px 0 8px}
        .muted{color:var(--muted);font-size:14px}.grid{display:grid;grid-template-columns:330px 1fr;gap:18px;align-items:start}
        .client-list{max-height:570px;overflow-y:auto;overflow-x:hidden;border:1px solid var(--line);border-radius:12px;background:var(--panel-soft)}
        .client-item{display:block;border-bottom:1px solid var(--line);padding:12px;text-decoration:none;color:var(--text);background:#fff}.client-item:last-child{border-bottom:0}.client-item:hover{background:#f1f5f9}.client-item.active{background:#e2e8f0;font-weight:bold;box-shadow:inset 4px 0 0 var(--accent)}
        input,textarea,select{box-sizing:border-box;padding:9px 10px;border:1px solid var(--line-strong);border-radius:10px;background:#fff;color:var(--text);font-size:15px;outline:none}
        input:focus,textarea:focus,select:focus{border-color:#64748b;box-shadow:0 0 0 3px rgba(100,116,139,.14)}
        input[type=text],input[type=email],input[type=number],input[type=date],select,textarea{width:100%}
        .btn{display:inline-block;border:1px solid var(--line-strong);border-radius:10px;background:#fff;color:var(--text);padding:8px 12px;cursor:pointer;text-decoration:none;font-weight:bold;white-space:nowrap}
        .btn:hover{background:var(--accent-soft)}.btn-dark{background:var(--accent);border-color:var(--accent);color:#fff}.btn-dark:hover{background:#1f2937}.btn-danger{background:var(--danger-soft);border-color:#c99;color:#6b1111}.btn-danger:hover{background:#ebc7c7}.btn-small{padding:6px 10px;font-size:14px}.btn-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
        .request-actions{min-width:430px}.request-action-row{display:flex;align-items:center;gap:8px;flex-wrap:nowrap}.reset-password-form{display:flex;align-items:center;gap:8px;flex-wrap:nowrap}.reset-password-form input[type=password]{width:190px;min-width:190px}.reject-request-form{display:flex;align-items:center;margin:0}.request-action-row .btn{white-space:nowrap}
        form{margin:0}table{width:100%;border-collapse:separate;border-spacing:0;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff}th,td{border-bottom:1px solid var(--line);padding:10px;text-align:left;vertical-align:top}tr:last-child td{border-bottom:0}th{background:#edf2f7;color:#111827;font-size:14px}
        .profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}.box{border:1px solid var(--line);border-radius:12px;padding:11px;background:#fff;text-align:left}.box span{display:block;font-size:13px;color:var(--muted);margin-bottom:4px}.box-button{width:100%;cursor:pointer}.box-button:hover,.box-button.active{background:#eef3f8;border-color:#94a3b8}
        .inline-form{display:grid;grid-template-columns:1fr auto;gap:8px;margin:10px 0 14px}.edit-row{border:1px solid var(--line-strong);border-radius:12px;background:#f8fafc;padding:12px;margin:12px 0 14px}.edit-row-grid{display:grid;grid-template-columns:180px 1fr auto;gap:10px;align-items:end}
        .computer-list{display:grid;gap:10px}.computer-row{display:grid;grid-template-columns:95px 1fr auto;gap:12px;align-items:center;border:1px solid var(--line);border-radius:12px;padding:10px;background:#fff}.computer-row:hover{background:#fbfdff}.computer-row img{width:95px;height:60px;object-fit:cover;filter:grayscale(65%);border-radius:10px;border:1px solid var(--line)}
        .status{display:inline-block;border:1px solid var(--line-strong);border-radius:999px;background:#f8fafc;padding:3px 9px;font-size:13px;margin:0 4px 5px 0}.error{border:1px solid #d89;background:#fdecec;color:#581313;border-radius:12px;padding:12px;margin-bottom:14px}.section-title-row{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px}.section-title-row h2{margin:0}
        .admin-nav{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;align-items:center;border-bottom:1px solid var(--line);padding:16px 20px;background:#eef2f7;position:sticky;top:0;z-index:5;box-shadow:0 2px 10px rgba(31,41,55,.05)}
        .admin-nav a{border:1px solid var(--line-strong);border-radius:999px;padding:11px 22px;text-decoration:none;background:#fff;color:var(--text);font-weight:bold;font-size:16px;min-width:120px;text-align:center}.admin-nav a:hover{background:#e2e8f0}.admin-nav a.active{background:var(--accent);border-color:var(--accent);color:#fff}
        .range-tools{display:grid;grid-template-columns:repeat(2,minmax(160px,220px)) auto;gap:8px;align-items:end;margin:12px 0;padding:12px;border:1px solid var(--line);border-radius:12px;background:#f8fafc}.range-tools span{display:block;font-size:13px;color:var(--muted);margin-bottom:4px}.global-range-wrap{margin-top:18px}.global-range-wrap .section{margin-bottom:0}.global-range-wrap .range-tools{max-width:680px}.computer-filters{display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr auto auto;gap:10px;align-items:end;margin:12px 0 16px;padding:12px;border:1px solid var(--line);border-radius:14px;background:#f8fafc}.computer-filter-field span{display:block;font-size:13px;color:var(--muted);margin-bottom:4px}.computer-list-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px}.computer-count{font-weight:bold;color:#111827}
        @media(max-width:1200px){.computer-filters{grid-template-columns:repeat(3,1fr)}}
        @media(max-width:900px){.grid,.profile-grid,.computer-row,.inline-form,.edit-row-grid,.computer-filters,.range-tools{grid-template-columns:1fr}.top{align-items:center;flex-direction:column}.top-meta{position:static;transform:none}.request-actions{min-width:0}.request-action-row,.reset-password-form{flex-wrap:wrap}.admin-nav{position:static}.admin-nav a{width:100%;max-width:360px}}
    </style>
</head>
<body>
<div class="top"><strong>Административная панель</strong><div class="top-meta">Админ: <?= a_text($_SESSION['plain_admin_login'] ?? '') ?> | <a href="admin_logout.php">Выход</a> | <a href="index.php">На сайт</a></div></div>
<nav class="admin-nav">
    <a class="<?= admin_active_class($section, 'clients') ?>" href="<?= a_text(admin_section_url('clients', ['q' => $search, 'user_id' => $selectedUserId])) ?>">Клиенты</a>
    <a class="<?= admin_active_class($section, 'requests') ?>" href="<?= a_text(admin_section_url('requests')) ?>">Заявки восстановления</a>
    <a class="<?= admin_active_class($section, 'computers') ?>" href="<?= a_text(admin_section_url('computers', $computerFilterParams)) ?>">Игровые места</a>
</nav>
<div class="wrap">
<?php if($errors){?><div class="error"><?php foreach($errors as $error){?><div><?=a_text($error)?></div><?php }?></div><?php }?>

<?php if($section === 'clients'){ ?>
<div class="section">
    <h2>Клиенты</h2>
    <form method="get" class="inline-form"><input type="hidden" name="section" value="clients"><input type="text" name="q" value="<?=a_text($search)?>" placeholder="Поиск по имени, логину, e-mail или телефону"><button class="btn btn-dark" type="submit">Найти</button></form>
    <div class="grid">
        <div class="client-list">
            <?php if($users){foreach($users as $client){?><a class="client-item <?=((int)$client['id']===$selectedUserId)?'active':''?>" href="admin.php?section=clients&user_id=<?=(int)$client['id']?>&q=<?=urlencode($search)?>"><strong><?=a_text($client['full_name'])?></strong><br>@<?=a_text($client['login'])?><br><span class="muted">Броней: <?=(int)$client['bookings_count']?></span></a><?php }}else{?><div class="client-item">Клиенты не найдены.</div><?php }?>
        </div>
        <div>
        <?php if($selectedUser){?>
            <div class="section">
                <h2>Профиль клиента</h2>
                <div class="profile-grid">
                    <div class="box"><span>ID</span><?=(int)$selectedUser['id']?></div>
                    <button type="button" class="box box-button profile-edit-tile" data-field="full_name" data-label="ФИО" data-value="<?=a_text($selectedUser['full_name'])?>"><span>ФИО</span><?=a_text($selectedUser['full_name'])?></button>
                    <button type="button" class="box box-button profile-edit-tile active" data-field="login" data-label="Логин" data-value="<?=a_text($selectedUser['login'])?>"><span>Логин</span>@<?=a_text($selectedUser['login'])?></button>
                    <button type="button" class="box box-button profile-edit-tile" data-field="phone" data-label="Телефон" data-value="<?=a_text($selectedUser['phone'])?>"><span>Телефон</span><?=a_text($selectedUser['phone'])?></button>
                    <button type="button" class="box box-button profile-edit-tile" data-field="email" data-label="E-mail" data-value="<?=a_text($selectedUser['email'])?>"><span>E-mail</span><?=a_text($selectedUser['email'])?></button>
                    <div class="box"><span>Дата регистрации</span><?=a_short_date($selectedUser['registered_at'])?></div>
                    <div class="box"><span>Последний вход</span><?=a_date($selectedUser['last_login_at'])?></div>
                </div>

                <div class="edit-row">
                    <form method="post" class="edit-row-grid">
                        <input type="hidden" name="section" value="clients">
                        <input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>">
                        <input type="hidden" name="q" value="<?=a_text($search)?>">
                        <input type="hidden" name="field_name" id="profile-field-name" value="login">
                        <div><strong id="profile-field-label">Логин</strong><br><span class="muted">Нажмите плитку выше, чтобы выбрать поле</span></div>
                        <input type="text" name="field_value" id="profile-field-value" value="<?=a_text($selectedUser['login'])?>" required>
                        <button class="btn btn-dark" type="submit" name="update_client_field">Изменить</button>
                    </form>
                </div>

                <form method="post" style="margin-top:12px">
                    <input type="hidden" name="section" value="clients">
                    <input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>">
                    <button class="btn btn-danger" type="submit" name="delete_user">Удалить аккаунт</button>
                </form>
            </div>

            <div class="section"><h2>Бронирования клиента</h2><table><tr><th>ID</th><th>Место</th><th>Дата</th><th>С</th><th>До</th><th>Цена</th><th>Действие</th></tr><?php if($clientBookings){foreach($clientBookings as $booking){?><tr><td><?=(int)$booking['id']?></td><td><?=a_text($booking['pc_name'])?></td><td><?=a_short_date($booking['booking_date'])?></td><td><?=a_text(a_short_time($booking['booking_time'] ?? '12:00'))?></td><td><?=a_text(a_booking_end_time($booking['booking_date'], $booking['booking_time'] ?? '12:00', (int)$booking['hours']))?></td><td><?=number_format((float)$booking['item_total'],2,'.',' ')?> руб.</td><td><form method="post"><input type="hidden" name="section" value="clients"><input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>"><input type="hidden" name="booking_id" value="<?=(int)$booking['id']?>"><button class="btn btn-small" type="submit" name="cancel_booking">Отменить</button></form></td></tr><?php }}else{?><tr><td colspan="7">Бронирований нет.</td></tr><?php }?></table><?php if($clientBookings){?><p><strong>Итог:</strong> <?=number_format($clientBookingsTotal,2,'.',' ')?> руб. · <?=a_count($clientBookingsHours,'час','часа','часов')?></p><form method="post" class="range-tools"><input type="hidden" name="section" value="clients"><input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>"><label><span>Удалить у клиента от</span><input type="date" name="date_from" required></label><label><span>до</span><input type="date" name="date_to" required></label><button class="btn btn-danger" type="submit" name="cancel_bookings_range">Удалить</button></form><form method="post"><input type="hidden" name="section" value="clients"><input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>"><button class="btn btn-danger" type="submit" name="cancel_all_bookings">Отменить все бронирования клиента</button></form><?php }?></div>
        <?php }else{?><div class="section">Выберите клиента слева.</div><?php }?>
        </div>
    </div>

    <?php if($selectedUser){ ?>
    <div class="global-range-wrap">
        <div class="section">
            <h2>Удалить бронирования у всех</h2>
            <form method="post" class="range-tools">
                <input type="hidden" name="section" value="clients">
                <input type="hidden" name="client_id" value="<?=(int)$selectedUser['id']?>">
                <label><span>От</span><input type="date" name="date_from" required></label>
                <label><span>До</span><input type="date" name="date_to" required></label>
                <button class="btn btn-danger" type="submit" name="cancel_bookings_range_all">Удалить</button>
            </form>
        </div>
    </div>
    <?php } ?>
</div>
<?php } ?>

<?php if($section === 'requests'){ ?>
<div class="section"><h2>Заявки на восстановление пароля</h2><p class="muted">Заявки сохраняются в админ-панели. После смены пароля новый пароль отправляется пользователю на e-mail аккаунта через mail(), а Open Server сохраняет письмо в userdata/temp/email/.</p><table><tr><th>ID</th><th>Логин/e-mail</th><th>Телефон</th><th>Дата регистрации</th><th>Комментарий</th><th>Создана</th><th>Действие</th></tr><?php if($requests){foreach($requests as $request){?><tr><td><?=(int)$request['id']?></td><td><?=a_text($request['login_or_email'])?></td><td><?=a_text($request['phone'])?></td><td><?=a_short_date($request['registered_at'])?></td><td><?=nl2br(a_text((string)$request['message_text']))?></td><td><?=a_date($request['created_at'])?></td><td class="request-actions"><div class="request-action-row"><form method="post" class="reset-password-form"><input type="hidden" name="section" value="requests"><input type="hidden" name="request_id" value="<?=(int)$request['id']?>"><input type="password" name="new_password" placeholder="Новый пароль" minlength="6" required><button class="btn btn-small btn-dark" type="submit" name="reset_user_password">Сменить пароль</button></form><form method="post" class="reject-request-form"><input type="hidden" name="section" value="requests"><input type="hidden" name="request_id" value="<?=(int)$request['id']?>"><button class="btn btn-small" type="submit" name="process_request">Отклонить</button></form></div></td></tr><?php }}else{?><tr><td colspan="7">Новых заявок нет.</td></tr><?php }?></table></div>
<?php } ?>

<?php if($section === 'computers'){ ?>
<div class="section">
    <div class="section-title-row"><h2>Состояние игровых мест</h2><a class="btn btn-dark" href="admin_computer_form.php">Добавить игровое место</a></div>
    <p>Администратор может добавлять, изменять, удалять места, переводить место в статус обслуживания или вернуть его в работу.</p>

    <form method="get" class="computer-filters">
        <input type="hidden" name="section" value="computers">
        <div class="computer-filter-field"><span>Поиск</span><input type="text" name="c_q" value="<?=a_text($computerSearch)?>" placeholder="Название, CPU, GPU, описание"></div>
        <div class="computer-filter-field"><span>Зона</span><select name="c_zone"><option value="0">Все зоны</option><?php foreach($zonesForFilter as $zone){?><option value="<?=(int)$zone['id']?>"<?=((int)$zone['id']===$computerZone)?' selected':''?>><?=a_text($zone['zone_name'])?></option><?php }?></select></div>
        <div class="computer-filter-field"><span>VIP</span><select name="c_vip"><option value="">Все</option><option value="1"<?=$computerVip==='1'?' selected':''?>>VIP</option><option value="0"<?=$computerVip==='0'?' selected':''?>>Standard</option></select></div>
        <div class="computer-filter-field"><span>Статус</span><select name="c_status"><option value="">Все</option><option value="available"<?=$computerStatus==='available'?' selected':''?>>Доступно</option><option value="maintenance"<?=$computerStatus==='maintenance'?' selected':''?>>На обслуживании</option></select></div>
        <div class="computer-filter-field"><span>Цена от</span><input type="number" name="c_price_min" min="0" step="1" value="<?=a_text($computerPriceMinRaw)?>"></div>
        <div class="computer-filter-field"><span>Цена до</span><input type="number" name="c_price_max" min="0" step="1" value="<?=a_text($computerPriceMaxRaw)?>"></div>
        <button class="btn btn-dark" type="submit">Фильтр</button>
        <a class="btn" href="admin.php?section=computers">Сбросить</a>
    </form>

    <div class="computer-list-head"><span class="computer-count">Найдено: <?=count($computers)?></span><span class="muted">Фильтр работает по названию, зоне, VIP, статусу и цене.</span></div>
    <div class="computer-list"><?php if($computers){foreach($computers as $computer){?><div class="computer-row"><img src="images/<?=a_text($computer['photo'])?>" alt=""><div><span class="status"><?=(int)$computer['is_maintenance']===1?'на обслуживании':'доступно'?></span> <?php if((int)($computer['is_vip'] ?? 0)===1){?><span class="status">VIP</span><?php }else{?><span class="status">standard</span><?php }?><br><strong><?=a_text($computer['pc_name'])?></strong><br><?=a_text($computer['zone_name'])?> · <?=a_text($computer['tariff_name'])?> · <?=a_text((string)$computer['price_per_hour'])?> Р/час<?php if(trim((string)($computer['short_description'] ?? '')) !== ''){?><br><span class="muted"><?=a_text($computer['short_description'])?></span><?php }?><br><span class="muted"><?=(int)$computer['bookings_count']?> броней в истории</span></div><div class="btn-row"><a class="btn btn-small" href="admin_computer_form.php?id=<?=(int)$computer['id']?>">Изменить</a><form method="post"><input type="hidden" name="section" value="computers"><input type="hidden" name="computer_id" value="<?=(int)$computer['id']?>"><input type="hidden" name="c_q" value="<?=a_text($computerSearch)?>"><input type="hidden" name="c_zone" value="<?=a_text((string)$computerZone)?>"><input type="hidden" name="c_vip" value="<?=a_text($computerVip)?>"><input type="hidden" name="c_status" value="<?=a_text($computerStatus)?>"><input type="hidden" name="c_price_min" value="<?=a_text($computerPriceMinRaw)?>"><input type="hidden" name="c_price_max" value="<?=a_text($computerPriceMaxRaw)?>"><?php if((int)$computer['is_maintenance']===1){?><input type="hidden" name="maintenance_status" value="0"><button class="btn btn-small" type="submit" name="set_maintenance">Вернуть в работу</button><?php }else{?><input type="hidden" name="maintenance_status" value="1"><button class="btn btn-small" type="submit" name="set_maintenance">На обслуживание</button><?php }?></form><form method="post"><input type="hidden" name="section" value="computers"><input type="hidden" name="computer_id" value="<?=(int)$computer['id']?>"><input type="hidden" name="c_q" value="<?=a_text($computerSearch)?>"><input type="hidden" name="c_zone" value="<?=a_text((string)$computerZone)?>"><input type="hidden" name="c_vip" value="<?=a_text($computerVip)?>"><input type="hidden" name="c_status" value="<?=a_text($computerStatus)?>"><input type="hidden" name="c_price_min" value="<?=a_text($computerPriceMinRaw)?>"><input type="hidden" name="c_price_max" value="<?=a_text($computerPriceMaxRaw)?>"><button class="btn btn-small btn-danger" type="submit" name="delete_computer">Удалить</button></form></div></div><?php }}else{?><div class="computer-row"><div></div><div>Игровые места по выбранным фильтрам не найдены.</div><div></div></div><?php }?></div>
</div>
<?php } ?>
</div>
<script>
(function () {
    const tiles = document.querySelectorAll('.profile-edit-tile');
    const fieldName = document.getElementById('profile-field-name');
    const fieldLabel = document.getElementById('profile-field-label');
    const fieldValue = document.getElementById('profile-field-value');

    function setField(tile) {
        tiles.forEach(item => item.classList.remove('active'));
        tile.classList.add('active');
        fieldName.value = tile.dataset.field;
        fieldLabel.textContent = tile.dataset.label;
        fieldValue.value = tile.dataset.value;
        fieldValue.type = tile.dataset.field === 'email' ? 'email' : 'text';
        fieldValue.focus();
    }

    tiles.forEach(tile => tile.addEventListener('click', () => setField(tile)));
})();
</script>
</body></html>
