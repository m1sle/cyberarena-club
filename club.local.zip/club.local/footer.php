<?php
$visits = get_visit_count($conn);
?>
<footer class="footer">
    <div class="container footer-inner">
        <div>CyberArena — компьютерный клуб для игр, турниров и вечерних сессий.</div>
        <div>Посещений сайта: <strong><?= $visits ?></strong></div>
    </div>
</footer>
</body>
</html>
