<?php
$visits = get_visit_count($conn);
?>
<footer class="footer">
    <div class="container footer-inner">
        <div>CyberArena — компьютерный клуб для игр, турниров и вечерних сессий.</div>
        <div>Посещений сайта: <strong><?= $visits ?></strong></div>
    </div>
</footer>

<script>
(function () {
    function closePickers(except) {
        document.querySelectorAll('[data-time-picker].open').forEach(function (picker) {
            if (picker !== except) {
                picker.classList.remove('open');
                const toggle = picker.querySelector('[data-time-toggle]');
                if (toggle) {
                    toggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    }

    function findScopedElement(picker, selector) {
        if (!selector) {
            return null;
        }

        const form = picker.closest('form');
        if (form) {
            const inForm = form.querySelector(selector);
            if (inForm) {
                return inForm;
            }
        }

        const row = picker.closest('tr');
        if (row) {
            const inRow = row.querySelector(selector);
            if (inRow) {
                return inRow;
            }
        }

        return document.querySelector(selector);
    }

    function getPickerParams(picker) {
        const dateInput = findScopedElement(picker, picker.dataset.dateSource || '');
        const hoursInput = findScopedElement(picker, picker.dataset.hoursSource || '');
        const serviceInput = findScopedElement(picker, picker.dataset.serviceSource || '');

        const params = new URLSearchParams();
        if (picker.dataset.computerId) {
            params.set('computer_id', picker.dataset.computerId);
        }
        if (serviceInput && serviceInput.value) {
            params.set('service_name', serviceInput.value);
        }
        if (dateInput && dateInput.value) {
            params.set('date', dateInput.value);
        }
        if (hoursInput && hoursInput.value) {
            params.set('hours', hoursInput.value);
        }

        return params;
    }

    function setPickerValue(picker, value) {
        const input = picker.querySelector('[data-time-input]');
        const label = picker.querySelector('[data-time-label]');

        if (input) {
            input.value = value;
        }

        if (label) {
            label.textContent = value;
        }

        picker.querySelectorAll('[data-time-value]').forEach(function (item) {
            item.classList.toggle('active', item.dataset.timeValue === value);
        });
    }

    function updateDisabledSlots(picker, disabledSlots) {
        const disabledSet = new Set(disabledSlots || []);
        let currentValue = '';
        const input = picker.querySelector('[data-time-input]');
        if (input) {
            currentValue = input.value;
        }

        let firstAvailable = '';

        picker.querySelectorAll('[data-time-value]').forEach(function (option) {
            const value = option.dataset.timeValue;
            const disabled = disabledSet.has(value);

            option.classList.toggle('disabled', disabled);
            option.setAttribute('aria-disabled', disabled ? 'true' : 'false');
            option.title = disabled ? 'Это время уже занято' : '';

            if (!disabled && firstAvailable === '') {
                firstAvailable = value;
            }
        });

        if (currentValue && disabledSet.has(currentValue) && firstAvailable !== '') {
            setPickerValue(picker, firstAvailable);
        }
    }

    function refreshPickerAvailability(picker) {
        const url = picker.dataset.availabilityUrl;
        if (!url) {
            return;
        }

        const params = getPickerParams(picker);

        if (!params.has('computer_id') && !params.has('service_name')) {
            updateDisabledSlots(picker, []);
            return;
        }

        if (!params.has('date') || !params.has('hours')) {
            updateDisabledSlots(picker, []);
            return;
        }

        picker.classList.add('loading');

        fetch(url + '?' + params.toString(), {
            headers: {'Accept': 'application/json'}
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                updateDisabledSlots(picker, data && data.disabled ? data.disabled : []);
            })
            .catch(function () {
                updateDisabledSlots(picker, []);
            })
            .finally(function () {
                picker.classList.remove('loading');
            });
    }

    function bindAvailability(picker) {
        const sources = [
            picker.dataset.dateSource,
            picker.dataset.hoursSource,
            picker.dataset.serviceSource
        ];

        sources.forEach(function (selector) {
            const element = findScopedElement(picker, selector || '');
            if (!element) {
                return;
            }

            element.addEventListener('change', function () {
                refreshPickerAvailability(picker);
            });

            element.addEventListener('input', function () {
                refreshPickerAvailability(picker);
            });
        });

        refreshPickerAvailability(picker);
    }

    document.querySelectorAll('[data-time-picker]').forEach(bindAvailability);

    document.addEventListener('click', function (event) {
        const toggle = event.target.closest('[data-time-toggle]');
        const option = event.target.closest('[data-time-value]');

        if (toggle) {
            const picker = toggle.closest('[data-time-picker]');
            const isOpen = picker.classList.contains('open');
            closePickers(picker);
            picker.classList.toggle('open', !isOpen);
            toggle.setAttribute('aria-expanded', isOpen ? 'false' : 'true');

            if (!isOpen) {
                refreshPickerAvailability(picker);
            }

            return;
        }

        if (option) {
            if (option.classList.contains('disabled')) {
                event.preventDefault();
                return;
            }

            const picker = option.closest('[data-time-picker]');
            const value = option.dataset.timeValue || option.textContent.trim();

            setPickerValue(picker, value);

            picker.classList.remove('open');
            const pickerToggle = picker.querySelector('[data-time-toggle]');
            if (pickerToggle) {
                pickerToggle.setAttribute('aria-expanded', 'false');
            }
            return;
        }

        if (!event.target.closest('[data-time-picker]')) {
            closePickers(null);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closePickers(null);
        }
    });
})();
</script>

</body>
</html>
