<?php
require_once __DIR__ . '/bootstrap.php';
require_login('login.php');
refresh_user_session($conn, current_user()['id']);

function format_booking_date_ru(string $date): string
{
    $timestamp = strtotime($date);
    return $timestamp ? date('d.m.Y', $timestamp) : $date;
}

$user = current_user();
$pageTitle = 'Мои бронирования | CyberArena';
$today = date('Y-m-d');

if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $bookingId = (int) $_GET['cancel'];

    $stmtDelete = mysqli_prepare($conn, 'DELETE b FROM bookings b WHERE b.id = ? AND b.user_id = ?');
    if (!$stmtDelete) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        set_flash('error', 'Не удалось подготовить отмену бронирования.');
        header('Location: bookings.php');
        exit;
    }

    $userId = (int) $user['id'];
    if (!mysqli_stmt_bind_param($stmtDelete, 'ii', $bookingId, $userId)) {
        logMysqliStmtError($stmtDelete, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmtDelete);
        set_flash('error', 'Не удалось обработать отмену бронирования.');
        header('Location: bookings.php');
        exit;
    }

    if (!mysqli_stmt_execute($stmtDelete)) {
        logMysqliStmtError($stmtDelete, 'mysqli_stmt_error', '', __FILE__, __LINE__);
        mysqli_stmt_close($stmtDelete);
        set_flash('error', 'Не удалось отменить бронирование.');
        header('Location: bookings.php');
        exit;
    }
    mysqli_stmt_close($stmtDelete);

    set_flash('info', 'Бронирование отменено.');
    header('Location: bookings.php');
    exit;
}

$sql = "
    SELECT
        b.id,
        c.pc_name,
        c.is_vip,
        z.zone_name,
        cl.club_name,
        t.tariff_name,
        COALESCE(NULLIF(b.price_per_hour_snapshot, 0), t.price_per_hour) AS price_per_hour,
        b.booking_date,
        COALESCE(b.booking_time, '12:00:00') AS booking_time,
        b.hours
    FROM bookings b
    JOIN computers c ON b.computer_id = c.id
    JOIN zones z ON c.zone_id = z.id
    JOIN clubs cl ON z.club_id = cl.id
    JOIN tariffs t ON c.tariff_id = t.id
    WHERE b.user_id = ?
    ORDER BY b.booking_date ASC, b.booking_time ASC, b.id ASC
";

$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
    showSystemError();
}

$userId = (int) $user['id'];
if (!mysqli_stmt_bind_param($stmt, 'i', $userId)) {
    logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
    showSystemError();
}

if (!mysqli_stmt_execute($stmt)) {
    logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
    showSystemError();
}

$result = mysqli_stmt_get_result($stmt);
if ($result === false) {
    logMysqliStmtError($stmt, 'mysqli_stmt_error', '', __FILE__, __LINE__);
    showSystemError();
}

$bookings = [];
$totalHours = 0;
$totalPrice = 0.0;
$nextBooking = null;
$nearestDate = null;
$nearestDateTotal = 0.0;

while ($row = mysqli_fetch_assoc($result)) {
    $row['item_total'] = (float) $row['price_per_hour'] * (int) $row['hours'];
    $bookings[] = $row;
    $totalHours += (int) $row['hours'];
    $totalPrice += $row['item_total'];

    if ($nextBooking === null && $row['booking_date'] >= $today) {
        $nextBooking = $row;
        $nearestDate = $row['booking_date'];
    }
}

if ($nextBooking === null && !empty($bookings)) {
    $nextBooking = $bookings[0];
    $nearestDate = $bookings[0]['booking_date'];
}

if ($nearestDate !== null) {
    foreach ($bookings as $row) {
        if ($row['booking_date'] === $nearestDate) {
            $nearestDateTotal += (float) $row['item_total'];
        }
    }
}

$totalBookings = count($bookings);
$nextBookingLabel = $nextBooking
    ? format_booking_date_ru($nextBooking['booking_date']) . ' в ' . substr((string)($nextBooking['booking_time'] ?? '12:00'), 0, 5) . ' · ' . $nextBooking['pc_name']
    : 'Пока нет активных бронирований';
$nearestDatePriceLabel = $nearestDate !== null
    ? 'На ближайший день: ' . number_format($nearestDateTotal, 2, '.', ' ') . ' руб.'
    : 'На ближайший день: 0.00 руб.';

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container">
        <div class="info-card">
            <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:16px;">
                <div>
                    <h2 style="margin:0 0 12px;">Мои бронирования</h2>
                    <p class="note" style="max-width:900px;">
                        В этом разделе отображаются ваши оформленные бронирования. Здесь можно посмотреть
                        дату игровой сессии, выбранное место, тариф, клуб и зафиксированную стоимость, а при необходимости
                        отменить активное бронирование.
                    </p>
                </div>

                <div style="
                    display:inline-flex;
                    align-items:center;
                    gap:10px;
                    padding:10px 14px;
                    border-radius:999px;
                    background:rgba(124, 92, 255, 0.14);
                    border:1px solid rgba(124, 92, 255, 0.28);
                    color:#e7e0ff;
                    font-weight:700;
                    white-space:nowrap;
                    box-shadow:0 0 20px rgba(124, 92, 255, 0.12);
                ">
                    Онлайн-бронирование активно
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="booking-stats-grid booking-stats-grid--4 booking-stats-grid-force booking-stats-row-4" style="display:grid;grid-template-columns:minmax(0,0.9fr) minmax(0,0.9fr) minmax(0,1.25fr) minmax(0,1fr);gap:18px;align-items:stretch;">
            <div class="small-box booking-stat-box booking-stat-box--compact">
                <span class="profile-label">Всего бронирований</span>
                <div class="booking-stat-value"><?= $totalBookings ?></div>
            </div>

            <div class="small-box booking-stat-box booking-stat-box--compact">
                <span class="profile-label">Общее количество часов</span>
                <div class="booking-stat-value"><?= $totalHours ?></div>
            </div>

            <div class="small-box booking-stat-box">
                <span class="profile-label">Ближайшая сессия</span>
                <div class="booking-stat-session"><?= htmlspecialchars($nextBookingLabel) ?></div>
                <div class="booking-stat-note"><?= htmlspecialchars($nearestDatePriceLabel) ?></div>
            </div>

            <div class="small-box booking-stat-box">
                <span class="profile-label">Итоговая цена</span>
                <div class="booking-stat-price"><?= number_format($totalPrice, 2, '.', ' ') ?> руб.</div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="table-card">
            <div class="card-actions" style="margin-bottom: 20px;">
                <a class="btn btn-primary" href="memory.php">Открыть корзину</a>
                <a class="btn btn-secondary" href="profile.php">Перейти в личный кабинет</a>
            </div>

            <?php if ($totalBookings > 0) { ?>
                <div class="table-wrap">
                    <table>
                        <tr>
                            <th>ID</th>
                            <th>Игровое место</th>
                            <th>Зона</th>
                            <th>Клуб</th>
                            <th>Тариф</th>
                            <th>Цена/час</th>
                            <th>Дата</th>
                            <th>Часы</th>
                            <th>Отмена</th>
                        </tr>

                        <?php foreach ($bookings as $row) { ?>
                            <tr>
                                <td><?= (int) $row['id'] ?></td>

                                <td>
                                    <div style="font-weight:700; margin-bottom:8px;">
                                        <?= htmlspecialchars($row['pc_name']) ?>
                                    </div>

                                    <span class="badge <?= (int)$row['is_vip'] === 1 ? 'badge-vip' : 'badge-regular' ?>">
                                        <?= (int)$row['is_vip'] === 1 ? 'VIP' : 'STANDARD' ?>
                                    </span>
                                </td>

                                <td><?= htmlspecialchars($row['zone_name']) ?></td>
                                <td><?= htmlspecialchars($row['club_name']) ?></td>
                                <td><?= htmlspecialchars($row['tariff_name']) ?></td>

                                <td>
                                    <span style="
                                        display:inline-block;
                                        font-weight:800;
                                        font-size:18px;
                                        color:#ffffff;
                                        white-space:nowrap;
                                        text-shadow:0 0 12px rgba(124, 92, 255, 0.18);
                                    ">
                                        <?= htmlspecialchars(number_format((float) $row['price_per_hour'], 2, '.', ' ')) ?> руб.
                                    </span>
                                </td>

                                <td><?= htmlspecialchars(format_booking_date_ru($row['booking_date'])) ?><br><span class="muted"><?= htmlspecialchars(substr((string)($row['booking_time'] ?? '12:00'), 0, 5)) ?></span></td>
                                <td><?= (int) $row['hours'] ?></td>

                                <td>
                                    <a class="btn btn-danger" href="bookings.php?cancel=<?= (int) $row['id'] ?>">Отменить</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
            <?php } else { ?>
                <div class="small-box" style="
                    margin-bottom:0;
                    text-align:center;
                    padding:42px 24px;
                ">
                    <div style="font-size:24px; font-weight:800; margin-bottom:10px;">У вас пока нет подтверждённых бронирований</div>
                    <div class="note" style="max-width:720px; margin:0 auto 22px;">
                        Перейдите к выбору игровых мест, добавьте нужные позиции в корзину
                        и оформите свою первую бронь онлайн.
                    </div>

                    <div class="card-actions" style="justify-content:center;">
                        <a class="btn btn-primary" href="index.php#catalog">Выбрать игровое место</a>
                        <a class="btn btn-secondary" href="memory.php">Открыть корзину</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php
mysqli_stmt_close($stmt);
require_once __DIR__ . '/footer.php';
?>
