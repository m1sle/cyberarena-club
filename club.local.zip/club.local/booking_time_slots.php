<?php
require_once __DIR__ . '/bootstrap.php';
require_login('login.php');

header('Content-Type: application/json; charset=UTF-8');

function response_json(array $data): void
{
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$date = raw_clean($_GET['date'] ?? date('Y-m-d'));
$hours = normalize_booking_duration($_GET['hours'] ?? 1);
$computerId = isset($_GET['computer_id']) ? (int) $_GET['computer_id'] : 0;
$serviceName = raw_clean($_GET['service_name'] ?? '');

if (!is_valid_date($date) || !is_valid_booking_duration($hours)) {
    response_json([
        'ok' => false,
        'disabled' => [],
        'message' => 'Некорректная дата или длительность.',
    ]);
}

if ($computerId <= 0 && $serviceName !== '') {
    $sql = "
        SELECT c.id
        FROM computers c
        JOIN zones z ON c.zone_id = z.id
        JOIN tariffs t ON c.tariff_id = t.id
        WHERE CONCAT(c.pc_name, ' / ', z.zone_name, ' / ', t.tariff_name) = ?
        LIMIT 1
    ";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
        response_json(['ok' => false, 'disabled' => [], 'message' => 'Не удалось найти игровое место.']);
    }

    mysqli_stmt_bind_param($stmt, 's', $serviceName);
    if (!mysqli_stmt_execute($stmt)) {
        logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
        mysqli_stmt_close($stmt);
        response_json(['ok' => false, 'disabled' => [], 'message' => 'Не удалось найти игровое место.']);
    }

    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    $computerId = $row ? (int) $row['id'] : 0;
}

if ($computerId <= 0) {
    response_json([
        'ok' => true,
        'disabled' => [],
        'message' => 'Игровое место не выбрано.',
    ]);
}

$sqlComputer = 'SELECT is_maintenance, is_active FROM computers WHERE id = ? LIMIT 1';
$stmtComputer = mysqli_prepare($conn, $sqlComputer);
if (!$stmtComputer) {
    logMysqliError($conn, 'mysqli_prepare', $sqlComputer, __FILE__, __LINE__);
    response_json(['ok' => false, 'disabled' => [], 'message' => 'Не удалось проверить игровое место.']);
}

mysqli_stmt_bind_param($stmtComputer, 'i', $computerId);
if (!mysqli_stmt_execute($stmtComputer)) {
    logMysqliStmtError($stmtComputer, 'mysqli_stmt_execute', $sqlComputer, __FILE__, __LINE__);
    mysqli_stmt_close($stmtComputer);
    response_json(['ok' => false, 'disabled' => [], 'message' => 'Не удалось проверить игровое место.']);
}

$computerResult = mysqli_stmt_get_result($stmtComputer);
$computer = $computerResult ? mysqli_fetch_assoc($computerResult) : null;
mysqli_stmt_close($stmtComputer);

$disabled = [];
foreach (range(0, 23) as $hour) {
    foreach ([0, 15, 30, 45] as $minute) {
        $slot = sprintf('%02d:%02d', $hour, $minute);
        if (!$computer || (int) $computer['is_active'] !== 1 || (int) $computer['is_maintenance'] === 1) {
            $disabled[] = $slot;
            continue;
        }

        if (get_booking_interval_conflict($conn, $computerId, $date, $slot, $hours) !== null) {
            $disabled[] = $slot;
        }
    }
}

response_json([
    'ok' => true,
    'disabled' => $disabled,
]);
