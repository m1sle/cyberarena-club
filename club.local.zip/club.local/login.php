<?php
require_once __DIR__ . '/bootstrap.php';

if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Вход | CyberArena';
$errors = [];
$login = isset($_SESSION['last_registered_login']) ? (string) $_SESSION['last_registered_login'] : '';
unset($_SESSION['last_registered_login']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = raw_clean($_POST['login'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($login === '') {
        $errors[] = 'Введите логин.';
    }

    if ($password === '') {
        $errors[] = 'Введите пароль.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'SELECT id, password_hash FROM users WHERE login = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 's', $login);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors[] = 'Неверный логин или пароль.';
        } else {
            refresh_user_session($conn, (int) $user['id']);
            set_flash('success', 'Вы успешно вошли в аккаунт.');
            header('Location: index.php');
            exit;
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container auth-shell">
        <div class="auth-card auth-card-modern auth-card-login-clean">
            <h1>Авторизация</h1>
            <p class="note auth-lead">
                Для входа используйте свой логин и пароль. Логин — это ваш никнейм, а не e-mail.
            </p>

            <?php if ($errors) { ?>
                <ul class="error-list">
                    <?php foreach ($errors as $error) { ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <form method="post" class="auth-form-grid auth-form-login-clean">
                <div class="field">
                    <label for="login">Логин</label>
                    <input
                        type="text"
                        id="login"
                        name="login"
                        value="<?= htmlspecialchars($login) ?>"
                        minlength="4"
                        maxlength="12"
                        autocomplete="username"
                        required
                    >
                    <div class="helper-text">Введите свой никнейм, который указывали при регистрации</div>
                </div>

                <div class="field">
                    <label for="password">Пароль</label>
                    <div class="password-field-wrap">
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="password-input"
                            autocomplete="current-password"
                            required
                        >
                        <button type="button" class="password-toggle-plain" data-target="password" aria-label="Показать пароль">👁</button>
                    </div>
                </div>

                <div class="auth-actions">
                    <button type="submit" class="btn btn-primary">Войти</button>
                    <a href="register.php" class="btn btn-secondary">Регистрация</a>
                </div>
            </form>
        </div>
    </div>
</section>

<script>
(function () {
    const toggles = document.querySelectorAll('.password-toggle-plain');

    toggles.forEach(function (button) {
        button.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);

            if (!input) return;

            const isPassword = input.getAttribute('type') === 'password';
            input.setAttribute('type', isPassword ? 'text' : 'password');
            this.classList.toggle('active', isPassword);
            this.setAttribute('aria-label', isPassword ? 'Скрыть пароль' : 'Показать пароль');
        });
    });
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
