<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$context = preg_replace('/[^a-z0-9_]/i', '', $_GET['context'] ?? 'register');
if ($context === '') {
    $context = 'register';
}

$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$code = '';
for ($i = 0; $i < 5; $i++) {
    $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
}

$_SESSION[$context . '_captcha_code'] = $code;

header('Content-Type: image/svg+xml; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$chars = str_split($code);
$x = 28;
$charSvg = '';
foreach ($chars as $char) {
    $rotation = random_int(-12, 12);
    $y = random_int(38, 54);
    $charSvg .= '<text x="' . $x . '" y="' . $y . '" transform="rotate(' . $rotation . ' ' . $x . ' ' . $y . ')" font-family="Arial, sans-serif" font-size="30" font-weight="700" fill="#ecf3ff">' . $char . '</text>';
    $x += random_int(30, 38);
}

$noise = '';
for ($i = 0; $i < 6; $i++) {
    $x1 = random_int(0, 190);
    $y1 = random_int(0, 70);
    $x2 = random_int(0, 190);
    $y2 = random_int(0, 70);
    $opacity = random_int(10, 30) / 100;
    $color = $i % 2 === 0 ? '#6f86ff' : '#79ffc1';
    $noise .= '<line x1="' . $x1 . '" y1="' . $y1 . '" x2="' . $x2 . '" y2="' . $y2 . '" stroke="' . $color . '" stroke-width="1.2" opacity="' . $opacity . '" />';
}

$dots = '';
for ($i = 0; $i < 18; $i++) {
    $cx = random_int(6, 194);
    $cy = random_int(6, 64);
    $r = random_int(1, 2);
    $opacity = random_int(12, 26) / 100;
    $color = $i % 2 === 0 ? '#8d5dff' : '#5d7cff';
    $dots .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" fill="' . $color . '" opacity="' . $opacity . '" />';
}

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="70" viewBox="0 0 200 70" role="img" aria-label="Captcha">';
echo '<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0a122d"/><stop offset="100%" stop-color="#151f3f"/></linearGradient></defs>';
echo '<rect width="200" height="70" rx="16" fill="url(#bg)" />';
echo '<rect x="1" y="1" width="198" height="68" rx="15" fill="none" stroke="rgba(111,134,255,0.28)" />';
echo $noise;
echo $dots;
echo $charSvg;
echo '</svg>';
