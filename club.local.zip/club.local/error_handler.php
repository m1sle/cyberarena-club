<?php
if (defined('CYBERARENA_ERROR_HANDLER_LOADED')) {
    return;
}
define('CYBERARENA_ERROR_HANDLER_LOADED', true);

define('CYBERARENA_ERROR_LOG_DIR', __DIR__ . '/logs');
define('CYBERARENA_ERROR_LOG_FILE', CYBERARENA_ERROR_LOG_DIR . '/error_log.xml');

function cyberarena_error_type_label(int $errno): string
{
    $map = [
        E_ERROR => 'Ошибка',
        E_WARNING => 'Предупреждение',
        E_PARSE => 'Ошибка разбора исходного кода',
        E_NOTICE => 'Уведомление',
        E_CORE_ERROR => 'Ошибка ядра',
        E_CORE_WARNING => 'Предупреждение ядра',
        E_COMPILE_ERROR => 'Ошибка на этапе компиляции',
        E_COMPILE_WARNING => 'Предупреждение на этапе компиляции',
        E_USER_ERROR => 'Пользовательская ошибка',
        E_USER_WARNING => 'Пользовательское предупреждение',
        E_USER_NOTICE => 'Пользовательское уведомление',
        E_STRICT => 'Уведомление времени выполнения',
        E_RECOVERABLE_ERROR => 'Отлавливаемая фатальная ошибка',
        E_DEPRECATED => 'Устаревшая функция',
        E_USER_DEPRECATED => 'Пользовательское уведомление об устаревании',
    ];

    return $map[$errno] ?? 'Неизвестная ошибка';
}

function cyberarena_ensure_error_log_storage(): void
{
    if (!is_dir(CYBERARENA_ERROR_LOG_DIR)) {
        @mkdir(CYBERARENA_ERROR_LOG_DIR, 0777, true);
    }

    if (!file_exists(CYBERARENA_ERROR_LOG_FILE)) {
        @file_put_contents(CYBERARENA_ERROR_LOG_FILE, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<errorlog>\n</errorlog>\n");
    }
}

function cyberarena_append_error_entry(array $entry): void
{
    cyberarena_ensure_error_log_storage();

    $entryXml = "  <errorentry>\n"
        . '    <datetime>' . htmlspecialchars((string) ($entry['datetime'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</datetime>\n"
        . '    <errornum>' . htmlspecialchars((string) ($entry['errornum'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</errornum>\n"
        . '    <errortype>' . htmlspecialchars((string) ($entry['errortype'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</errortype>\n"
        . '    <errormsg>' . htmlspecialchars((string) ($entry['errormsg'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</errormsg>\n"
        . '    <scriptname>' . htmlspecialchars((string) ($entry['scriptname'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</scriptname>\n"
        . '    <scriptlinenum>' . htmlspecialchars((string) ($entry['scriptlinenum'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</scriptlinenum>\n"
        . "  </errorentry>\n";

    $content = @file_get_contents(CYBERARENA_ERROR_LOG_FILE);
    if ($content === false || trim($content) === '') {
        $content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<errorlog>\n</errorlog>\n";
    }

    $updated = str_replace("</errorlog>", $entryXml . "</errorlog>", $content);
    @file_put_contents(CYBERARENA_ERROR_LOG_FILE, $updated, LOCK_EX);
}

function cyberarena_log_error_event(int $errno, string $message, string $file, int $line): void
{
    cyberarena_append_error_entry([
        'datetime' => date('Y-m-d H:i:s T'),
        'errornum' => $errno,
        'errortype' => cyberarena_error_type_label($errno),
        'errormsg' => $message,
        'scriptname' => $file,
        'scriptlinenum' => $line,
    ]);
}

function cyberarena_render_friendly_system_error(): void
{
    if (!headers_sent()) {
        http_response_code(500);
    }

    echo '<!doctype html><html lang="ru"><head><meta charset="UTF-8"><title>Ошибка системы</title>';
    echo '<style>body{margin:0;font-family:Arial,sans-serif;background:#050b1f;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px}';
    echo '.box{max-width:640px;width:100%;background:linear-gradient(180deg,#16203f,#0b1430);border:1px solid rgba(255,255,255,.09);border-radius:24px;padding:32px;box-shadow:0 20px 40px rgba(0,0,0,.35)}';
    echo 'h1{margin:0 0 14px;font-size:34px}p{margin:0 0 12px;font-size:18px;line-height:1.55;color:#cfd6f8}</style></head><body>';
    echo '<div class="box"><h1>Произошла ошибка</h1><p>Система временно не может обработать запрос. Попробуйте обновить страницу или повторите действие позже.</p><p>Подробности сохранены во внутреннем журнале ошибок.</p></div></body></html>';
    exit;
}

function cyberarena_php_error_handler(int $errno, string $errstr, string $errfile, int $errline): bool
{
    cyberarena_log_error_event($errno, $errstr, $errfile, $errline);
    return true;
}

function cyberarena_exception_handler(Throwable $exception): void
{
    cyberarena_log_error_event(E_USER_ERROR, $exception->getMessage(), $exception->getFile(), $exception->getLine());
    cyberarena_render_friendly_system_error();
}

function cyberarena_shutdown_handler(): void
{
    $error = error_get_last();
    if (!$error) {
        return;
    }

    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR];
    if (in_array($error['type'], $fatalTypes, true)) {
        cyberarena_log_error_event((int) $error['type'], (string) $error['message'], (string) $error['file'], (int) $error['line']);
        cyberarena_render_friendly_system_error();
    }
}

function cyberarena_register_error_handler(): void
{
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '0');
    set_error_handler('cyberarena_php_error_handler');
    set_exception_handler('cyberarena_exception_handler');
    register_shutdown_function('cyberarena_shutdown_handler');
}

function cyberarena_db_prepare(mysqli $conn, string $sql, string $userMessage = 'Не удалось подготовить запрос к базе данных.'): mysqli_stmt
{
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        trigger_error('Ошибка подготовки запроса к БД: ' . mysqli_error($conn), E_USER_WARNING);
        throw new RuntimeException($userMessage);
    }

    return $stmt;
}

function cyberarena_stmt_bind(mysqli_stmt $stmt, string $types, &...$vars): void
{
    if (!mysqli_stmt_bind_param($stmt, $types, ...$vars)) {
        trigger_error('Ошибка связывания параметров: ' . mysqli_stmt_error($stmt), E_USER_WARNING);
        throw new RuntimeException('Не удалось обработать введённые данные.');
    }
}

function cyberarena_stmt_execute(mysqli_stmt $stmt, string $userMessage = 'Не удалось выполнить запрос к базе данных.'): void
{
    if (!mysqli_stmt_execute($stmt)) {
        trigger_error('Ошибка выполнения запроса к БД: ' . mysqli_stmt_error($stmt), E_USER_WARNING);
        throw new RuntimeException($userMessage);
    }
}
