<?php
require_once __DIR__ . '/bootstrap.php';

$id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    die('Некорректный ID игрового места.');
}

$pageTitle = 'Игровое место | CyberArena';
$current_page = 'details.php';
$errors = [];

$query = "
    SELECT
        c.id,
        c.pc_name,
        c.cpu,
        c.gpu,
        c.ram,
        c.monitor_hz,
        c.monitor_model,
        c.keyboard_model,
        c.mouse_model,
        c.headset_model,
        c.chair_model,
        c.release_year,
        c.photo,
        c.is_vip,
        z.zone_name,
        cl.club_name,
        cl.address,
        t.tariff_name,
        t.price_per_hour
    FROM computers c
    JOIN zones z ON c.zone_id = z.id
    JOIN clubs cl ON z.club_id = cl.id
    JOIN tariffs t ON c.tariff_id = t.id
    WHERE c.id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$data) {
    die('Игровое место не найдено.');
}

$serviceLabel = $data['pc_name'] . ' / ' . $data['zone_name'] . ' / ' . $data['tariff_name'];
$today = date('Y-m-d');

$isBootcamp = stripos($data['zone_name'], 'Bootcamp') !== false;
$isVip = (int) $data['is_vip'] === 1;

$gameTags = $isVip
    ? ['CS2', 'Dota 2', 'Valorant', 'Warzone']
    : ['CS2', 'Dota 2', 'Valorant', 'Apex'];

$promoText = $isVip
    ? 'Премиум-выбор для длинных игровых сессий, компании друзей и максимального комфорта.'
    : 'Оптимальный выбор для вечерней игры, тренировок и быстрых онлайн-бронирований.';

$monitorHz = !empty($data['monitor_hz'])
    ? (int) $data['monitor_hz']
    : ($isVip ? 500 : ($isBootcamp ? 300 : 165));

$monitorModel = trim((string) ($data['monitor_model'] ?? ''));
if ($monitorModel === '') {
    $monitorModel = $isVip
        ? 'Acer XV252Q 24.5" 500Hz'
        : ($isBootcamp ? 'Acer XV272U 27" 300Hz' : 'AOC 24G2SPAE 24" 165Hz');
}

$keyboardModel = trim((string) ($data['keyboard_model'] ?? ''));
if ($keyboardModel === '') {
    $keyboardModel = $isVip
        ? 'Wooting 60HE+'
        : ($isBootcamp ? 'Dark Project KD87A' : 'Dark Project KD87A');
}

$mouseModel = trim((string) ($data['mouse_model'] ?? ''));
if ($mouseModel === '') {
    $mouseModel = $isVip
        ? 'Lamzu Maya X Super Light 8K'
        : ($isBootcamp ? 'Logitech G Pro X Superlight' : 'Logitech G Pro X Superlight');
}

$headsetModel = trim((string) ($data['headset_model'] ?? ''));
if ($headsetModel === '') {
    $headsetModel = $isVip
        ? 'Logitech G Pro X'
        : ($isBootcamp ? 'HyperX Cloud Alpha' : 'HyperX Cloud Alpha');
}

$chairModel = trim((string) ($data['chair_model'] ?? ''));
if ($chairModel === '') {
    $chairModel = $isVip
        ? 'BRAVE'
        : ($isBootcamp ? 'Cougar Armor One' : 'Cougar Armor One');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_add'])) {
    require_login('login.php');

    $bookingDate = raw_clean($_POST['booking_date'] ?? '');
    $hours = (int) ($_POST['hours'] ?? 0);

    if (!is_valid_date($bookingDate) || $bookingDate < $today) {
        $errors[] = 'Укажите корректную дату бронирования. Прошедшие дни выбирать нельзя.';
    }

    if ($hours <= 0 || $hours > 24) {
        $errors[] = 'Количество часов должно быть от 1 до 24.';
    }

    if (!$errors) {
        $user = current_user();

        add_cart_item([
            'client_name' => $user['full_name'],
            'phone' => $user['phone'],
            'service_name' => $serviceLabel,
            'booking_date' => $bookingDate,
            'hours' => $hours,
        ]);

        set_flash('success', 'Игровое место добавлено в корзину.');
        header('Location: memory.php');
        exit;
    }
}

function icon_cpu() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="7" y="7" width="10" height="10" rx="1.5" stroke="currentColor" stroke-width="1.8"/>
        <path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M5 19l1.5-1.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_gpu() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="7" width="15" height="10" rx="2" stroke="currentColor" stroke-width="1.8"/>
        <circle cx="8" cy="12" r="2.2" stroke="currentColor" stroke-width="1.8"/>
        <circle cx="14" cy="12" r="2.2" stroke="currentColor" stroke-width="1.8"/>
        <path d="M18 10h2M18 14h2M7 18v2M13 18v2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_ram() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="8" width="18" height="8" rx="2" stroke="currentColor" stroke-width="1.8"/>
        <path d="M7 10v4M11 10v4M15 10v4M19 10v4M6 16v2M10 16v2M14 16v2M18 16v2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_monitor() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="4" y="5" width="16" height="11" rx="2" stroke="currentColor" stroke-width="1.8"/>
        <path d="M9 20h6M12 16v4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_keyboard() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="7" width="18" height="10" rx="2" stroke="currentColor" stroke-width="1.8"/>
        <path d="M6 10h1M9 10h1M12 10h1M15 10h1M18 10h1M6 13h1M9 13h1M12 13h1M15 13h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_mouse() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="8" y="3" width="8" height="18" rx="4" stroke="currentColor" stroke-width="1.8"/>
        <path d="M12 3v6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_headset() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M5 12a7 7 0 0 1 14 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
        <rect x="4" y="12" width="3.5" height="6" rx="1.2" stroke="currentColor" stroke-width="1.8"/>
        <rect x="16.5" y="12" width="3.5" height="6" rx="1.2" stroke="currentColor" stroke-width="1.8"/>
        <path d="M20 18v1a2 2 0 0 1-2 2h-2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_chair() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M9 4h6v5a3 3 0 0 1-6 0V4Z" stroke="currentColor" stroke-width="1.8"/>
        <path d="M7 14a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v2H7v-2Z" stroke="currentColor" stroke-width="1.8"/>
        <path d="M12 16v4M8 20h8M6 22l2-2M18 22l-2-2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    </svg>';
}

function icon_club() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M4 20h16M6 20V9l6-4 6 4v11M9 12h2v2H9v-2ZM13 12h2v2h-2v-2Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>';
}

function icon_geo() {
    return '
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 21s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11Z" stroke="currentColor" stroke-width="1.8"/>
        <circle cx="12" cy="10" r="2.2" stroke="currentColor" stroke-width="1.8"/>
    </svg>';
}

require_once __DIR__ . '/header.php';
?>

<style>
.details-vip-upgrade {
    --blue-main: #6f86ff;
    --blue-soft: rgba(111, 134, 255, 0.16);
    --violet-main: #8d5dff;
    --violet-soft: rgba(141, 93, 255, 0.18);
    --vip-rose: #ff5f7a;
    --green-main: #79ffc1;
    --green-soft: rgba(89, 188, 89, 0.14);
    --green-line: rgba(89, 188, 89, 0.25);
    --line-soft: rgba(255, 255, 255, 0.08);
    --card-deep: #09112a;
    --text-soft: #cbd5f1;
    --icon-gold: #f0c85b;
}

.details-vip-upgrade .details-shell {
    position: relative;
}

.details-vip-upgrade .floating-back-button {
    position: absolute;
    left: -185px;
    top: 18px;
    z-index: 5;
}

.details-vip-upgrade .neon-back-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    min-width: 164px;
    padding: 12px 18px;
    border-radius: 18px;
    text-decoration: none;
    color: #eef2ff;
    font-weight: 800;
    background: linear-gradient(135deg, rgba(9, 17, 42, 0.86), rgba(18, 26, 49, 0.94));
    border: 1px solid rgba(111, 134, 255, 0.16);
    box-shadow:
        0 0 0 1px rgba(111, 134, 255, 0.04),
        0 0 18px rgba(111, 134, 255, 0.08),
        0 0 28px rgba(141, 93, 255, 0.06);
    transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
}

.details-vip-upgrade .neon-back-link:hover {
    transform: translateY(-2px);
    border-color: rgba(141, 93, 255, 0.26);
    box-shadow:
        0 0 0 1px rgba(141, 93, 255, 0.05),
        0 0 20px rgba(111, 134, 255, 0.10),
        0 0 32px rgba(141, 93, 255, 0.10);
}

.details-vip-upgrade .neon-back-arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    border-radius: 999px;
    background: linear-gradient(135deg, rgba(111, 134, 255, 0.18), rgba(141, 93, 255, 0.18));
    color: #b7c5ff;
    font-size: 14px;
    line-height: 1;
    box-shadow: 0 0 14px rgba(141, 93, 255, 0.08);
}

.details-vip-upgrade .pc-detail-card {
    box-shadow:
        0 12px 32px rgba(0, 0, 0, 0.22),
        0 0 26px rgba(111, 134, 255, 0.06),
        0 0 36px rgba(141, 93, 255, 0.05);
}

.details-vip-upgrade .details-layout-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.05fr) minmax(0, 0.95fr);
    gap: 18px;
    align-items: stretch;
}

.details-vip-upgrade .hero-image-box {
    position: relative;
    border-radius: 24px;
    overflow: hidden;
    background: #0b1228;
    border: 1px solid rgba(255,255,255,0.06);
    box-shadow:
        0 0 0 1px rgba(111, 134, 255, 0.10),
        0 0 30px rgba(141, 93, 255, 0.10);
}

.details-vip-upgrade .hero-image-box.vip-mode {
    box-shadow:
        0 0 0 1px rgba(255, 95, 122, 0.14),
        0 0 28px rgba(255, 95, 122, 0.10),
        0 0 38px rgba(141, 93, 255, 0.10);
}

.details-vip-upgrade .hero-image-box img {
    width: 100%;
    display: block;
    border-radius: 24px;
    object-fit: cover;
    max-height: 520px;
}

.details-vip-upgrade .hero-image-badge {
    position: absolute;
    top: 16px;
    left: 16px;
    z-index: 4;
    padding: 10px 15px;
    border-radius: 999px;
    color: #fff;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 0.05em;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(9, 17, 42, 0.86);
}

.details-vip-upgrade .hero-image-badge.vip-mode {
    background: linear-gradient(135deg, rgba(255, 95, 122, 0.88), rgba(141, 93, 255, 0.88));
    box-shadow: 0 0 22px rgba(255, 95, 122, 0.20);
}

.details-vip-upgrade .hero-image-badge.standard-mode {
    box-shadow: 0 0 18px rgba(111, 134, 255, 0.12);
}

.details-vip-upgrade .top-content {
    align-self: start;
}

.details-vip-upgrade .top-content h1 {
    margin: 0 0 14px;
    font-size: 54px;
    line-height: 1.02;
}

.details-vip-upgrade .page-kicker {
    display: inline-flex;
    align-items: center;
    padding: 8px 14px;
    border-radius: 999px;
    background: linear-gradient(135deg, rgba(111,134,255,0.14), rgba(141,93,255,0.14));
    border: 1px solid rgba(111,134,255,0.18);
    color: #dce5ff;
    font-size: 14px;
    font-weight: 700;
    margin-bottom: 14px;
}

.details-vip-upgrade .top-promo {
    color: var(--text-soft);
    font-size: 18px;
    line-height: 1.65;
    margin-bottom: 18px;
}

.details-vip-upgrade .badges-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 18px;
}

.details-vip-upgrade .vip-badge-custom {
    display: inline-flex;
    align-items: center;
    padding: 10px 15px;
    border-radius: 999px;
    font-size: 14px;
    font-weight: 800;
    color: #fff;
    border: 1px solid rgba(255,255,255,0.08);
}

.details-vip-upgrade .vip-badge-custom.vip-mode {
    background: linear-gradient(135deg, #ff5f7a, #8d5dff);
    box-shadow: 0 0 20px rgba(255, 95, 122, 0.16);
}

.details-vip-upgrade .vip-badge-custom.standard-mode {
    background: linear-gradient(135deg, rgba(111,134,255,0.18), rgba(141,93,255,0.14));
    color: #eef2ff;
}

.details-vip-upgrade .online-badge {
    display: inline-flex;
    align-items: center;
    padding: 10px 15px;
    border-radius: 999px;
    background: var(--green-soft);
    border: 1px solid var(--green-line);
    color: #e1ffe4;
    font-size: 14px;
    font-weight: 700;
}

.details-vip-upgrade .price-card {
    padding: 24px 26px;
    border-radius: 24px;
    border: 1px solid rgba(111, 134, 255, 0.18);
    background: linear-gradient(135deg, rgba(111, 134, 255, 0.18), rgba(141, 93, 255, 0.14));
    box-shadow:
        0 0 0 1px rgba(111, 134, 255, 0.06),
        0 0 28px rgba(141, 93, 255, 0.08);
}

.details-vip-upgrade .price-card.vip-mode {
    border: 1px solid rgba(255, 95, 122, 0.18);
    background: linear-gradient(135deg, rgba(111, 134, 255, 0.16), rgba(141, 93, 255, 0.18), rgba(255, 95, 122, 0.12));
    box-shadow:
        0 0 0 1px rgba(255, 95, 122, 0.06),
        0 0 26px rgba(255, 95, 122, 0.08),
        0 0 34px rgba(141, 93, 255, 0.10);
}

.details-vip-upgrade .price-value {
    font-size: 68px;
    font-weight: 900;
    line-height: 1;
    color: #fff;
}

.details-vip-upgrade .price-note {
    margin-top: 8px;
    color: #dce5ff;
    font-size: 17px;
}

.details-vip-upgrade .summary-left,
.details-vip-upgrade .summary-right,
.details-vip-upgrade .config-panel,
.details-vip-upgrade .periphery-panel {
    height: 100%;
}

.details-vip-upgrade .summary-left {
    display: grid;
    gap: 18px;
    align-content: start;
}

.details-vip-upgrade .games-box,
.details-vip-upgrade .quick-booking-card,
.details-vip-upgrade .info-panel,
.details-vip-upgrade .meta-box {
    background: var(--card-deep);
}

.details-vip-upgrade .games-box {
    padding: 18px 20px;
    border-radius: 18px;
    border: 1px solid var(--line-soft);
}

.details-vip-upgrade .games-box strong {
    display: block;
    margin-bottom: 12px;
    font-size: 18px;
}

.details-vip-upgrade .tag-list {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.details-vip-upgrade .tag-chip {
    padding: 10px 14px;
    border-radius: 999px;
    color: #eef2ff;
    font-size: 14px;
    font-weight: 700;
    background: linear-gradient(135deg, rgba(111,134,255,0.16), rgba(141,93,255,0.14));
    border: 1px solid rgba(111,134,255,0.18);
}

.details-vip-upgrade .tag-chip.vip-mode {
    background: linear-gradient(135deg, rgba(111,134,255,0.14), rgba(141,93,255,0.16), rgba(255,95,122,0.12));
    border: 1px solid rgba(255,95,122,0.12);
}

.details-vip-upgrade .meta-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
}

.details-vip-upgrade .meta-box {
    border-radius: 18px;
    padding: 16px 18px;
    border: 1px solid var(--line-soft);
    min-height: 108px;
}

.details-vip-upgrade .meta-box.vip-monitor {
    border: 1px solid rgba(255, 95, 122, 0.14);
    box-shadow: 0 0 18px rgba(255, 95, 122, 0.06);
}

.details-vip-upgrade .meta-box span {
    display: block;
    margin-bottom: 8px;
    color: #9fb7ff;
    font-size: 13px;
    font-weight: 700;
}

.details-vip-upgrade .meta-box strong {
    color: #fff;
    font-size: 17px;
    line-height: 1.45;
}

.details-vip-upgrade .summary-right {
    display: flex;
}

.details-vip-upgrade .quick-booking-card {
    width: 100%;
    padding: 24px 20px;
    border-radius: 22px;
    background: linear-gradient(180deg, rgba(18,26,49,0.96), rgba(9,17,42,0.96));
    border: 1px solid rgba(111,134,255,0.16);
    box-shadow: 0 0 24px rgba(111,134,255,0.05);
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.details-vip-upgrade .quick-booking-card.vip-mode {
    border: 1px solid rgba(255, 95, 122, 0.12);
    box-shadow:
        0 0 18px rgba(255, 95, 122, 0.05),
        0 0 24px rgba(141, 93, 255, 0.06);
}

.details-vip-upgrade .quick-booking-spacer {
    height: 38px;
    width: 100%;
    margin-bottom: 10px;
}

.details-vip-upgrade .quick-booking-card h3,
.details-vip-upgrade .quick-booking-title {
    margin: 0 0 18px;
    font-size: 32px;
    line-height: 1.08;
}

.details-vip-upgrade .quick-grid {
    display: grid;
    grid-template-columns: 210px 78px 190px;
    gap: 14px;
    align-items: end;
}

.details-vip-upgrade .quick-grid .field {
    min-width: 0;
}

.details-vip-upgrade .quick-grid label {
    display: block;
    margin-bottom: 8px;
    line-height: 1.2;
}

.details-vip-upgrade .quick-grid .booking-date-field input {
    width: 100%;
    min-width: 0;
}

.details-vip-upgrade .quick-grid .booking-hours-field input {
    width: 100%;
    min-width: 0;
    max-width: 78px;
    text-align: left;
}

.details-vip-upgrade .quick-grid .auth-actions {
    margin-top: 0;
}

.details-vip-upgrade .quick-grid .btn {
    width: 190px;
    min-width: 190px;
    padding-left: 16px;
    padding-right: 16px;
    white-space: nowrap;
}

.details-vip-upgrade input[type="date"]::-webkit-calendar-picker-indicator {
    opacity: 1;
    cursor: pointer;
    filter: brightness(0) saturate(100%) invert(84%) sepia(16%) saturate(1168%) hue-rotate(89deg) brightness(104%) contrast(101%);
}

.details-vip-upgrade input[type="date"] {
    color-scheme: dark;
}

.details-vip-upgrade .info-panel {
    border-radius: 22px;
    padding: 22px 22px 18px;
    border: 1px solid var(--line-soft);
    min-height: 100%;
}

.details-vip-upgrade .info-panel h3 {
    margin: 0 0 18px;
    font-size: 22px;
}

.details-vip-upgrade .icon-list {
    display: grid;
    gap: 16px;
}

.details-vip-upgrade .icon-item {
    display: grid;
    grid-template-columns: 42px 1fr;
    gap: 14px;
    align-items: start;
}

.details-vip-upgrade .icon-wrap {
    width: 42px;
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--icon-gold);
}

.details-vip-upgrade .icon-wrap svg {
    width: 30px;
    height: 30px;
    display: block;
}

.details-vip-upgrade .icon-text strong {
    display: block;
    margin-bottom: 4px;
    color: #e9eeff;
    font-size: 15px;
}

.details-vip-upgrade .icon-text span {
    display: block;
    color: var(--text-soft);
    line-height: 1.55;
    font-size: 15px;
}

.details-vip-upgrade .mini-note {
    margin-top: 20px;
    color: #d7e2ff;
    font-size: 15px;
    line-height: 1.6;
}

@media (max-width: 1500px) {
    .details-vip-upgrade .floating-back-button {
        position: static;
        margin-bottom: 14px;
    }
}

@media (max-width: 1200px) {
    .details-vip-upgrade .details-layout-grid,
    .details-vip-upgrade .meta-grid,
    .details-vip-upgrade .quick-grid {
        grid-template-columns: 1fr;
    }

    .details-vip-upgrade .top-content h1 {
        font-size: 42px;
    }

    .details-vip-upgrade .quick-grid .booking-hours-field input,
    .details-vip-upgrade .quick-grid .btn,
    .details-vip-upgrade .neon-back-link {
        max-width: 100%;
        width: 100%;
        min-width: 0;
    }

    .details-vip-upgrade .summary-right {
        display: block;
    }
}
</style>

<section class="section details-vip-upgrade">
    <div class="container">
        <div class="details-shell">
            <div class="floating-back-button">
                <a class="neon-back-link" href="index.php#catalog">
                    <span class="neon-back-arrow">←</span>
                    <span>В каталог</span>
                </a>
            </div>

            <div class="pc-detail-card">
                <div class="details-layout-grid">

                    <!-- 1 ряд -->
                    <div class="hero-image-box <?= $isVip ? 'vip-mode' : '' ?>">
                        <div class="hero-image-badge <?= $isVip ? 'vip-mode' : 'standard-mode' ?>">
                            <?= $isVip ? 'VIP' : 'STANDARD' ?>
                        </div>
                        <img src="images/<?= htmlspecialchars($data['photo']) ?>" alt="Фото ПК" onerror="this.src='images/noimage.jpg'">
                    </div>

                    <div class="top-content">
                        <div class="page-kicker">Игровое место CyberArena</div>
                        <h1><?= htmlspecialchars($data['pc_name']) ?></h1>
                        <p class="top-promo"><?= htmlspecialchars($promoText) ?></p>

                        <div class="badges-row">
                            <span class="vip-badge-custom <?= $isVip ? 'vip-mode' : 'standard-mode' ?>">
                                <?= $isVip ? 'VIP место' : 'Стандартное место' ?>
                            </span>
                            <span class="online-badge">Доступно онлайн-бронирование</span>
                        </div>

                        <div class="price-card <?= $isVip ? 'vip-mode' : '' ?>">
                            <div class="price-value"><?= htmlspecialchars($data['price_per_hour']) ?> ₽</div>
                            <div class="price-note">за 1 час игры</div>
                        </div>
                    </div>

                    <!-- 2 ряд -->
                    <div class="summary-left">
                        <div class="games-box">
                            <strong>Подходит для:</strong>
                            <div class="tag-list">
                                <?php foreach ($gameTags as $tag) { ?>
                                    <span class="tag-chip <?= $isVip ? 'vip-mode' : '' ?>"><?= htmlspecialchars($tag) ?></span>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="meta-grid">
                            <div class="meta-box">
                                <span>Зона</span>
                                <strong><?= htmlspecialchars($data['zone_name']) ?></strong>
                            </div>
                            <div class="meta-box">
                                <span>Тариф</span>
                                <strong><?= htmlspecialchars($data['tariff_name']) ?></strong>
                            </div>
                            <div class="meta-box <?= $isVip ? 'vip-monitor' : '' ?>">
                                <span>Монитор</span>
                                <strong><?= $monitorHz ?> Гц</strong>
                            </div>
                            <div class="meta-box">
                                <span>Год</span>
                                <strong><?= htmlspecialchars($data['release_year']) ?></strong>
                            </div>
                        </div>
                    </div>

                    <div class="summary-right">
                        <?php if (is_logged_in()) { ?>
                            <div class="quick-booking-card <?= $isVip ? 'vip-mode' : '' ?>" id="quick-booking">
                                <div class="quick-booking-spacer" aria-hidden="true"></div>
                                <h3 class="quick-booking-title">Добавить в корзину</h3>

                                <?php if ($errors) { ?>
                                    <ul class="error-list">
                                        <?php foreach ($errors as $error) { ?>
                                            <li><?= htmlspecialchars($error) ?></li>
                                        <?php } ?>
                                    </ul>
                                <?php } ?>

                                <form method="post" class="quick-grid">
                                    <div class="field booking-date-field">
                                        <label for="booking_date">Дата бронирования</label>
                                        <input type="date" name="booking_date" id="booking_date" value="<?= $today ?>" min="<?= $today ?>" required>
                                    </div>

                                    <div class="field booking-hours-field">
                                        <label for="hours">Часы</label>
                                        <input type="number" name="hours" id="hours" min="1" max="24" value="2" required>
                                    </div>

                                    <div class="auth-actions">
                                        <button type="submit" name="quick_add" class="btn btn-primary">Добавить в корзину</button>
                                    </div>
                                </form>
                            </div>
                        <?php } else { ?>
                            <div class="quick-booking-card <?= $isVip ? 'vip-mode' : '' ?>">
                                <div class="quick-booking-spacer" aria-hidden="true"></div>
                                <h3 class="quick-booking-title">Добавить в корзину</h3>
                                <p class="note" style="margin-bottom:18px;">
                                    Чтобы добавить место в корзину и потом оформить его в свои бронирования,
                                    сначала войдите в аккаунт.
                                </p>
                                <div class="card-actions">
                                    <a class="btn btn-primary" href="login.php">Войти</a>
                                    <a class="btn btn-secondary" href="register.php">Регистрация</a>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- 3 ряд -->
                    <div class="info-panel config-panel">
                        <h3>Конфигурация ПК</h3>

                        <div class="icon-list">
                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_cpu(); ?></div>
                                <div class="icon-text">
                                    <strong>Процессор</strong>
                                    <span><?= htmlspecialchars($data['cpu']) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_gpu(); ?></div>
                                <div class="icon-text">
                                    <strong>Видеокарта</strong>
                                    <span><?= htmlspecialchars($data['gpu']) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_ram(); ?></div>
                                <div class="icon-text">
                                    <strong>Оперативная память</strong>
                                    <span><?= htmlspecialchars($data['ram']) ?> ГБ</span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_club(); ?></div>
                                <div class="icon-text">
                                    <strong>Клуб</strong>
                                    <span><?= htmlspecialchars($data['club_name']) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_geo(); ?></div>
                                <div class="icon-text">
                                    <strong>Адрес</strong>
                                    <span><?= htmlspecialchars($data['address']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-panel periphery-panel">
                        <h3>Игровая периферия</h3>

                        <div class="icon-list">
                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_monitor(); ?></div>
                                <div class="icon-text">
                                    <strong>Монитор</strong>
                                    <span><?= htmlspecialchars($monitorModel) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_keyboard(); ?></div>
                                <div class="icon-text">
                                    <strong>Клавиатура</strong>
                                    <span><?= htmlspecialchars($keyboardModel) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_mouse(); ?></div>
                                <div class="icon-text">
                                    <strong>Мышь</strong>
                                    <span><?= htmlspecialchars($mouseModel) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_headset(); ?></div>
                                <div class="icon-text">
                                    <strong>Наушники</strong>
                                    <span><?= htmlspecialchars($headsetModel) ?></span>
                                </div>
                            </div>

                            <div class="icon-item">
                                <div class="icon-wrap"><?= icon_chair(); ?></div>
                                <div class="icon-text">
                                    <strong>Кресло</strong>
                                    <span><?= htmlspecialchars($chairModel) ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="mini-note">
                            Формат места:
                            <strong style="color:#ffffff;"><?= $isVip ? 'VIP-сегмент' : 'Стандартная игровая зона' ?></strong>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/footer.php'; ?>