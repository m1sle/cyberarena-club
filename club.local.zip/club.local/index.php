<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'CyberArena | Компьютерный клуб';
$bodyClass = 'page-home';
$current_user_id = current_user()['id'] ?? 0;
$is_logged_in = is_logged_in();
$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    require_login('login.php');

    $serviceName = raw_clean($_POST['service_name'] ?? '');
    $bookingDate = raw_clean($_POST['booking_date'] ?? $today);
    $hours = (int) ($_POST['hours'] ?? 2);
    $user = current_user();

    if ($serviceName === '' || !is_valid_date($bookingDate) || $hours <= 0 || $hours > 24) {
        set_flash('error', 'Не удалось добавить место в корзину. Проверьте данные бронирования.');
    } else {
        add_cart_item([
            'client_name' => $user['full_name'],
            'phone' => $user['phone'],
            'service_name' => $serviceName,
            'booking_date' => $bookingDate,
            'hours' => $hours,
        ]);
        set_flash('success', 'Игровое место добавлено в корзину.');
    }

    $queryString = isset($_POST['return_query']) ? trim((string) $_POST['return_query']) : '';
    $redirect = 'index.php#catalog';
    if ($queryString !== '') {
        $redirect = 'index.php?' . $queryString . '#catalog';
    }

    header('Location: ' . $redirect);
    exit;
}

$total_places = 0;
$total_places_result = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM computers');
if ($total_places_result) {
    $row_total = mysqli_fetch_assoc($total_places_result);
    $total_places = (int) ($row_total['total'] ?? 0);
}

$vip_places = 0;
$vip_places_result = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM computers WHERE is_vip = 1');
if ($vip_places_result) {
    $row_vip = mysqli_fetch_assoc($vip_places_result);
    $vip_places = (int) ($row_vip['total'] ?? 0);
}

$night_rate = 0;
$night_rate_result = mysqli_query($conn, "
    SELECT MIN(price_per_hour) AS min_price
    FROM tariffs
    WHERE tariff_name LIKE '%Night%'
");
if ($night_rate_result) {
    $row_night = mysqli_fetch_assoc($night_rate_result);
    $night_rate = (float) ($row_night['min_price'] ?? 0);
}

if ($night_rate <= 0) {
    $fallback_rate_result = mysqli_query($conn, 'SELECT MIN(price_per_hour) AS min_price FROM tariffs');
    if ($fallback_rate_result) {
        $row_rate = mysqli_fetch_assoc($fallback_rate_result);
        $night_rate = (float) ($row_rate['min_price'] ?? 0);
    }
}

$hero_photos = [];
$hero_result = mysqli_query($conn, "
    SELECT photo
    FROM computers
    WHERE photo IS NOT NULL
      AND photo <> ''
    ORDER BY id ASC
");

if ($hero_result && mysqli_num_rows($hero_result) > 0) {
    while ($hero_row = mysqli_fetch_assoc($hero_result)) {
        $photo = trim($hero_row['photo']);
        if ($photo !== '' && !in_array($photo, $hero_photos, true)) {
            $hero_photos[] = $photo;
        }
    }
}

$fallback_photos = ['pc1.jpg', 'pc2.jpg', 'pc3.jpg', 'pc4.jpg', 'pc5.jpg'];
foreach ($fallback_photos as $fallback_photo) {
    if (!in_array($fallback_photo, $hero_photos, true)) {
        $hero_photos[] = $fallback_photo;
    }
}
$hero_photos = array_slice($hero_photos, 0, 5);
if (count($hero_photos) === 0) {
    $hero_photos = ['noimage.jpg'];
}

$order = 'c.pc_name ASC';
if (isset($_GET['sort'])) {
    if ($_GET['sort'] === 'price_asc') {
        $order = 't.price_per_hour ASC';
    } elseif ($_GET['sort'] === 'price_desc') {
        $order = 't.price_per_hour DESC';
    } elseif ($_GET['sort'] === 'year_desc') {
        $order = 'c.release_year DESC';
    }
}

$where = '1=1';
if (!empty($_GET['zone_id'])) {
    $zone_id = (int) $_GET['zone_id'];
    $where .= " AND z.id = {$zone_id}";
}
if (isset($_GET['vip_only']) && $_GET['vip_only'] === '1') {
    $where .= ' AND c.is_vip = 1';
}

$zones_result = mysqli_query($conn, 'SELECT id, zone_name FROM zones ORDER BY zone_name ASC');

$query = "
SELECT
    c.id,
    c.pc_name,
    c.cpu,
    c.gpu,
    c.ram,
    c.monitor_hz,
    c.release_year,
    c.photo,
    c.is_vip,
    z.zone_name,
    cl.club_name,
    cl.address,
    t.tariff_name,
    t.price_per_hour
FROM computers c
JOIN zones z ON c.zone_id = z.id
JOIN clubs cl ON z.club_id = cl.id
JOIN tariffs t ON c.tariff_id = t.id
WHERE {$where}
ORDER BY {$order}
";

$result = mysqli_query($conn, $query);
$returnQuery = http_build_query($_GET);

require_once __DIR__ . '/header.php';
?>

<div class="status-strip">
    <div class="container status-strip-inner">
        <div class="status-pill">Сегодня доступно: <strong><?= $total_places ?></strong> мест</div>
        <div class="status-pill">VIP-зоны: <strong><?= $vip_places ?></strong></div>
        <div class="status-pill">Ночной тариф от <strong><?= number_format($night_rate, 0, '.', ' ') ?> ₽/час</strong></div>
        <div class="status-pill">Онлайн-бронирование доступно 24/7</div>
    </div>
</div>

<section class="hero">
    <div class="container hero-grid">
        <div>
            <div class="hero-badge">24/7 · VIP-зоны · Онлайн-бронирование</div>
            <h1>Играй на мощных ПК в современном компьютерном клубе</h1>
            <p>
                Выбирай игровые места, сравнивай характеристики компьютеров, находи подходящую зону
                и оформляй бронирование онлайн в несколько кликов.
            </p>

            <div class="hero-perks">
                <span class="hero-perk-item">RTX / High FPS</span>
                <span class="hero-perk-item">VIP и стандартные зоны</span>
                <span class="hero-perk-item">Ночные тарифы</span>
            </div>

            <div class="hero-buttons">
                <a href="#catalog" class="btn btn-primary">Смотреть игровые места</a>
                <?php if ($is_logged_in) { ?>
                    <a href="memory.php" class="btn btn-secondary">Перейти в корзину</a>
                <?php } else { ?>
                    <a href="register.php" class="btn btn-secondary">Зарегистрироваться</a>
                <?php } ?>
            </div>
        </div>

        <div class="hero-card glow-card">
            <div class="hero-slider" id="heroSlider">
                <?php foreach ($hero_photos as $index => $photo) { ?>
                    <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>">
                        <img src="images/<?= htmlspecialchars($photo) ?>" alt="Игровая зона" onerror="this.src='images/noimage.jpg'">
                    </div>
                <?php } ?>

                <div class="hero-slider-shadow"></div>

                <?php if (count($hero_photos) > 1) { ?>
                    <button type="button" class="hero-slider-hitbox hero-slider-hitbox-left" id="heroPrevArea" aria-label="Предыдущий слайд"></button>
                    <button type="button" class="hero-slider-hitbox hero-slider-hitbox-right" id="heroNextArea" aria-label="Следующий слайд"></button>

                    <div class="hero-slider-dots" id="heroSliderDots">
                        <?php foreach ($hero_photos as $index => $photo) { ?>
                            <button type="button" class="hero-slider-dot <?= $index === 0 ? 'active' : '' ?>" data-slide="<?= $index ?>" aria-label="Слайд <?= $index + 1 ?>"></button>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>

<section class="section" id="catalog">
    <div class="container">
        <div class="filter-card catalog-filter-card">
            <div>
                <h2>Подбор игрового места</h2>
            </div>

            <form method="get" action="index.php#catalog" class="filter-form">
                <div>
                    <label for="sort">Сортировка</label>
                    <select name="sort" id="sort">
                        <option value="name_asc" <?= (isset($_GET['sort']) && $_GET['sort'] === 'name_asc') ? 'selected' : '' ?>>По названию</option>
                        <option value="price_asc" <?= (isset($_GET['sort']) && $_GET['sort'] === 'price_asc') ? 'selected' : '' ?>>По цене ↑</option>
                        <option value="price_desc" <?= (isset($_GET['sort']) && $_GET['sort'] === 'price_desc') ? 'selected' : '' ?>>По цене ↓</option>
                        <option value="year_desc" <?= (isset($_GET['sort']) && $_GET['sort'] === 'year_desc') ? 'selected' : '' ?>>По году ↓</option>
                    </select>
                </div>

                <div>
                    <label for="zone_id">Зона</label>
                    <select name="zone_id" id="zone_id">
                        <option value="">Все зоны</option>
                        <?php if ($zones_result && mysqli_num_rows($zones_result) > 0) { ?>
                            <?php while ($zone = mysqli_fetch_assoc($zones_result)) { ?>
                                <option value="<?= (int) $zone['id'] ?>" <?= (isset($_GET['zone_id']) && $_GET['zone_id'] == $zone['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($zone['zone_name']) ?>
                                </option>
                            <?php } ?>
                        <?php } ?>
                    </select>
                </div>

                <div>
                    <label>
                        <input type="checkbox" name="vip_only" value="1" <?= (isset($_GET['vip_only']) && $_GET['vip_only'] === '1') ? 'checked' : '' ?>>
                        Только VIP-компьютеры
                    </label>
                </div>

                <div>
                    <button type="submit" class="btn btn-primary">Показать</button>
                </div>

                <div>
                    <a href="index.php#catalog" class="btn btn-secondary">Сбросить</a>
                </div>
            </form>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="table-card">
            <div class="catalog-header-row">
                <div>
                    <div class="page-kicker">Готово к бронированию</div>
                    <h2>Доступные игровые компьютеры</h2>
                </div>
                <div class="catalog-mini-note">Выбирайте конфигурацию, тариф и переходите к бронированию в пару кликов.</div>
            </div>

            <?php if ($result && mysqli_num_rows($result) > 0) { ?>
                <div class="pc-grid">
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <?php $serviceLabel = $row['pc_name'] . ' / ' . $row['zone_name'] . ' / ' . $row['tariff_name']; ?>
                        <div class="pc-card glow-card">
                            <div class="pc-card-media">
                                <img src="images/<?= htmlspecialchars($row['photo']) ?>" alt="Фото ПК" onerror="this.src='images/noimage.jpg'">
                                <div class="pc-card-label <?= $row['is_vip'] ? 'pc-card-label-vip' : 'pc-card-label-regular' ?>">
                                    <?= $row['is_vip'] ? 'VIP' : 'STANDARD' ?>
                                </div>
                            </div>

                            <div class="pc-card-body">
                                <div class="pc-title-row">
                                    <h3 class="pc-title"><?= htmlspecialchars($row['pc_name']) ?></h3>
                                </div>

                                <div class="pc-card-subtitle">
                                    <?= htmlspecialchars($row['zone_name']) ?> · <?= htmlspecialchars($row['tariff_name']) ?>
                                </div>

                                <div class="pc-spec-grid">
                                    <div class="pc-spec-chip">
                                        <span>CPU</span>
                                        <strong><?= htmlspecialchars($row['cpu']) ?></strong>
                                    </div>
                                    <div class="pc-spec-chip">
                                        <span>GPU</span>
                                        <strong><?= htmlspecialchars($row['gpu']) ?></strong>
                                    </div>
                                    <div class="pc-spec-chip">
                                        <span>RAM</span>
                                        <strong><?= htmlspecialchars($row['ram']) ?> ГБ</strong>
                                    </div>
                                    <div class="pc-spec-chip">
                                        <span>MONITOR</span>
                                        <strong><?= !empty($row['monitor_hz']) ? (int) $row['monitor_hz'] . ' Гц' : '—' ?></strong>
                                    </div>
                                </div>

                                <div class="pc-price-row">
                                    <div class="price price-strong"><?= number_format((float) $row['price_per_hour'], 0, '.', ' ') ?> ₽</div>
                                    <div class="price-caption">за 1 час игры</div>
                                </div>

                                <div class="card-actions card-actions-stretch">
                                    <a class="btn btn-secondary" href="details.php?id=<?= (int) $row['id'] ?>">Подробнее</a>

                                    <?php if ($is_logged_in) { ?>
                                        <form method="post" class="catalog-cart-form">
                                            <input type="hidden" name="service_name" value="<?= htmlspecialchars($serviceLabel) ?>">
                                            <input type="hidden" name="booking_date" value="<?= $today ?>">
                                            <input type="hidden" name="hours" value="2">
                                            <input type="hidden" name="return_query" value="<?= htmlspecialchars($returnQuery) ?>">
                                            <button type="submit" name="add_to_cart" class="btn btn-primary btn-glow">В корзину</button>
                                        </form>
                                    <?php } else { ?>
                                        <a class="btn btn-primary btn-glow" href="login.php">В корзину</a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } else { ?>
                <p class="note">По вашему запросу игровые места не найдены.</p>
            <?php } ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="info-card">
            <div class="page-kicker">О клубе</div>
            <h2 class="section-title">Комфортные игровые сессии, мощные ПК и бронирование без лишних шагов</h2>

            <p class="note" style="margin-bottom: 18px;">
                CyberArena — это современный компьютерный клуб для игровых сессий, турниров, совместных каток
                и комфортного отдыха. Мы собрали игровые места с разными тарифами и зонами, чтобы каждый клиент
                мог подобрать формат игры под себя: от стандартных мест для повседневных сессий до более
                комфортных VIP-позиций.
            </p>

            <p class="note" style="margin-bottom: 18px;">
                На сайте можно заранее посмотреть доступные компьютеры, сравнить их характеристики,
                быстро открыть подробную страницу каждого места, выбрать подходящую дату и добавить нужные
                позиции в корзину. После этого бронирование оформляется и сохраняется в личном кабинете.
            </p>

            <div class="club-feature-row">
                <div class="club-feature-box">
                    <strong>Игровые и VIP-места</strong>
                    <span>Разные конфигурации, зоны и тарифы под вечернюю игру и долгие сессии.</span>
                </div>
                <div class="club-feature-box">
                    <strong>Фильтрация и сравнение</strong>
                    <span>Удобный выбор по зоне, цене и характеристикам без лишнего перехода между страницами.</span>
                </div>
                <div class="club-feature-box">
                    <strong>Онлайн-бронирование</strong>
                    <span>Корзина и личный кабинет помогают быстро оформить место и сохранить все брони.</span>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/footer.php'; ?>

<?php if (count($hero_photos) > 1) { ?>
<script>
(function () {
    const slider = document.getElementById('heroSlider');
    if (!slider) return;

    const slides = slider.querySelectorAll('.hero-slide');
    const dots = slider.querySelectorAll('.hero-slider-dot');
    const prevArea = document.getElementById('heroPrevArea');
    const nextArea = document.getElementById('heroNextArea');

    if (!slides.length) return;

    let current = 0;
    let intervalId = null;

    function showSlide(index) {
        slides.forEach((slide, i) => slide.classList.toggle('active', i === index));
        dots.forEach((dot, i) => dot.classList.toggle('active', i === index));
        current = index;
    }

    function nextSlide() {
        showSlide((current + 1) % slides.length);
    }

    function prevSlide() {
        showSlide((current - 1 + slides.length) % slides.length);
    }

    function startAuto() {
        stopAuto();
        intervalId = setInterval(nextSlide, 3200);
    }

    function stopAuto() {
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
    }

    if (nextArea) {
        nextArea.addEventListener('click', function () {
            nextSlide();
            startAuto();
        });
    }

    if (prevArea) {
        prevArea.addEventListener('click', function () {
            prevSlide();
            startAuto();
        });
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', function () {
            showSlide(index);
            startAuto();
        });
    });

    slider.addEventListener('mouseenter', stopAuto);
    slider.addEventListener('mouseleave', startAuto);

    startAuto();
})();
</script>
<?php } ?>
