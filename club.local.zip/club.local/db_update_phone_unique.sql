USE computer_club;

ALTER TABLE users
ADD UNIQUE KEY uq_users_phone (phone);
