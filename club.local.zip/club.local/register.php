<?php
require_once __DIR__ . '/bootstrap.php';

if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Регистрация | CyberArena';
$errors = [];

$form = [
    'full_name' => '',
    'phone' => '',
    'login' => '',
    'email' => '',
    'captcha' => '',
];

function is_allowed_registration_email(string $email): bool
{
    $email = mb_strtolower(trim($email));
    $parts = explode('@', $email);

    if (count($parts) !== 2) {
        return false;
    }

    $domain = $parts[1];
    $allowedDomains = ['mail.com', 'yandex.ru'];

    return in_array($domain, $allowedDomains, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['full_name'] = raw_clean($_POST['full_name'] ?? '');
    $form['phone'] = raw_clean($_POST['phone'] ?? '');
    $form['login'] = raw_clean($_POST['login'] ?? '');
    $form['email'] = raw_clean($_POST['email'] ?? '');
    $form['captcha'] = raw_clean($_POST['captcha'] ?? '');

    $password = (string) ($_POST['password'] ?? '');
    $passwordRepeat = (string) ($_POST['password_repeat'] ?? '');
    $registeredAt = date('Y-m-d');
    $captchaExpected = strtoupper((string) ($_SESSION['register_captcha_code'] ?? ''));
    $captchaInput = strtoupper($form['captcha']);

    if ($form['full_name'] === '') {
        $errors[] = 'Укажите имя и фамилию.';
    } elseif (!is_valid_full_name($form['full_name'])) {
        $errors[] = 'Имя и фамилия должны содержать только буквы, пробелы или дефис.';
    }

    $normalizedPhone = normalize_phone_ru($form['phone']);
    if ($normalizedPhone === false) {
        $errors[] = 'Введите корректный номер телефона в российском формате.';
    }

    if (!is_valid_login_name($form['login'])) {
        $errors[] = 'Логин должен содержать от 4 до 12 символов: латиница, цифры или _.';
    }

    if (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Введите корректный e-mail.';
    } elseif (!is_allowed_registration_email($form['email'])) {
        $errors[] = 'Разрешены только адреса на доменах mail.com и yandex.ru.';
    }

    if (mb_strlen($password) < 6) {
        $errors[] = 'Пароль должен содержать минимум 6 символов.';
    }

    if ($password !== $passwordRepeat) {
        $errors[] = 'Пароли не совпадают.';
    }

    if ($form['login'] !== '' && $password !== '' && $form['login'] === $password) {
        $errors[] = 'Логин и пароль не должны совпадать.';
    }

    if ($form['email'] !== '' && $password !== '' && $form['email'] === $password) {
        $errors[] = 'Пароль не должен совпадать с e-mail.';
    }

    if ($captchaInput === '' || $captchaExpected === '' || $captchaInput !== $captchaExpected) {
        $errors[] = 'Капча введена неверно.';
    }

    if (!$errors) {
        try {
            $stmt = cyberarena_db_prepare(
                $conn,
                'SELECT id, login, email, phone FROM users WHERE login = ? OR email = ? OR phone = ? LIMIT 1',
                'Не удалось проверить регистрационные данные в базе.'
            );
            cyberarena_stmt_bind($stmt, 'sss', $form['login'], $form['email'], $normalizedPhone);
            cyberarena_stmt_execute($stmt, 'Не удалось проверить регистрационные данные в базе.');
            $existingResult = mysqli_stmt_get_result($stmt);
            $existingUser = mysqli_fetch_assoc($existingResult);
            mysqli_stmt_close($stmt);

            if ($existingUser) {
                if ($existingUser['login'] === $form['login']) {
                    $errors[] = 'Такой логин уже зарегистрирован.';
                }
                if ($existingUser['email'] === $form['email']) {
                    $errors[] = 'Такая почта уже зарегистрирована.';
                }
                if ($existingUser['phone'] === $normalizedPhone) {
                    $errors[] = 'Этот номер телефона уже используется другим пользователем.';
                }
            }
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (!$errors) {
        try {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            if ($passwordHash === false) {
                trigger_error('Не удалось создать хэш пароля при регистрации.', E_USER_WARNING);
                throw new RuntimeException('Не удалось подготовить данные для регистрации.');
            }

            $userStmt = cyberarena_db_prepare(
                $conn,
                'INSERT INTO users (full_name, phone, login, email, password_hash, registered_at) VALUES (?, ?, ?, ?, ?, ?)',
                'Не удалось подготовить регистрацию пользователя.'
            );
            cyberarena_stmt_bind(
                $userStmt,
                'ssssss',
                $form['full_name'],
                $normalizedPhone,
                $form['login'],
                $form['email'],
                $passwordHash,
                $registeredAt
            );
            cyberarena_stmt_execute($userStmt, 'Не удалось завершить регистрацию пользователя.');
            mysqli_stmt_close($userStmt);

            unset($_SESSION['register_captcha_code']);
            $_SESSION['last_registered_login'] = $form['login'];
            set_flash('success', 'Регистрация прошла успешно. Теперь войдите в свой аккаунт.');
            header('Location: login.php');
            exit;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container auth-shell">
        <div class="auth-card auth-card-modern auth-card-register-clean">
                        <h1>Регистрация</h1>
            <p class="note auth-lead">
                Создайте аккаунт CyberArena, чтобы бронировать игровые места,
                сохранять свои данные и быстро оформлять заказы в личном кабинете.
            </p>

            <?php if ($errors) { ?>
                <ul class="error-list">
                    <?php foreach ($errors as $error) { ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <form method="post" id="registerForm" class="auth-form-grid auth-form-register-clean" autocomplete="off">
                <div class="field">
                    <label for="full_name">Имя и фамилия</label>
                    <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($form['full_name']) ?>" required>
                </div>

                <div class="field">
                    <label for="phone">Телефон</label>
                    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($form['phone']) ?>" placeholder="+7 (999) 999-99-99" required>
                </div>

                <div class="field">
                    <label for="login">Логин</label>
                    <input
                        type="text"
                        id="login"
                        name="login"
                        value="<?= htmlspecialchars($form['login']) ?>"
                        minlength="4"
                        maxlength="12"
                        required
                    >
                    <div class="helper-text">От 4 до 12 символов: латиница, цифры или _</div>
                </div>

                <div class="field">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($form['email']) ?>" required>
                    <div class="helper-text">Разрешены адреса только на доменах mail.com и yandex.ru</div>
                </div>

                <div class="field register-date-field">
                    <label>Дата регистрации</label>
                    <div class="readonly-info-box"><?= date('d.m.Y') ?></div>
                </div>

                <div class="register-grid-spacer" aria-hidden="true"></div>


                <div class="field">
                    <label for="password">Пароль</label>
                    <div class="password-field-wrap">
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="password-input"
                            minlength="6"
                            required
                        >
                        <button type="button" class="password-toggle-plain" data-target="password" aria-label="Показать пароль">👁</button>
                    </div>
                </div>

                <div class="field">
                    <label for="password_repeat">Повтор пароля</label>
                    <div class="password-field-wrap">
                        <input
                            type="password"
                            id="password_repeat"
                            name="password_repeat"
                            class="password-input"
                            minlength="6"
                            required
                        >
                        <button type="button" class="password-toggle-plain" data-target="password_repeat" aria-label="Показать пароль">👁</button>
                    </div>
                </div>

                <input type="hidden" name="captcha" id="captchaHiddenField" value="<?= htmlspecialchars($form['captcha']) ?>">

                <div class="auth-actions field-full">
                    <button type="button" id="openCaptchaModalBtn" class="btn btn-primary">Зарегистрироваться</button>
                    <a href="login.php" class="btn btn-secondary">Уже есть аккаунт</a>
                </div>
            </form>

            <div class="captcha-modal" id="registerCaptchaModal" hidden>
                <div class="captcha-modal-backdrop" id="captchaModalBackdrop"></div>
                <div class="captcha-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="captchaModalTitle">
                    <button type="button" class="captcha-modal-close" id="closeCaptchaModalCross" aria-label="Закрыть">×</button>
                    <div class="captcha-modal-title" id="captchaModalTitle">Подтвердите регистрацию</div>
                    <div class="captcha-modal-text">Введите символы с картинки перед созданием аккаунта.</div>

                    <div class="captcha-row captcha-row-modal">
                        <div class="captcha-preview-box">
                            <img src="captcha.php?context=register&r=<?= time() ?>" alt="Капча" class="captcha-image" id="registerCaptchaImage">
                        </div>
                        <button type="button" class="captcha-refresh-btn" id="refreshCaptchaBtn">Обновить</button>
                    </div>

                    <div class="field captcha-modal-field">
                        <input type="text" id="captchaModalInput" maxlength="5" autocomplete="off">
                        <div class="helper-text">Введите символы с картинки</div>
                    </div>

                    <div class="captcha-modal-actions">
                        <button type="button" class="btn btn-secondary" id="closeCaptchaModalBtn">Отмена</button>
                        <button type="button" class="btn btn-primary" id="confirmCaptchaSubmitBtn">Подтвердить</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
function formatPhoneValue(value) {
    let digits = value.replace(/\D/g, '');

    if (digits.startsWith('8')) {
        digits = '7' + digits.slice(1);
    }

    if (!digits.startsWith('7') && digits.length > 0) {
        digits = '7' + digits;
    }

    digits = digits.slice(0, 11);

    if (digits.length === 0) return '';

    let result = '+7';
    if (digits.length > 1) result += ' (' + digits.slice(1, 4);
    if (digits.length >= 4) result += ')';
    if (digits.length > 4) result += ' ' + digits.slice(4, 7);
    if (digits.length > 7) result += '-' + digits.slice(7, 9);
    if (digits.length > 9) result += '-' + digits.slice(9, 11);

    return result;
}

const phoneInput = document.getElementById('phone');
if (phoneInput) {
    phoneInput.addEventListener('input', function () {
        this.value = formatPhoneValue(this.value);
    });
}

(function () {
    const toggles = document.querySelectorAll('.password-toggle-plain');

    toggles.forEach(function (button) {
        button.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);

            if (!input) return;

            const isPassword = input.getAttribute('type') === 'password';
            input.setAttribute('type', isPassword ? 'text' : 'password');
            this.classList.toggle('active', isPassword);
            this.setAttribute('aria-label', isPassword ? 'Скрыть пароль' : 'Показать пароль');
        });
    });
})();

(function () {
    const form = document.getElementById('registerForm');
    const openButton = document.getElementById('openCaptchaModalBtn');
    const closeButton = document.getElementById('closeCaptchaModalBtn');
    const closeCross = document.getElementById('closeCaptchaModalCross');
    const backdrop = document.getElementById('captchaModalBackdrop');
    const modal = document.getElementById('registerCaptchaModal');
    const refreshButton = document.getElementById('refreshCaptchaBtn');
    const captchaImage = document.getElementById('registerCaptchaImage');
    const captchaHidden = document.getElementById('captchaHiddenField');
    const captchaInput = document.getElementById('captchaModalInput');
    const confirmButton = document.getElementById('confirmCaptchaSubmitBtn');

    if (!form || !openButton || !modal || !captchaImage || !captchaInput || !confirmButton || !captchaHidden) {
        return;
    }

    function refreshCaptcha() {
        captchaImage.src = 'captcha.php?context=register&r=' + Date.now();
    }

    function openModal() {
        refreshCaptcha();
        captchaInput.value = '';
        captchaHidden.value = '';
        modal.hidden = false;
        document.body.classList.add('modal-open');
        window.setTimeout(function () {
            captchaInput.focus();
        }, 60);
    }

    function closeModal() {
        modal.hidden = true;
        document.body.classList.remove('modal-open');
    }

    openButton.addEventListener('click', function () {
        if (form.reportValidity()) {
            openModal();
        }
    });

    refreshButton.addEventListener('click', function () {
        refreshCaptcha();
        captchaInput.focus();
    });

    function handleClose() {
        closeModal();
    }

    closeButton.addEventListener('click', handleClose);
    if (closeCross) {
        closeCross.addEventListener('click', handleClose);
    }
    if (backdrop) {
        backdrop.addEventListener('click', handleClose);
    }

    confirmButton.addEventListener('click', function () {
        const value = captchaInput.value.trim();
        if (value === '') {
            captchaInput.focus();
            return;
        }

        captchaHidden.value = value;
        form.submit();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && !modal.hidden) {
            closeModal();
        }
    });
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
