<?php
require_once __DIR__ . '/bootstrap.php';
require_login('login.php');
refresh_user_session($conn, current_user()['id']);

$user = current_user();
$pageTitle = 'Личный кабинет | CyberArena';
$profileErrors = [];
$passwordErrors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    $fullName = raw_clean($_POST['full_name'] ?? '');
    $phoneRaw = raw_clean($_POST['phone'] ?? '');
    $email = raw_clean($_POST['email'] ?? '');

    if ($fullName === '') {
        $profileErrors[] = 'Укажите имя и фамилию.';
    }

    $normalizedPhone = normalize_phone_ru($phoneRaw);
    if ($normalizedPhone === false) {
        $profileErrors[] = 'Введите корректный номер телефона.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $profileErrors[] = 'Введите корректный e-mail.';
    }

    if (!$profileErrors) {
        $stmt = mysqli_prepare($conn, 'SELECT id, email, phone FROM users WHERE (email = ? OR phone = ?) AND id <> ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 'ssi', $email, $normalizedPhone, $user['id']);
        mysqli_stmt_execute($stmt);
        $resultDuplicate = mysqli_stmt_get_result($stmt);
        $duplicate = mysqli_fetch_assoc($resultDuplicate);
        mysqli_stmt_close($stmt);

        if ($duplicate) {
            if ($duplicate['email'] === $email) {
                $profileErrors[] = 'Этот e-mail уже используется другим пользователем.';
            }
            if ($duplicate['phone'] === $normalizedPhone) {
                $profileErrors[] = 'Этот номер телефона уже используется другим пользователем.';
            }
        }
    }

    if (!$profileErrors) {
        $stmtUser = mysqli_prepare($conn, 'UPDATE users SET full_name = ?, phone = ?, email = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmtUser, 'sssi', $fullName, $normalizedPhone, $email, $user['id']);
        $updated = mysqli_stmt_execute($stmtUser);
        mysqli_stmt_close($stmtUser);

        if ($updated) {
            refresh_user_session($conn, $user['id']);
            set_flash('success', 'Профиль успешно обновлён.');
            header('Location: profile.php');
            exit;
        }

        $profileErrors[] = 'Не удалось обновить профиль.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = (string) ($_POST['current_password'] ?? '');
    $newPassword = (string) ($_POST['new_password'] ?? '');
    $newPasswordRepeat = (string) ($_POST['new_password_repeat'] ?? '');

    if ($currentPassword === '') {
        $passwordErrors[] = 'Введите текущий пароль.';
    }

    if (mb_strlen($newPassword) < 6) {
        $passwordErrors[] = 'Новый пароль должен содержать минимум 6 символов.';
    }

    if ($newPassword !== $newPasswordRepeat) {
        $passwordErrors[] = 'Новый пароль и повтор пароля не совпадают.';
    }

    if ($newPassword !== '' && $currentPassword !== '' && $newPassword === $currentPassword) {
        $passwordErrors[] = 'Новый пароль должен отличаться от текущего.';
    }

    if ($newPassword !== '' && $newPassword === ($user['login'] ?? '')) {
        $passwordErrors[] = 'Новый пароль не должен совпадать с логином.';
    }

    if ($newPassword !== '' && $newPassword === ($user['email'] ?? '')) {
        $passwordErrors[] = 'Новый пароль не должен совпадать с e-mail.';
    }

    if (!$passwordErrors) {
        $stmtPassword = mysqli_prepare($conn, 'SELECT password_hash FROM users WHERE id = ? LIMIT 1');
        mysqli_stmt_bind_param($stmtPassword, 'i', $user['id']);
        mysqli_stmt_execute($stmtPassword);
        $passwordResult = mysqli_stmt_get_result($stmtPassword);
        $passwordRow = mysqli_fetch_assoc($passwordResult);
        mysqli_stmt_close($stmtPassword);

        $storedHash = $passwordRow['password_hash'] ?? '';

        if (!$storedHash || !password_verify($currentPassword, $storedHash)) {
            $passwordErrors[] = 'Текущий пароль введён неверно.';
        }
    }

    if (!$passwordErrors) {
        $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmtUpdatePassword = mysqli_prepare($conn, 'UPDATE users SET password_hash = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmtUpdatePassword, 'si', $newPasswordHash, $user['id']);
        $passwordUpdated = mysqli_stmt_execute($stmtUpdatePassword);
        mysqli_stmt_close($stmtUpdatePassword);

        if ($passwordUpdated) {
            set_flash('success', 'Пароль успешно изменён.');
            header('Location: profile.php');
            exit;
        }

        $passwordErrors[] = 'Не удалось изменить пароль.';
    }
}

$user = current_user();

$bookingsSql = "
    SELECT
        b.id,
        b.booking_date,
        b.hours,
        c.pc_name,
        z.zone_name,
        cl.club_name,
        t.tariff_name,
        t.price_per_hour
    FROM bookings b
    JOIN computers c ON b.computer_id = c.id
    JOIN zones z ON c.zone_id = z.id
    JOIN clubs cl ON z.club_id = cl.id
    JOIN tariffs t ON c.tariff_id = t.id
    WHERE b.user_id = ?
    ORDER BY b.booking_date DESC, b.id DESC
";

$stmtBookings = mysqli_prepare($conn, $bookingsSql);
mysqli_stmt_bind_param($stmtBookings, 'i', $user['id']);
mysqli_stmt_execute($stmtBookings);
$bookingsResult = mysqli_stmt_get_result($stmtBookings);

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container profile-grid">
        <div class="profile-card">
            <h2>Данные пользователя</h2>
           
            <?php if ($profileErrors) { ?>
                <ul class="error-list">
                    <?php foreach ($profileErrors as $error) { ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <form method="post" class="profile-form">
                <div class="field">
                    <label for="full_name">Имя и фамилия</label>
                    <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
                </div>

                <div class="field">
                    <label for="phone">Телефон</label>
                    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>
                </div>

                <div class="field">
                    <label for="login">Логин</label>
                    <input type="text" id="login" value="<?= htmlspecialchars($user['login']) ?>" readonly>
                </div>

                <div class="field">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>

                <div class="field">
                    <label for="registered_at">Дата регистрации</label>
                    <input type="text" id="registered_at" value="<?= htmlspecialchars(date('d.m.Y', strtotime($user['registered_at']))) ?>" readonly>
                </div>

                <div class="profile-actions">
                    <button type="submit" name="save_profile" class="btn btn-primary">Сохранить профиль</button>
                    <a href="memory.php" class="btn btn-secondary">Перейти в корзину</a>
                </div>
            </form>

            <div class="profile-section-divider"></div>

            <div class="profile-password-block">
                <h3 class="profile-subtitle">Смена пароля</h3>
                <p class="note profile-password-note">Введите текущий пароль и задайте новый.</p>

                <?php if ($passwordErrors) { ?>
                    <ul class="error-list">
                        <?php foreach ($passwordErrors as $error) { ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php } ?>
                    </ul>
                <?php } ?>

                <form method="post" class="profile-form profile-password-form" autocomplete="off">
                    <div class="field">
                        <label for="current_password">Текущий пароль</label>
                        <div class="password-field-wrap">
                            <input type="password" id="current_password" name="current_password" class="password-input" minlength="6" required>
                            <button type="button" class="password-toggle-plain" data-target="current_password" aria-label="Показать пароль">👁</button>
                        </div>
                    </div>

                    <div class="field">
                        <label for="new_password">Новый пароль</label>
                        <div class="password-field-wrap">
                            <input type="password" id="new_password" name="new_password" class="password-input" minlength="6" required>
                            <button type="button" class="password-toggle-plain" data-target="new_password" aria-label="Показать пароль">👁</button>
                        </div>
                    </div>

                    <div class="field">
                        <label for="new_password_repeat">Повтор нового пароля</label>
                        <div class="password-field-wrap">
                            <input type="password" id="new_password_repeat" name="new_password_repeat" class="password-input" minlength="6" required>
                            <button type="button" class="password-toggle-plain" data-target="new_password_repeat" aria-label="Показать пароль">👁</button>
                        </div>
                    </div>

                    <div class="profile-actions">
                        <button type="submit" name="change_password" class="btn btn-primary">Сменить пароль</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="profile-card">
            <h2>Кратко по аккаунту</h2>
            <div class="small-box"><span class="profile-label">Имя</span><?= htmlspecialchars($user['full_name']) ?></div>
            <div class="small-box"><span class="profile-label">Телефон</span><?= htmlspecialchars($user['phone']) ?></div>
            <div class="small-box"><span class="profile-label">Логин</span><?= htmlspecialchars($user['login']) ?></div>
            <div class="small-box"><span class="profile-label">E-mail</span><?= htmlspecialchars($user['email']) ?></div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="table-card">
            <h2>Мои бронирования</h2>
            <div class="table-wrap">
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Дата</th>
                        <th>Часы</th>
                        <th>Игровое место</th>
                        <th>Зона</th>
                        <th>Клуб</th>
                        <th>Тариф</th>
                        <th>Цена/час</th>
                    </tr>

                    <?php if ($bookingsResult && mysqli_num_rows($bookingsResult) > 0) { ?>
                        <?php while ($row = mysqli_fetch_assoc($bookingsResult)) { ?>
                            <tr>
                                <td><?= (int) $row['id'] ?></td>
                                <td><?= htmlspecialchars(date('d.m.Y', strtotime($row['booking_date']))) ?></td>
                                <td><?= (int) $row['hours'] ?></td>
                                <td class="cell-service"><?= htmlspecialchars($row['pc_name']) ?></td>
                                <td><?= htmlspecialchars($row['zone_name']) ?></td>
                                <td><?= htmlspecialchars($row['club_name']) ?></td>
                                <td><?= htmlspecialchars($row['tariff_name']) ?></td>
                                <td><?= htmlspecialchars($row['price_per_hour']) ?> руб.</td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="8">У вас пока нет оформленных бронирований.</td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>
    </div>
</section>

<script>
function formatPhoneValue(value) {
    let digits = value.replace(/\D/g, '');
    if (digits.startsWith('8')) digits = '7' + digits.slice(1);
    if (!digits.startsWith('7') && digits.length > 0) digits = '7' + digits;
    digits = digits.slice(0, 11);
    if (digits.length === 0) return '';

    let result = '+7';
    if (digits.length > 1) result += ' (' + digits.slice(1, 4);
    if (digits.length >= 4) result += ')';
    if (digits.length > 4) result += ' ' + digits.slice(4, 7);
    if (digits.length > 7) result += '-' + digits.slice(7, 9);
    if (digits.length > 9) result += '-' + digits.slice(9, 11);
    return result;
}

const phoneInput = document.getElementById('phone');
if (phoneInput) {
    phoneInput.addEventListener('input', function () {
        this.value = formatPhoneValue(this.value);
    });
}

(function () {
    const toggles = document.querySelectorAll('.password-toggle-plain');

    toggles.forEach(function (button) {
        button.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);

            if (!input) return;

            const isPassword = input.getAttribute('type') === 'password';
            input.setAttribute('type', isPassword ? 'text' : 'password');
            this.classList.toggle('active', isPassword);
        });
    });
})();
</script>

<?php
mysqli_stmt_close($stmtBookings);
require_once __DIR__ . '/footer.php';
?>
