<?php
$headerUser = current_user();
$cartCount = get_user_cart_count();
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$bodyClassAttr = '';

if (!empty($bodyClass)) {
    $bodyClassAttr = ' class="' . htmlspecialchars($bodyClass, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"';
}

function nav_active(string $currentPage, array $pages): string
{
    return in_array($currentPage, $pages, true) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'CyberArena' ?></title>
    <link rel="icon" type="image/png" sizes="32x32" href="images/logo.png?v=3">
    <link rel="shortcut icon" type="image/png" href="images/logo.png?v=3">
    <link rel="apple-touch-icon" href="images/logo.png?v=3">
    <link rel="stylesheet" href="styles.css">
</head>
<body<?= $bodyClassAttr ?>>
<header class="header">
    <div class="container header-inner">
        <a href="index.php" class="logo">
            <img src="images/logo.png" alt="CyberArena" class="logo-mark">
            <span class="logo-text">Cyber<span>Arena</span></span>
        </a>

        <nav class="nav">
            <a href="index.php" class="<?= nav_active($currentPage, ['index.php']) ?>">Главная</a>
            <a href="index.php#catalog" class="<?= nav_active($currentPage, ['details.php']) ?>">Игровые места</a>

            <?php if ($headerUser) { ?>
                <a href="memory.php" class="nav-basket-link <?= nav_active($currentPage, ['memory.php']) ?>">
                    Корзина
                    <span class="basket-counter"><?= $cartCount ?></span>
                </a>
                <a href="bookings.php" class="<?= nav_active($currentPage, ['bookings.php']) ?>">Мои бронирования</a>
                <a href="contacts.php" class="<?= nav_active($currentPage, ['contacts.php']) ?>">Контакты</a>
                <a href="profile.php" class="<?= nav_active($currentPage, ['profile.php']) ?>">Личный кабинет</a>
                <a href="logout.php">Выход</a>
            <?php } else { ?>
                <a href="contacts.php" class="<?= nav_active($currentPage, ['contacts.php']) ?>">Контакты</a>
                <a href="login.php" class="<?= nav_active($currentPage, ['login.php']) ?>">Вход</a>
                <a href="register.php" class="<?= nav_active($currentPage, ['register.php']) ?>">Регистрация</a>
            <?php } ?>
        </nav>
    </div>
</header>

<?php $flash = get_flash(); ?>
<?php if ($flash) { ?>
    <div class="container">
        <div class="flash flash-<?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['message']) ?>
        </div>
    </div>
<?php } ?>
