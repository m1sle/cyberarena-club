<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'computer_club';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    trigger_error('Ошибка подключения к БД: ' . mysqli_connect_error(), E_USER_WARNING);
    cyberarena_render_friendly_system_error();
}

if (!mysqli_set_charset($conn, 'utf8mb4')) {
    trigger_error('Не удалось установить кодировку utf8mb4: ' . mysqli_error($conn), E_USER_WARNING);
    cyberarena_render_friendly_system_error();
}
