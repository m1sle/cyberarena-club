<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'ЛР5 · Обработчик ошибок | CyberArena';

if (isset($_GET['demo_throw'])) {
    throw new RuntimeException('Демонстрационное непойманное исключение для проверки set_exception_handler().');
}

if (isset($_GET['demo_fatal'])) {
    require __DIR__ . '/file_not_found_for_lr5_demo.php';
}

function resetDemoLog(): void
{
    ensurePhpErrorLogFile();
    ensureMysqlErrorLogFile();

    saveXmlFile(PHP_ERROR_LOG_FILE, makeEmptyXml('errorlog'));
    saveXmlFile(MYSQL_ERROR_LOG_FILE, makeEmptyXml('mysqllog'));
}

function readPhpLogEntries(int $limit = 10): array
{
    ensurePhpErrorLogFile();
    $content = file_get_contents(PHP_ERROR_LOG_FILE);
    if ($content === false || trim($content) === '') {
        return [];
    }

    $entries = [];
    $xml = @simplexml_load_string($content);
    if ($xml !== false && isset($xml->errorentry)) {
        foreach ($xml->errorentry as $entry) {
            $entries[] = [
                'datetime' => (string) ($entry->datetime ?? ''),
                'errornum' => (string) ($entry->errornum ?? ''),
                'errortype' => (string) ($entry->errortype ?? ''),
                'errormsg' => (string) ($entry->errormsg ?? ''),
                'scriptname' => (string) ($entry->scriptname ?? ''),
                'scriptlinenum' => (string) ($entry->scriptlinenum ?? ''),
            ];
        }
    }

    $entries = array_reverse($entries);
    return array_slice($entries, 0, $limit);
}

function readMysqlLogEntries(int $limit = 10): array
{
    ensureMysqlErrorLogFile();
    $content = file_get_contents(MYSQL_ERROR_LOG_FILE);
    if ($content === false || trim($content) === '') {
        return [];
    }

    $entries = [];
    $xml = @simplexml_load_string($content);
    if ($xml !== false && isset($xml->mysqlerror)) {
        foreach ($xml->mysqlerror as $entry) {
            $entries[] = [
                'datetime' => (string) ($entry->datetime ?? ''),
                'function' => (string) ($entry->function ?? ''),
                'sql' => (string) ($entry->sql ?? ''),
                'errno' => (string) ($entry->errno ?? ''),
                'sqlstate' => (string) ($entry->sqlstate ?? ''),
                'message' => (string) ($entry->message ?? ''),
                'scriptname' => (string) ($entry->scriptname ?? ''),
                'scriptlinenum' => (string) ($entry->scriptlinenum ?? ''),
            ];
        }
    }

    $entries = array_reverse($entries);
    return array_slice($entries, 0, $limit);
}

function redirectDemo(): void
{
    header('Location: error_demo.php');
    exit;
}

$demoForm = [
    'message' => raw_clean($_POST['message'] ?? ''),
    'scenario' => raw_clean($_POST['scenario'] ?? 'warning'),
];

$phpScenarioTitles = [
    'warning' => 'trigger_error + E_USER_WARNING',
    'notice' => 'trigger_error + E_USER_NOTICE',
];

$mysqlScenarioTitles = [
    'mysqli_connect' => 'mysqli_connect / mysqli_connect_error',
    'mysqli_query' => 'mysqli_query / mysqli_error',
    'mysqli_prepare' => 'mysqli_prepare / mysqli_error',
    'mysqli_stmt_execute' => 'mysqli_stmt_execute / mysqli_stmt_error',
];

$scenarioTitles = $phpScenarioTitles + $mysqlScenarioTitles;

/*
 * Здесь лежат НЕ тексты ошибок, а SQL-запросы, которые специально запускаются
 * для демонстрации ошибок MySQL. Сам текст ошибки берётся ниже из mysqli_error(),
 * mysqli_errno(), mysqli_sqlstate() или mysqli_stmt_error().
 * Для mysqli_connect SQL-запроса нет, потому что это проверка соединения с БД.
 */
$demoSqlTexts = [
    'mysqli_query' => 'SELECT id, login FROM users WHERE',
    'mysqli_prepare' => "INSERT INTO users_demo_broken (full_name, phone, login, email, password_hash, registered_at) VALUES (?, ?, ?, ?, ?, ?)",
    'mysqli_stmt_execute' => "SELECT full_name, phone, login, email FROM users ORDER BY id ASC LIMIT 1;
"
        . "INSERT INTO users (full_name, phone, login, email, password_hash, registered_at) VALUES (?, ?, ?, ?, ?, ?)",
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = raw_clean($_POST['form_action'] ?? 'generate');

    if ($action === 'clear_log') {
        resetDemoLog();
        unset($_SESSION['last_demo_sql'], $_SESSION['last_demo_sql_title']);
        set_flash('success', 'Журналы ошибок очищены.');
        redirectDemo();
    }

    $scenario = $demoForm['scenario'];
    $message = $demoForm['message'];

    if (!isset($scenarioTitles[$scenario])) {
        set_flash('error', 'Не выбран сценарий демонстрации.');
        redirectDemo();
    }

    if ($message === '') {
        $message = 'Демонстрационная пользовательская ошибка для ЛР №5.';
    }

    unset($_SESSION['last_demo_sql'], $_SESSION['last_demo_sql_title']);

    try {
        switch ($scenario) {
            case 'warning':
                trigger_error($message, E_USER_WARNING);
                set_flash('success', 'E_USER_WARNING записан в logs/error_log.xml.');
                break;

            case 'notice':
                trigger_error($message, E_USER_NOTICE);
                set_flash('info', 'E_USER_NOTICE записан в logs/error_log.xml.');
                break;

            case 'mysqli_connect':
                /*
                 * Ошибка подключения к БД. Здесь нет SQL-запроса.
                 * MySQL сам возвращает код и текст ошибки через mysqli_connect_errno()
                 * и mysqli_connect_error().
                 */
                unset($_SESSION['last_demo_sql'], $_SESSION['last_demo_sql_title']);

                $badConn = mysqli_connect('localhost', 'root', '', 'computer_club_missing_demo');
                if (!$badConn) {
                    logMysqliConnectionError(__FILE__, __LINE__);
                    set_flash('error', 'mysqli_connect вернула ошибку MySQL. Смотри logs/mysql_error_log.xml.');
                    break;
                }
                mysqli_close($badConn);
                set_flash('info', 'mysqli_connect неожиданно выполнилась без ошибки.');
                break;

            case 'mysqli_query':
                /* mysqli_query: обычный SQL-запрос. Ошибка берётся из mysqli_error($conn). */
                $sql = $demoSqlTexts['mysqli_query'];
                $_SESSION['last_demo_sql'] = $sql;
                $_SESSION['last_demo_sql_title'] = $scenarioTitles[$scenario];

                $result = mysqli_query($conn, $sql);
                if ($result === false) {
                    logMysqliError($conn, 'mysqli_query', $sql, __FILE__, __LINE__);
                    set_flash('error', 'mysqli_query вернула ошибку MySQL. Смотри logs/mysql_error_log.xml.');
                    break;
                }
                set_flash('info', 'mysqli_query неожиданно выполнилась без ошибки.');
                break;

            case 'mysqli_prepare':
                /* mysqli_prepare: подготовка SQL-запроса. Ошибка берётся из mysqli_error($conn). */
                $sql = $demoSqlTexts['mysqli_prepare'];
                $_SESSION['last_demo_sql'] = $sql;
                $_SESSION['last_demo_sql_title'] = $scenarioTitles[$scenario];

                $stmt = mysqli_prepare($conn, $sql);
                if (!$stmt) {
                    logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
                    set_flash('error', 'mysqli_prepare вернула ошибку MySQL. Смотри logs/mysql_error_log.xml.');
                    break;
                }
                mysqli_stmt_close($stmt);
                set_flash('info', 'mysqli_prepare неожиданно выполнилась без ошибки.');
                break;

            case 'mysqli_stmt_execute':
                /* mysqli_stmt_execute: выполнение подготовленного запроса. Ошибка берётся из mysqli_stmt_error($stmt). */
                $_SESSION['last_demo_sql'] = $demoSqlTexts['mysqli_stmt_execute'];
                $_SESSION['last_demo_sql_title'] = $scenarioTitles[$scenario];

                $selectSql = 'SELECT full_name, phone, login, email FROM users ORDER BY id ASC LIMIT 1';
                $sampleResult = mysqli_query($conn, $selectSql);
                if (!$sampleResult) {
                    logMysqliError($conn, 'mysqli_query', $selectSql, __FILE__, __LINE__);
                    set_flash('error', 'mysqli_query вернула ошибку MySQL при получении тестовой записи.');
                    break;
                }

                $sampleUser = mysqli_fetch_assoc($sampleResult);
                if (!$sampleUser) {
                    set_flash('error', 'В таблице users нет записи, на которой можно показать ошибку повторного INSERT.');
                    break;
                }

                $passwordHash = password_hash('Demo12345', PASSWORD_DEFAULT);
                $registeredAt = date('Y-m-d');
                $insertSql = 'INSERT INTO users (full_name, phone, login, email, password_hash, registered_at) VALUES (?, ?, ?, ?, ?, ?)';
                $stmt = mysqli_prepare($conn, $insertSql);
                if (!$stmt) {
                    logMysqliError($conn, 'mysqli_prepare', $insertSql, __FILE__, __LINE__);
                    set_flash('error', 'mysqli_prepare вернула ошибку MySQL для INSERT.');
                    break;
                }

                if (!mysqli_stmt_bind_param(
                    $stmt,
                    'ssssss',
                    $sampleUser['full_name'],
                    $sampleUser['phone'],
                    $sampleUser['login'],
                    $sampleUser['email'],
                    $passwordHash,
                    $registeredAt
                )) {
                    logMysqliStmtError($stmt, 'mysqli_stmt_bind_param', $insertSql, __FILE__, __LINE__);
                    mysqli_stmt_close($stmt);
                    set_flash('error', 'mysqli_stmt_bind_param вернула ошибку MySQLi.');
                    break;
                }

                if (!mysqli_stmt_execute($stmt)) {
                    logMysqliStmtError($stmt, 'mysqli_stmt_execute', $insertSql, __FILE__, __LINE__);
                    mysqli_stmt_close($stmt);
                    set_flash('error', 'mysqli_stmt_execute вернула ошибку MySQL. Смотри logs/mysql_error_log.xml.');
                    break;
                }

                mysqli_stmt_close($stmt);
                set_flash('info', 'mysqli_stmt_execute неожиданно выполнилась без ошибки.');
                break;
        }
    } catch (Throwable $e) {
        set_flash('error', $e->getMessage());
    }

    redirectDemo();
}

$entries = readPhpLogEntries(10);
$mysqlEntries = readMysqlLogEntries(10);
$latestEntry = $entries[0] ?? null;
$latestMysqlEntry = $mysqlEntries[0] ?? null;
$lastDemoSql = $_SESSION['last_demo_sql'] ?? '';
$lastDemoSqlTitle = $_SESSION['last_demo_sql_title'] ?? 'Последний SQL-запрос';
$exceptionDemoUrl = 'error_demo.php?demo_throw=1';
$fatalDemoUrl = 'error_demo.php?demo_fatal=1';

$allDemoSqlPreview = '';
foreach ($demoSqlTexts as $key => $sqlText) {
    $allDemoSqlPreview .= $scenarioTitles[$key] . ":
" . $sqlText . "

";
}
$allDemoSqlPreview = trim($allDemoSqlPreview);

require_once __DIR__ . '/header.php';
?>
<style>
.edemo-wrap {
    padding: 34px 0 64px;
}
.edemo-shell {
    display: grid;
    gap: 22px;
}
.edemo-hero,
.edemo-card,
.edemo-log-card {
    position: relative;
    overflow: hidden;
    border-radius: 28px;
    border: 1px solid rgba(115, 140, 255, 0.18);
    background:
        radial-gradient(circle at top right, rgba(113, 93, 255, 0.18), transparent 30%),
        linear-gradient(180deg, rgba(9, 18, 56, 0.96), rgba(6, 12, 38, 0.96));
    box-shadow: 0 18px 48px rgba(0, 0, 0, 0.24);
}
.edemo-hero::before,
.edemo-card::before,
.edemo-log-card::before {
    content: '';
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: linear-gradient(135deg, rgba(255,255,255,0.05), transparent 28%, transparent 72%, rgba(255,255,255,0.03));
}
.edemo-hero {
    padding: 30px 32px;
}
.edemo-hero-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.8fr) minmax(260px, 0.8fr);
    gap: 18px;
    align-items: start;
}
.edemo-kicker {
    display: inline-flex;
    padding: 7px 12px;
    border-radius: 999px;
    margin-bottom: 14px;
    background: rgba(124, 106, 255, 0.14);
    border: 1px solid rgba(124, 106, 255, 0.28);
    color: #c7d4ff;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}
.edemo-title {
    margin: 0 0 12px;
    font-size: clamp(32px, 5vw, 56px);
    line-height: 1.04;
    color: #f7f9ff;
}
.edemo-text {
    margin: 0;
    max-width: 860px;
    color: #d6ddff;
    line-height: 1.75;
    font-size: 16px;
}
.edemo-text code,
.edemo-hint code,
.edemo-help code {
    padding: 2px 8px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.08);
    color: #f4f7ff;
    font-family: Consolas, Monaco, monospace;
    font-size: 0.94em;
}
.edemo-side {
    display: grid;
    gap: 14px;
}
.edemo-mini {
    position: relative;
    z-index: 1;
    padding: 18px 18px 16px;
    border-radius: 22px;
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.edemo-mini-label {
    display: block;
    margin-bottom: 8px;
    color: #c8d5ff;
    font-size: 13px;
    font-weight: 700;
}
.edemo-mini-value {
    display: block;
    color: #ffffff;
    font-size: 28px;
    line-height: 1.1;
    font-weight: 800;
    word-break: break-word;
}
.edemo-grid {
    display: grid;
    grid-template-columns: minmax(380px, 0.95fr) minmax(0, 1.35fr);
    gap: 22px;
    align-items: start;
}
.edemo-card,
.edemo-log-card {
    padding: 26px;
}
.edemo-card-title {
    margin: 0 0 10px;
    color: #ffffff;
    font-size: 20px;
}
.edemo-subtitle {
    margin: 0 0 18px;
    color: #cfd8ff;
    line-height: 1.65;
}
.edemo-form {
    position: relative;
    z-index: 1;
    display: grid;
    gap: 16px;
}
.edemo-demo-block {
    position: relative;
    z-index: 1;
    display: grid;
    gap: 18px;
}
.edemo-demo-section {
    padding: 18px;
    border-radius: 22px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(255, 255, 255, 0.035);
}
.edemo-demo-section--mysql {
    border-color: rgba(89, 216, 154, 0.2);
    background: rgba(89, 216, 154, 0.045);
}
.edemo-section-title {
    margin: 0 0 8px;
    color: #ffffff;
    font-size: 17px;
    font-weight: 900;
}
.edemo-section-note {
    margin: 0 0 14px;
    color: #cfd8ff;
    line-height: 1.55;
    font-size: 14px;
}
.edemo-field {
    display: grid;
    gap: 8px;
}
.edemo-label {
    color: #eef2ff;
    font-weight: 700;
    font-size: 14px;
}
.edemo-textarea,
.edemo-select {
    width: 100%;
    min-width: 0;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 18px;
    background: rgba(4, 10, 32, 0.82);
    color: #f6f8ff;
    padding: 16px 16px;
    font: inherit;
    box-sizing: border-box;
    outline: none;
    transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
}
.edemo-textarea {
    min-height: 136px;
    resize: vertical;
    line-height: 1.55;
}
.edemo-textarea:focus,
.edemo-select:focus {
    border-color: rgba(125, 143, 255, 0.75);
    box-shadow: 0 0 0 4px rgba(97, 118, 255, 0.14);
}
.edemo-select {
    appearance: none;
    background-image:
        linear-gradient(45deg, transparent 50%, #d8e0ff 50%),
        linear-gradient(135deg, #d8e0ff 50%, transparent 50%);
    background-position:
        calc(100% - 22px) calc(50% - 4px),
        calc(100% - 16px) calc(50% - 4px);
    background-size: 6px 6px, 6px 6px;
    background-repeat: no-repeat;
    padding-right: 44px;
}
.edemo-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}
.edemo-button,
.edemo-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 54px;
    padding: 0 18px;
    border-radius: 18px;
    border: 1px solid transparent;
    text-decoration: none;
    font-weight: 800;
    font-size: 16px;
    cursor: pointer;
    transition: transform .16s ease, box-shadow .16s ease, border-color .16s ease, opacity .16s ease;
}
.edemo-button:hover,
.edemo-link:hover {
    transform: translateY(-1px);
}
.edemo-button:active,
.edemo-link:active {
    transform: translateY(0);
}
.edemo-button--primary {
    background: linear-gradient(135deg, #7b8cff, #6177ff);
    color: #ffffff;
    box-shadow: 0 10px 26px rgba(97, 119, 255, 0.26);
}
.edemo-button--danger {
    background: linear-gradient(135deg, #f17074, #e55260);
    color: #ffffff;
    box-shadow: 0 10px 26px rgba(229, 82, 96, 0.22);
}
.edemo-link {
    grid-column: 1 / -1;
    border-color: rgba(255, 255, 255, 0.14);
    background: rgba(255, 255, 255, 0.03);
    color: #f8faff;
}
.edemo-help {
    margin: 2px 0 0;
    color: #aebce7;
    font-size: 14px;
    line-height: 1.65;
}
.edemo-stats {
    display: flex;
    flex-wrap: nowrap;
    gap: 12px;
    margin-top: 8px;
}
.edemo-stat {
    position: relative;
    z-index: 1;
    flex: 1 1 0;
    min-width: 0;
    padding: 14px 16px;
    border-radius: 18px;
    background: rgba(255, 255, 255, 0.035);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.edemo-stat-number {
    display: block;
    margin-bottom: 6px;
    color: #ffffff;
    font-size: 22px;
    line-height: 1.18;
    font-weight: 900;
    overflow-wrap: anywhere;
}
.edemo-stat-label {
    display: block;
    color: #c9d4ff;
    line-height: 1.4;
    font-size: 13px;
}
.edemo-stat:nth-child(2) .edemo-stat-number {
    font-size: 16px;
}
.edemo-log {
    position: relative;
    z-index: 1;
    display: grid;
    gap: 14px;
}
.edemo-empty {
    padding: 28px;
    border-radius: 22px;
    border: 1px dashed rgba(255, 255, 255, 0.14);
    background: rgba(255, 255, 255, 0.02);
    color: #cdd7ff;
    line-height: 1.7;
}
.edemo-entry {
    padding: 18px 18px 16px;
    border-radius: 22px;
    background: rgba(255, 255, 255, 0.035);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
.edemo-entry-top {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    margin-bottom: 10px;
}
.edemo-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 12px;
    border-radius: 999px;
    background: rgba(255, 209, 96, 0.1);
    border: 1px solid rgba(255, 209, 96, 0.24);
    color: #ffe3a2;
    font-size: 12px;
    font-weight: 800;
}
.edemo-time {
    color: #c7d2ff;
    font-size: 13px;
    font-weight: 700;
}
.edemo-message {
    margin: 0 0 10px;
    color: #ffffff;
    line-height: 1.65;
    font-size: 16px;
}
.edemo-meta {
    color: #b8c5ef;
    line-height: 1.55;
    font-size: 14px;
    word-break: break-word;
}
.edemo-sql-box {
    padding: 14px 16px;
    border-radius: 18px;
    background: rgba(0, 0, 0, 0.22);
    border: 1px solid rgba(255, 255, 255, 0.1);
}
.edemo-sql-title {
    display: block;
    margin-bottom: 8px;
    color: #eef2ff;
    font-weight: 800;
    font-size: 14px;
}
.edemo-sql-code {
    margin: 0;
    color: #f7f9ff;
    white-space: pre-wrap;
    word-break: break-word;
    font-family: Consolas, Monaco, monospace;
    font-size: 13px;
    line-height: 1.55;
}
@media (max-width: 1180px) {
    .edemo-hero-grid,
    .edemo-grid {
        grid-template-columns: 1fr;
    }
}
@media (max-width: 760px) {
    .edemo-wrap {
        padding: 24px 0 44px;
    }
    .edemo-hero,
    .edemo-card,
    .edemo-log-card {
        padding: 20px;
        border-radius: 22px;
    }
    .edemo-actions {
        grid-template-columns: 1fr;
    }
    .edemo-stats {
        flex-direction: column;
    }
    .edemo-title {
        font-size: 34px;
    }
    .edemo-mini-value,
    .edemo-stat-number {
        font-size: 24px;
    }
}
</style>
<main class="container edemo-wrap">
    <div class="edemo-shell">
        <section class="edemo-hero">
            <div class="edemo-hero-grid">
                <div>
                    <span class="edemo-kicker">ЛР 5 · Демонстрационный стенд</span>
                    <h1 class="edemo-title">Пользовательский обработчик ошибок</h1>
                    <p class="edemo-text">
                        Эта страница сделана как отдельный стенд для защиты ЛР №5. В одном генераторе можно показать
                        пользовательские PHP-ошибки через <code>trigger_error()</code> и реальные ошибки SQL/MySQL,
                        которые возвращают стандартные функции <code>mysqli_connect_error()</code>, <code>mysqli_error()</code>,
                        <code>mysqli_errno()</code>, <code>mysqli_sqlstate()</code> и <code>mysqli_stmt_error()</code>.
                    </p>
                </div>
                <aside class="edemo-side">
                    <div class="edemo-mini">
                        <span class="edemo-mini-label">Последняя PHP-запись</span>
                        <span class="edemo-mini-value"><?= htmlspecialchars($latestEntry['datetime'] ?? 'Журнал пуст', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                    </div>
                    <div class="edemo-mini">
                        <span class="edemo-mini-label">PHP-лог</span>
                        <span class="edemo-mini-value">logs/error_log.xml</span>
                    </div>
                    <div class="edemo-mini">
                        <span class="edemo-mini-label">MySQL-лог</span>
                        <span class="edemo-mini-value">logs/mysql_error_log.xml</span>
                    </div>
                </aside>
            </div>
        </section>

        <section class="edemo-grid">
            <div class="edemo-card">
                <h2 class="edemo-card-title">Генератор ошибок</h2>
                <p class="edemo-subtitle">
                    Всё снова в одном блоке, как раньше. В выпадающем списке две группы: сначала PHP/пользовательские ошибки,
                    затем SQL/MySQL-ошибки, которые возвращает сама база.
                </p>

                <form method="post" class="edemo-form">
                    <div class="edemo-field">
                        <label class="edemo-label" for="demo-message">Сообщение пользовательской ошибки</label>
                        <textarea class="edemo-textarea" id="demo-message" name="message" placeholder="Например: Демонстрационное пользовательское предупреждение для ЛР 5."><?= htmlspecialchars($demoForm['message'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></textarea>
                    </div>

                    <div class="edemo-field">
                        <label class="edemo-label" for="scenario">Сценарий</label>
                        <select class="edemo-select" id="scenario" name="scenario">
                            <optgroup label="PHP / пользовательские ошибки">
                                <?php foreach ($phpScenarioTitles as $key => $title) { ?>
                                    <option value="<?= htmlspecialchars($key, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>"<?= $demoForm['scenario'] === $key ? ' selected' : '' ?>>
                                        <?= htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
                                    </option>
                                <?php } ?>
                            </optgroup>
                            <optgroup label="SQL / MySQL ошибки от БД">
                                <?php foreach ($mysqlScenarioTitles as $key => $title) { ?>
                                    <option value="<?= htmlspecialchars($key, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>"<?= $demoForm['scenario'] === $key ? ' selected' : '' ?>>
                                        <?= htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
                                    </option>
                                <?php } ?>
                            </optgroup>
                        </select>
                    </div>

                    <?php if ($lastDemoSql !== '') { ?>
                        <div class="edemo-sql-box">
                            <span class="edemo-sql-title">SQL-запрос последней проверки: <?= htmlspecialchars($lastDemoSqlTitle, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                            <pre class="edemo-sql-code"><?= htmlspecialchars($lastDemoSql, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></pre>
                        </div>
                    <?php } ?>

                    <div class="edemo-sql-box">
                        <span class="edemo-sql-title">Все SQL-запросы для демонстрации MySQL-ошибок</span>
                        <pre class="edemo-sql-code"><?= htmlspecialchars($allDemoSqlPreview, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></pre>
                    </div>

                    <div class="edemo-actions">
                        <button type="submit" name="form_action" value="generate" class="edemo-button edemo-button--primary">Сгенерировать</button>
                        <button type="submit" name="form_action" value="clear_log" class="edemo-button edemo-button--danger">Очистить журналы</button>
                        <a class="edemo-link" href="<?= htmlspecialchars($exceptionDemoUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" target="_blank" rel="noopener">Показать непойманное исключение</a>
                        <a class="edemo-link" href="<?= htmlspecialchars($fatalDemoUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" target="_blank" rel="noopener">Показать фатальную ошибку require</a>
                        <a class="edemo-link" href="logs/error_log.xml" target="_blank" rel="noopener">Открыть PHP-лог</a>
                        <a class="edemo-link" href="logs/mysql_error_log.xml" target="_blank" rel="noopener">Открыть MySQL-лог</a>
                    </div>
                </form>

                <p class="edemo-help">
                    Пользовательские ошибки пишутся в <code>logs/error_log.xml</code>. MySQL-ошибки пишутся отдельно в
                    <code>logs/mysql_error_log.xml</code>. В SQL-логе текст <code>message</code>, <code>errno</code> и
                    <code>sqlstate</code> берутся из MySQLi-функций, а не придумываются вручную.
                </p>

                <div class="edemo-stats">
                    <div class="edemo-stat">
                        <span class="edemo-stat-number"><?= count($entries) ?></span>
                        <span class="edemo-stat-label">PHP-ошибок выведено</span>
                    </div>
                    <div class="edemo-stat">
                        <span class="edemo-stat-number"><?= count($mysqlEntries) ?></span>
                        <span class="edemo-stat-label">MySQL-ошибок выведено</span>
                    </div>
                    <div class="edemo-stat">
                        <span class="edemo-stat-number"><?= htmlspecialchars($latestMysqlEntry['errno'] ?? '—', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                        <span class="edemo-stat-label">последний errno MySQL</span>
                    </div>
                </div>
            </div>

            <div class="edemo-log-card">
                <h2 class="edemo-card-title">Последние PHP-ошибки</h2>
                <p class="edemo-subtitle">Здесь ошибки, которые прошли через <code>set_error_handler()</code>, <code>trigger_error()</code>, обработчик исключений или обработчик фатальных ошибок.</p>

                <?php if (!$entries) { ?>
                    <div class="edemo-empty">PHP-журнал пуст. Сгенерируй E_USER_WARNING, E_USER_NOTICE или непойманное исключение.</div>
                <?php } else { ?>
                    <div class="edemo-log">
                        <?php foreach ($entries as $entry) { ?>
                            <article class="edemo-entry">
                                <div class="edemo-entry-top">
                                    <span class="edemo-badge">[<?= htmlspecialchars($entry['errornum'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>] <?= htmlspecialchars($entry['errortype'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                                    <span class="edemo-time"><?= htmlspecialchars($entry['datetime'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                                </div>
                                <p class="edemo-message"><?= htmlspecialchars($entry['errormsg'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></p>
                                <div class="edemo-meta">
                                    Файл: <?= htmlspecialchars($entry['scriptname'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?><br>
                                    Строка: <?= htmlspecialchars($entry['scriptlinenum'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
                                </div>
                            </article>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>

            <div class="edemo-log-card">
                <h2 class="edemo-card-title">Последние ошибки MySQL</h2>
                <p class="edemo-subtitle">Здесь реальные ошибки MySQL: функция MySQLi, SQL-запрос, errno, SQLSTATE и английский текст ошибки.</p>

                <?php if (!$mysqlEntries) { ?>
                    <div class="edemo-empty">MySQL-журнал пуст. Выбери сценарий mysqli_connect, mysqli_query, mysqli_prepare или mysqli_stmt_execute.</div>
                <?php } else { ?>
                    <div class="edemo-log">
                        <?php foreach ($mysqlEntries as $entry) { ?>
                            <article class="edemo-entry">
                                <div class="edemo-entry-top">
                                    <span class="edemo-badge"><?= htmlspecialchars($entry['function'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?> · errno <?= htmlspecialchars($entry['errno'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                                    <span class="edemo-time"><?= htmlspecialchars($entry['datetime'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></span>
                                </div>
                                <p class="edemo-message"><?= htmlspecialchars($entry['message'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></p>
                                <?php if ($entry['sql'] !== '') { ?>
                                    <div class="edemo-sql-box">
                                        <span class="edemo-sql-title">SQL</span>
                                        <pre class="edemo-sql-code"><?= htmlspecialchars($entry['sql'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></pre>
                                    </div>
                                <?php } ?>
                                <div class="edemo-meta">
                                    SQLSTATE: <?= htmlspecialchars($entry['sqlstate'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?><br>
                                    Файл: <?= htmlspecialchars($entry['scriptname'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?><br>
                                    Строка: <?= htmlspecialchars($entry['scriptlinenum'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
                                </div>
                            </article>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </section>
    </div>
</main>
<?php require_once __DIR__ . '/footer.php'; ?>
