<?php
require_once __DIR__ . '/admin_auth.php';
admin_require_login();
require_once __DIR__ . '/error_handler.php';
registerErrorHandler();
require_once __DIR__ . '/db_connect.php';

function f_text(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function f_clean(string $value): string
{
    return trim($value);
}

function fetch_all_assoc(mysqli_result $result): array
{
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

$errors = [];
$computerId = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
$isEdit = $computerId > 0;
$currentPhoto = '';

$form = [
    'zone_id' => '',
    'tariff_id' => '',
    'pc_name' => '',
    'short_description' => '',
    'cpu' => '',
    'gpu' => '',
    'ram' => '16',
    'monitor_hz' => '165',
    'monitor_model' => '',
    'keyboard_model' => '',
    'mouse_model' => '',
    'headset_model' => '',
    'chair_model' => '',
    'release_year' => date('Y'),
    'photo' => 'pc1.jpg',
    'is_vip' => '0',
    'is_maintenance' => '0',
];

$zonesResult = mysqli_query($conn, "SELECT z.id, z.zone_name, c.club_name FROM zones z JOIN clubs c ON z.club_id = c.id ORDER BY c.club_name, z.zone_name");
$tariffsResult = mysqli_query($conn, "SELECT id, tariff_name, price_per_hour FROM tariffs ORDER BY id ASC");
$zones = $zonesResult ? fetch_all_assoc($zonesResult) : [];
$tariffs = $tariffsResult ? fetch_all_assoc($tariffsResult) : [];

if ($isEdit) {
    $stmt = mysqli_prepare($conn, 'SELECT * FROM computers WHERE id = ? AND is_active = 1 LIMIT 1');
    if (!$stmt) {
        logMysqliError($conn, 'mysqli_prepare', 'SELECT * FROM computers WHERE id = ? AND is_active = 1 LIMIT 1', __FILE__, __LINE__);
        $errors[] = 'Не удалось подготовить получение игрового места.';
    } else {
        mysqli_stmt_bind_param($stmt, 'i', $computerId);
        if (!mysqli_stmt_execute($stmt)) {
            logMysqliStmtError($stmt, 'mysqli_stmt_execute', 'SELECT * FROM computers WHERE id = ? AND is_active = 1 LIMIT 1', __FILE__, __LINE__);
            $errors[] = 'Не удалось получить игровое место.';
        } else {
            $computer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            if ($computer) {
                foreach ($form as $key => $_) {
                    $form[$key] = (string) ($computer[$key] ?? $form[$key]);
                }
                $currentPhoto = (string) ($computer['photo'] ?? '');
            } else {
                $errors[] = 'Игровое место не найдено.';
                $isEdit = false;
                $computerId = 0;
            }
        }
        mysqli_stmt_close($stmt);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $key => $_) {
        $form[$key] = f_clean((string) ($_POST[$key] ?? ''));
    }
    $computerId = (int) ($_POST['computer_id'] ?? 0);
    $isEdit = $computerId > 0;
    $currentPhoto = f_clean((string) ($_POST['current_photo'] ?? ''));

    if ((int) $form['zone_id'] <= 0) $errors[] = 'Выберите зону.';
    if ((int) $form['tariff_id'] <= 0) $errors[] = 'Выберите тариф.';
    if ($form['pc_name'] === '') $errors[] = 'Введите название игрового места.';
    if (mb_strlen($form['short_description']) > 220) $errors[] = 'Короткое описание должно быть не длиннее 220 символов.';
    if ($form['cpu'] === '') $errors[] = 'Введите процессор.';
    if ($form['gpu'] === '') $errors[] = 'Введите видеокарту.';
    if ((int) $form['ram'] <= 0) $errors[] = 'Введите корректный объём RAM.';
    if ((int) $form['release_year'] < 2018 || (int) $form['release_year'] > 2035) $errors[] = 'Введите корректный год выпуска.';
    if ($form['photo'] === '') {
        if ($isEdit && $currentPhoto !== '') {
            $form['photo'] = $currentPhoto;
        } else {
            $form['photo'] = 'pc1.jpg';
        }
    }
    $form['is_vip'] = ((int) $form['is_vip']) === 1 ? '1' : '0';
    $form['is_maintenance'] = ((int) $form['is_maintenance']) === 1 ? '1' : '0';

    if (!$errors) {
        if ($isEdit) {
            $sql = 'UPDATE computers SET zone_id=?, tariff_id=?, pc_name=?, short_description=?, cpu=?, gpu=?, ram=?, monitor_hz=?, monitor_model=?, keyboard_model=?, mouse_model=?, headset_model=?, chair_model=?, release_year=?, photo=?, is_vip=?, is_maintenance=? WHERE id=?';
            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) {
                logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
                $errors[] = 'Не удалось подготовить изменение игрового места.';
            } else {
                $zoneId = (int) $form['zone_id'];
                $tariffId = (int) $form['tariff_id'];
                $ram = (int) $form['ram'];
                $monitorHz = $form['monitor_hz'] === '' ? null : (int) $form['monitor_hz'];
                $releaseYear = (int) $form['release_year'];
                $isVip = (int) $form['is_vip'];
                $isMaintenance = (int) $form['is_maintenance'];
                mysqli_stmt_bind_param($stmt, 'iissssiisssssisiii', $zoneId, $tariffId, $form['pc_name'], $form['short_description'], $form['cpu'], $form['gpu'], $ram, $monitorHz, $form['monitor_model'], $form['keyboard_model'], $form['mouse_model'], $form['headset_model'], $form['chair_model'], $releaseYear, $form['photo'], $isVip, $isMaintenance, $computerId);
                if (!mysqli_stmt_execute($stmt)) {
                    logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
                    $errors[] = 'Не удалось изменить игровое место.';
                } else {
                    mysqli_stmt_close($stmt);
                    header('Location: admin.php?section=computers');
                    exit;
                }
                mysqli_stmt_close($stmt);
            }
        } else {
            $sql = 'INSERT INTO computers (zone_id, tariff_id, pc_name, short_description, cpu, gpu, ram, monitor_hz, monitor_model, keyboard_model, mouse_model, headset_model, chair_model, release_year, photo, is_vip, is_maintenance, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)';
            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) {
                logMysqliError($conn, 'mysqli_prepare', $sql, __FILE__, __LINE__);
                $errors[] = 'Не удалось подготовить добавление игрового места.';
            } else {
                $zoneId = (int) $form['zone_id'];
                $tariffId = (int) $form['tariff_id'];
                $ram = (int) $form['ram'];
                $monitorHz = $form['monitor_hz'] === '' ? null : (int) $form['monitor_hz'];
                $releaseYear = (int) $form['release_year'];
                $isVip = (int) $form['is_vip'];
                $isMaintenance = (int) $form['is_maintenance'];
                mysqli_stmt_bind_param($stmt, 'iissssiisssssisii', $zoneId, $tariffId, $form['pc_name'], $form['short_description'], $form['cpu'], $form['gpu'], $ram, $monitorHz, $form['monitor_model'], $form['keyboard_model'], $form['mouse_model'], $form['headset_model'], $form['chair_model'], $releaseYear, $form['photo'], $isVip, $isMaintenance);
                if (!mysqli_stmt_execute($stmt)) {
                    logMysqliStmtError($stmt, 'mysqli_stmt_execute', $sql, __FILE__, __LINE__);
                    $errors[] = 'Не удалось добавить игровое место.';
                } else {
                    mysqli_stmt_close($stmt);
                    header('Location: admin.php?section=computers');
                    exit;
                }
                mysqli_stmt_close($stmt);
            }
        }
    }
}
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Изменить игровое место' : 'Добавить игровое место' ?></title>
    <style>
        :root{
            --bg:#f4f6f9;
            --card:#ffffff;
            --line:#d8dde6;
            --line-strong:#b8c0cc;
            --text:#1f2937;
            --muted:#6b7280;
            --soft:#eef2f7;
            --dark:#303846;
            --dark-hover:#202633;
            --danger-bg:#fff1f2;
            --danger-line:#fecdd3;
            --danger-text:#9f1239;
        }
        *{box-sizing:border-box}
        body{
            margin:0;
            font-family:Arial,sans-serif;
            background:var(--bg);
            color:var(--text);
        }
        .top{
            background:#ffffff;
            border-bottom:1px solid var(--line);
            padding:18px 24px 14px;
            display:flex;
            justify-content:center;
            align-items:center;
            position:relative;
            box-shadow:0 1px 0 rgba(17,24,39,.03);
        }
        .top strong{font-size:26px;color:var(--text)}
        .top-meta{position:absolute;right:24px;top:50%;transform:translateY(-50%);font-size:14px;color:var(--muted)}
        .top a{color:#374151;text-decoration:none;font-weight:bold}
        .top a:hover{text-decoration:underline}
        .admin-nav{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;align-items:center;border-bottom:1px solid var(--line);padding:16px 20px;background:#eef2f7;box-shadow:0 2px 10px rgba(31,41,55,.05)}
        .admin-nav a{border:1px solid var(--line-strong);border-radius:999px;padding:11px 22px;text-decoration:none;background:#fff;color:var(--text);font-weight:bold;font-size:16px;min-width:120px;text-align:center}
        .admin-nav a:hover{background:#e2e8f0;text-decoration:none}
        .admin-nav a.active{background:var(--dark);border-color:var(--dark);color:#fff}
        .wrap{
            min-height:calc(100vh - 54px);
            padding:28px 18px 42px;
            display:flex;
            justify-content:center;
            align-items:flex-start;
        }
        .box{
            width:100%;
            max-width:1040px;
            margin:0 auto;
            border:1px solid var(--line);
            border-radius:18px;
            background:var(--card);
            padding:26px;
            box-shadow:0 18px 45px rgba(31,41,55,.08);
        }
        h1{
            margin:0 0 20px;
            font-size:28px;
            line-height:1.2;
            color:var(--text);
        }
        .grid{
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:16px 18px;
        }
        label{
            display:block;
            font-weight:700;
            margin-bottom:7px;
            color:#374151;
            font-size:14px;
        }
        input,select,textarea{
            width:100%;
            border:1px solid var(--line-strong);
            border-radius:10px;
            padding:10px 12px;
            background:#fff;
            color:var(--text);
            font:inherit;
            outline:none;
            transition:border-color .15s ease, box-shadow .15s ease, background .15s ease;
        }
        input:focus,select:focus,textarea:focus{
            border-color:#8da2c0;
            box-shadow:0 0 0 3px rgba(141,162,192,.22);
            background:#fff;
        }
        textarea{resize:vertical;min-height:82px}
        .full{grid-column:1/-1}
        .actions{
            display:flex;
            gap:10px;
            margin-top:22px;
            padding-top:18px;
            border-top:1px solid var(--line);
        }
        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            border:1px solid var(--line-strong);
            border-radius:10px;
            background:#fff;
            color:var(--text);
            padding:10px 16px;
            font-weight:700;
            text-decoration:none;
            cursor:pointer;
            min-height:40px;
        }
        .btn:hover{background:var(--soft)}
        .btn-dark{
            background:var(--dark);
            border-color:var(--dark);
            color:#fff;
        }
        .btn-dark:hover{background:var(--dark-hover)}
        .error{
            border:1px solid var(--danger-line);
            border-radius:12px;
            background:var(--danger-bg);
            color:var(--danger-text);
            padding:12px 14px;
            margin-bottom:18px;
            font-weight:700;
        }
        .hint{
            font-size:12px;
            color:var(--muted);
            margin-top:6px;
            line-height:1.45;
        }
        @media(max-width:800px){
            .grid{grid-template-columns:1fr}
            .top{display:block;line-height:1.8}
            .box{padding:18px;border-radius:14px}
            .actions{flex-wrap:wrap}
        }
    </style>
</head>
<body>
<div class="top"><strong>Административная панель</strong><div class="top-meta">Админ: <?= f_text($_SESSION['plain_admin_login'] ?? '') ?> | <a href="admin_logout.php">Выход</a> | <a href="index.php">На сайт</a></div></div>
<nav class="admin-nav">
    <a href="admin.php?section=clients">Клиенты</a>
    <a href="admin.php?section=requests">Заявки восстановления</a>
    <a class="active" href="admin.php?section=computers">Игровые места</a>
</nav>
<div class="wrap">
    <div class="box">
        <h1><?= $isEdit ? 'Изменить игровое место' : 'Добавить игровое место' ?></h1>
        <?php if ($errors) { ?><div class="error"><?php foreach ($errors as $error) { ?><div><?= f_text($error) ?></div><?php } ?></div><?php } ?>
        <form method="post">
            <input type="hidden" name="computer_id" value="<?= (int) $computerId ?>">
            <input type="hidden" name="current_photo" value="<?= f_text($currentPhoto !== '' ? $currentPhoto : $form['photo']) ?>">
            <div class="grid">
                <div><label>Название</label><input type="text" name="pc_name" value="<?= f_text($form['pc_name']) ?>" required></div>
                <div class="full"><label>Короткое описание для карточки</label><textarea name="short_description" rows="3" maxlength="220" placeholder="Например: Сбалансированное место для быстрых матчей и вечерних игр."><?= f_text($form['short_description']) ?></textarea><div class="hint">Показывается на карточке, когда место доступно. Если место на обслуживании, вместо описания выводится плашка недоступности.</div></div>
                <div>
                    <label>Фото</label>
                    <input type="text" name="photo" value="<?= f_text($form['photo']) ?>" placeholder="pc1.jpg">
                    <?php if ($isEdit) { ?>
                        <div class="hint">Если поле оставить пустым, сохранится текущая фотография: <?= f_text($currentPhoto !== '' ? $currentPhoto : $form['photo']) ?></div>
                    <?php } ?>
                </div>
                <div><label>Зона</label><select name="zone_id" required><option value="">Выберите зону</option><?php foreach ($zones as $zone) { ?><option value="<?= (int) $zone['id'] ?>" <?= (int)$form['zone_id'] === (int)$zone['id'] ? 'selected' : '' ?>><?= f_text($zone['club_name'] . ' / ' . $zone['zone_name']) ?></option><?php } ?></select></div>
                <div><label>Тариф</label><select name="tariff_id" required><option value="">Выберите тариф</option><?php foreach ($tariffs as $tariff) { ?><option value="<?= (int) $tariff['id'] ?>" <?= (int)$form['tariff_id'] === (int)$tariff['id'] ? 'selected' : '' ?>><?= f_text($tariff['tariff_name'] . ' / ' . $tariff['price_per_hour'] . ' Р/час') ?></option><?php } ?></select></div>
                <div><label>CPU</label><input type="text" name="cpu" value="<?= f_text($form['cpu']) ?>" required></div>
                <div><label>GPU</label><input type="text" name="gpu" value="<?= f_text($form['gpu']) ?>" required></div>
                <div><label>RAM, ГБ</label><input type="number" name="ram" min="1" value="<?= f_text($form['ram']) ?>" required></div>
                <div><label>Герцовка монитора</label><input type="number" name="monitor_hz" min="0" value="<?= f_text($form['monitor_hz']) ?>"></div>
                <div><label>Модель монитора</label><input type="text" name="monitor_model" value="<?= f_text($form['monitor_model']) ?>"></div>
                <div><label>Клавиатура</label><input type="text" name="keyboard_model" value="<?= f_text($form['keyboard_model']) ?>"></div>
                <div><label>Мышь</label><input type="text" name="mouse_model" value="<?= f_text($form['mouse_model']) ?>"></div>
                <div><label>Гарнитура</label><input type="text" name="headset_model" value="<?= f_text($form['headset_model']) ?>"></div>
                <div><label>Кресло</label><input type="text" name="chair_model" value="<?= f_text($form['chair_model']) ?>"></div>
                <div><label>Год выпуска</label><input type="number" name="release_year" min="2018" max="2035" value="<?= f_text($form['release_year']) ?>" required></div>
                <div><label>VIP</label><select name="is_vip"><option value="0" <?= $form['is_vip']==='0'?'selected':'' ?>>Нет</option><option value="1" <?= $form['is_vip']==='1'?'selected':'' ?>>Да</option></select></div>
                <div><label>Обслуживание</label><select name="is_maintenance"><option value="0" <?= $form['is_maintenance']==='0'?'selected':'' ?>>В работе</option><option value="1" <?= $form['is_maintenance']==='1'?'selected':'' ?>>На обслуживании</option></select></div>
            </div>
            <div class="actions"><button class="btn btn-dark" type="submit"><?= $isEdit ? 'Сохранить' : 'Добавить' ?></button><a class="btn" href="admin.php?section=computers">Отмена</a></div>
        </form>
    </div>
</div>
</body>
</html>
