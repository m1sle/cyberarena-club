<?php
function ensure_counter_exists(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $sqlCreate = "CREATE TABLE IF NOT EXISTS site_stats (
        id TINYINT NOT NULL PRIMARY KEY,
        visit_count INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    if (!mysqli_query($conn, $sqlCreate)) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return;
    }

    if (!mysqli_query($conn, 'INSERT IGNORE INTO site_stats (id, visit_count) VALUES (1, 0)')) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return;
    }

    $checked = true;
}

function count_visit_once_per_session(mysqli $conn): void
{
    ensure_counter_exists($conn);

    if (empty($_SESSION['visit_counted'])) {
        if (!mysqli_query($conn, 'UPDATE site_stats SET visit_count = visit_count + 1 WHERE id = 1')) {
            logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
            return;
        }
        $_SESSION['visit_counted'] = true;
    }
}

function get_visit_count(mysqli $conn): int
{
    ensure_counter_exists($conn);

    $result = mysqli_query($conn, 'SELECT visit_count FROM site_stats WHERE id = 1 LIMIT 1');
    if (!$result) {
        logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
        return 0;
    }

    $row = mysqli_fetch_assoc($result);
    return $row ? (int) $row['visit_count'] : 0;
}
