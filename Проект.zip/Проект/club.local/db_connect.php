<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'computer_club';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    logMysqliConnectionError(__FILE__, __LINE__);
    showSystemError();
}

if (!mysqli_set_charset($conn, 'utf8mb4')) {
    logMysqliError($conn, 'mysqli_set_charset', 'SET NAMES utf8mb4', __FILE__, __LINE__);
    showSystemError();
}
