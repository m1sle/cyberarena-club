<?php
require_once __DIR__ . '/error_handler.php';
registerErrorHandler();
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/counter.php';

count_visit_once_per_session($conn);
