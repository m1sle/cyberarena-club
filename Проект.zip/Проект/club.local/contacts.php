<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Контакты | CyberArena';
$errors = [];

$form = [
    'name' => '',
    'email' => '',
    'subject' => '',
    'message' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['name'] = raw_clean($_POST['name'] ?? '');
    $form['email'] = raw_clean($_POST['email'] ?? '');
    $form['subject'] = raw_clean($_POST['subject'] ?? '');
    $form['message'] = raw_clean($_POST['message'] ?? '');

    if ($form['name'] === '') {
        $errors[] = 'Укажите имя.';
    }
    if (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Введите корректный e-mail.';
    }
    if ($form['subject'] === '') {
        $errors[] = 'Укажите тему сообщения.';
    }
    if ($form['message'] === '') {
        $errors[] = 'Введите текст сообщения.';
    }

    if (!$errors) {
        $to = 'club@cyberarena.local';
        $mailSubject = 'Сообщение с сайта CyberArena: ' . $form['subject'];
        $mailBody = "Новое сообщение с формы контактов CyberArena\n\n"
            . "Имя: " . $form['name'] . "\n"
            . "E-mail: " . $form['email'] . "\n"
            . "Тема: " . $form['subject'] . "\n\n"
            . "Сообщение:\n" . $form['message'] . "\n";
        $headers = "From: no-reply@cyberarena.local\r\n"
            . "Reply-To: " . $form['email'] . "\r\n"
            . "Content-Type: text/plain; charset=UTF-8";

        $sent = @mail($to, $mailSubject, $mailBody, $headers);

        if ($sent) {
            set_flash('success', 'Сообщение отправлено на почту клуба.');
        } else {
            set_flash('info', 'Сообщение принято сайтом, но отправка письма зависит от настроек почты в Open Server Panel.');
        }

        header('Location: contacts.php');
        exit;
    }
}

$hideGlobalFlash = true;
require_once __DIR__ . '/header.php';
$contactFlash = get_flash();
?>

<section class="section">
    <div class="container contact-grid">
        <div class="contact-card">
            <h2>Контакты CyberArena</h2>
            <p class="note contact-intro">
                Ответим по бронированиям, свободным местам, зонам, тарифам и подскажем, какой формат игры подойдёт именно вам.
            </p>

            <div class="contact-list">
                <div class="small-box">
                    <span class="profile-label">Адрес клуба</span>
                    Санкт-Петербург, Невский проспект, 88
                </div>
                <div class="small-box">
                    <span class="profile-label">Телефон</span>
                    <a class="contact-link" href="tel:+78121234567">+7 (812) 123-45-67</a>
                </div>
                <div class="small-box">
                    <span class="profile-label">E-mail</span>
                    <a class="contact-link" href="mailto:club@cyberarena.local">club@cyberarena.local</a>
                </div>
                <div class="small-box">
                    <span class="profile-label">Режим работы</span>
                    Круглосуточно, без выходных
                </div>
            </div>

            <div class="contact-channels">
                <div class="contact-channel">
                    <span class="contact-channel-name">Telegram</span>
                    <span>@cyberarena_club</span>
                </div>
                <div class="contact-channel">
                    <span class="contact-channel-name">Discord</span>
                    <span>CyberArena Community</span>
                </div>
                <div class="contact-channel">
                    <span class="contact-channel-name">Быстрый ответ</span>
                    <span>обычно в течение 10–15 минут</span>
                </div>
            </div>
        </div>

        <div class="contact-card">
            <h2>Написать нам</h2>
            <p class="note contact-intro">Сообщение отправляется на почту клуба. В базу данных обычные сообщения не сохраняются.</p>

            <?php if ($contactFlash) { ?>
                <div class="flash contact-flash flash-<?= htmlspecialchars($contactFlash['type']) ?>">
                    <?= htmlspecialchars($contactFlash['message']) ?>
                </div>
            <?php } ?>

            <?php if ($errors) { ?>
                <ul class="error-list">
                    <?php foreach ($errors as $error) { ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <form method="post" class="contact-form">
                <div class="field">
                    <label for="name">Имя</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($form['name']) ?>" placeholder="Как к вам обращаться" required>
                </div>

                <div class="field">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($form['email']) ?>" placeholder="name@gmail.com" required>
                </div>

                <div class="field">
                    <label for="subject">Тема</label>
                    <input type="text" id="subject" name="subject" value="<?= htmlspecialchars($form['subject']) ?>" placeholder="Например, VIP-зона" required>
                </div>

                <div class="field">
                    <label for="message">Сообщение</label>
                    <textarea id="message" name="message" placeholder="Напишите, какая нужна зона, дата или вопрос по бронированию" required><?= htmlspecialchars($form['message']) ?></textarea>
                </div>

                <div class="auth-actions">
                    <button type="submit" class="btn btn-primary">Отправить</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/footer.php'; ?>
