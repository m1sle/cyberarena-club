<?php
require_once __DIR__ . '/admin_auth.php';

if (admin_is_logged_in()) {
    header('Location: admin.php');
    exit;
}

$error = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim((string) ($_POST['admin_login'] ?? ''));
    $password = (string) ($_POST['admin_password'] ?? '');

    if (admin_login_attempt($login, $password)) {
        header('Location: admin.php');
        exit;
    }

    $error = 'Неверный логин или пароль администратора.';
}
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход администратора</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #fff; color: #111; }
        .wrap { width: 420px; max-width: 94%; margin: 70px auto; border: 1px solid #111; padding: 24px; }
        h1 { margin: 0 0 16px; font-size: 26px; }
        p { margin: 0 0 18px; line-height: 1.45; }
        label { display: block; margin: 12px 0 6px; font-weight: bold; }
        input { width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #111; background: #fff; color: #111; font-size: 16px; }
        .btn { display: inline-block; margin-top: 18px; padding: 10px 18px; border: 1px solid #111; background: #111; color: #fff; font-weight: bold; cursor: pointer; }
        .error { border: 1px solid #111; padding: 10px; margin-bottom: 14px; background: #eee; }
        a { color: #111; }
    </style>
</head>
<body>
    <div class="wrap">
        <h1>Вход администратора</h1>
        <p>Вход в административную панель выполняется отдельно от клиентской авторизации.</p>

        <?php if ($error !== '') { ?>
            <div class="error"><?= htmlspecialchars($error, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
        <?php } ?>

        <form method="post">
            <label for="admin_login">Логин администратора</label>
            <input type="text" id="admin_login" name="admin_login" value="<?= htmlspecialchars($login, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" required>

            <label for="admin_password">Пароль администратора</label>
            <input type="password" id="admin_password" name="admin_password" required>

            <button class="btn" type="submit">Войти</button>
        </form>

        <p style="margin-top:18px;"><a href="index.php">Вернуться на сайт</a></p>
    </div>
</body>
</html>
