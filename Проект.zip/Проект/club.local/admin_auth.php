<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const CYBER_ADMIN_LOGIN = 'Admin';
const CYBER_ADMIN_PASSWORD = 'Admin123!';

function admin_is_logged_in(): bool
{
    return !empty($_SESSION['plain_admin_logged_in']);
}

function admin_login_attempt(string $login, string $password): bool
{
    if (hash_equals(CYBER_ADMIN_LOGIN, $login) && hash_equals(CYBER_ADMIN_PASSWORD, $password)) {
        $_SESSION['plain_admin_logged_in'] = true;
        $_SESSION['plain_admin_login'] = CYBER_ADMIN_LOGIN;
        $_SESSION['plain_admin_login_time'] = date('Y-m-d H:i:s');
        return true;
    }

    return false;
}

function admin_require_login(): void
{
    if (!admin_is_logged_in()) {
        header('Location: admin_login.php');
        exit;
    }
}

function admin_logout(): void
{
    unset($_SESSION['plain_admin_logged_in'], $_SESSION['plain_admin_login'], $_SESSION['plain_admin_login_time']);
}
