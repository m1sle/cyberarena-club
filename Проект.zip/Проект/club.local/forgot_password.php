<?php
require_once __DIR__ . '/bootstrap.php';

if (is_logged_in()) {
    header('Location: profile.php');
    exit;
}

$pageTitle = 'Восстановление доступа | CyberArena';
$errors = [];
$sent = false;

$form = [
    'login_or_email' => '',
    'phone' => '',
    'registered_at' => '',
    'message_text' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['login_or_email'] = raw_clean($_POST['login_or_email'] ?? '');
    $form['phone'] = raw_clean($_POST['phone'] ?? '');
    $form['registered_at'] = raw_clean($_POST['registered_at'] ?? '');
    $form['message_text'] = raw_clean($_POST['message_text'] ?? '');

    if ($form['login_or_email'] === '') {
        $errors[] = 'Укажите логин или e-mail аккаунта.';
    }

    $normalizedPhone = normalize_phone_ru($form['phone']);
    if ($normalizedPhone === false) {
        $errors[] = 'Введите корректный номер телефона.';
    }

    if (!is_valid_date($form['registered_at'])) {
        $errors[] = 'Укажите корректную дату регистрации.';
    }

    if (mb_strlen($form['message_text']) > 500) {
        $errors[] = 'Комментарий не должен превышать 500 символов.';
    }

    if (!$errors) {
        $matchedUserId = null;

        try {
            $stmtUser = mysqli_prepare($conn, 'SELECT id FROM users WHERE (login = ? OR email = ?) AND phone = ? AND registered_at = ? LIMIT 1');
            if (!$stmtUser) {
                logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
                throw new RuntimeException('Не удалось подготовить проверку аккаунта.');
            }

            if (!mysqli_stmt_bind_param($stmtUser, 'ssss', $form['login_or_email'], $form['login_or_email'], $normalizedPhone, $form['registered_at'])) {
                logMysqliStmtError($stmtUser, 'mysqli_stmt_error', '', __FILE__, __LINE__);
                mysqli_stmt_close($stmtUser);
                throw new RuntimeException('Не удалось обработать данные аккаунта.');
            }

            if (!mysqli_stmt_execute($stmtUser)) {
                logMysqliStmtError($stmtUser, 'mysqli_stmt_error', '', __FILE__, __LINE__);
                mysqli_stmt_close($stmtUser);
                throw new RuntimeException('Не удалось проверить данные аккаунта.');
            }

            $userResult = mysqli_stmt_get_result($stmtUser);
            if ($userResult === false) {
                logMysqliStmtError($stmtUser, 'mysqli_stmt_error', '', __FILE__, __LINE__);
                mysqli_stmt_close($stmtUser);
                throw new RuntimeException('Не удалось получить результат проверки аккаунта.');
            }

            $matchedUser = mysqli_fetch_assoc($userResult);
            mysqli_stmt_close($stmtUser);

            if ($matchedUser) {
                $matchedUserId = (int) $matchedUser['id'];
            }

            $stmtRequest = mysqli_prepare($conn, 'INSERT INTO password_reset_requests (user_id, login_or_email, phone, registered_at, message_text, status, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())');
            if (!$stmtRequest) {
                logMysqliError($conn, 'mysqli_error', '', __FILE__, __LINE__);
                throw new RuntimeException('Не удалось подготовить отправку заявки.');
            }

            $status = 'new';
            if (!mysqli_stmt_bind_param(
                $stmtRequest,
                'isssss',
                $matchedUserId,
                $form['login_or_email'],
                $normalizedPhone,
                $form['registered_at'],
                $form['message_text'],
                $status
            )) {
                logMysqliStmtError($stmtRequest, 'mysqli_stmt_error', '', __FILE__, __LINE__);
                mysqli_stmt_close($stmtRequest);
                throw new RuntimeException('Не удалось обработать заявку на восстановление.');
            }

            if (!mysqli_stmt_execute($stmtRequest)) {
                logMysqliStmtError($stmtRequest, 'mysqli_stmt_error', '', __FILE__, __LINE__);
                mysqli_stmt_close($stmtRequest);
                throw new RuntimeException('Не удалось отправить заявку на восстановление.');
            }
            mysqli_stmt_close($stmtRequest);

            $adminMail = 'club@cyberarena.local';
            $mailSubject = 'Заявка на восстановление доступа CyberArena';
            $mailBody = "Новая заявка на восстановление доступа\n\n"
                . "Логин или e-mail: " . $form['login_or_email'] . "\n"
                . "Телефон: " . $normalizedPhone . "\n"
                . "Дата регистрации: " . $form['registered_at'] . "\n"
                . "Совпадение с пользователем в БД: " . ($matchedUserId ? ('ID ' . $matchedUserId) : 'не найдено') . "\n\n"
                . "Комментарий клиента:\n" . ($form['message_text'] !== '' ? $form['message_text'] : '-') . "\n";
            $headers = "From: no-reply@cyberarena.local\r\n"
                . "Content-Type: text/plain; charset=UTF-8";
            @mail($adminMail, $mailSubject, $mailBody, $headers);

            $sent = true;
            $form = [
                'login_or_email' => '',
                'phone' => '',
                'registered_at' => '',
                'message_text' => '',
            ];
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<section class="section">
    <div class="container auth-shell">
        <div class="auth-card auth-card-modern forgot-card">
            <h1>Восстановление доступа</h1>
            <p class="note auth-lead">
                Заполните данные аккаунта. Заявка останется в админ-панели, а копия уйдёт на почту клуба.
            </p>

            <?php if ($sent) { ?>
                <div class="flash flash-success forgot-success">
                    Заявка отправлена. Она сохранена в админ-панели и дополнительно отправлена на почту клуба.
                </div>
            <?php } ?>

            <?php if ($errors) { ?>
                <ul class="error-list">
                    <?php foreach ($errors as $error) { ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <form method="post" class="auth-form-grid auth-form-register-clean" autocomplete="off">
                <div class="field">
                    <label for="login_or_email">Логин или e-mail</label>
                    <input type="text" id="login_or_email" name="login_or_email" value="<?= htmlspecialchars($form['login_or_email']) ?>" required>
                </div>

                <div class="field">
                    <label for="phone">Телефон аккаунта</label>
                    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($form['phone']) ?>" placeholder="+7 (999) 999-99-99" required>
                </div>

                <div class="field">
                    <label for="registered_at">Дата регистрации</label>
                    <input type="date" id="registered_at" name="registered_at" value="<?= htmlspecialchars($form['registered_at']) ?>" required>
                    <div class="helper-text">Дата, когда был создан аккаунт</div>
                </div>

                <div class="field field-full">
                    <label for="message_text">Комментарий</label>
                    <textarea id="message_text" name="message_text" rows="4" maxlength="500" placeholder="Например: хочу сменить пароль или не могу войти в аккаунт"><?= htmlspecialchars($form['message_text']) ?></textarea>
                </div>

                <div class="auth-actions field-full">
                    <button type="submit" class="btn btn-primary">Отправить заявку</button>
                    <a href="login.php" class="btn btn-secondary">Вернуться ко входу</a>
                </div>
            </form>
        </div>
    </div>
</section>

<script>
function formatPhoneValue(value) {
    let digits = value.replace(/\D/g, '');
    if (digits.startsWith('8')) digits = '7' + digits.slice(1);
    if (!digits.startsWith('7') && digits.length > 0) digits = '7' + digits;
    digits = digits.slice(0, 11);
    if (digits.length === 0) return '';

    let result = '+7';
    if (digits.length > 1) result += ' (' + digits.slice(1, 4);
    if (digits.length >= 4) result += ')';
    if (digits.length > 4) result += ' ' + digits.slice(4, 7);
    if (digits.length > 7) result += '-' + digits.slice(7, 9);
    if (digits.length > 9) result += '-' + digits.slice(9, 11);
    return result;
}

const phoneInput = document.getElementById('phone');
if (phoneInput) {
    phoneInput.addEventListener('input', function () {
        this.value = formatPhoneValue(this.value);
    });
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
