<?php
require_once __DIR__ . '/bootstrap.php';

clear_cart_items();
logout_user();
session_start();
set_flash('success', 'Вы вышли из аккаунта.');
header('Location: index.php');
exit;
