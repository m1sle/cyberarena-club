<?php
if (defined('ERROR_HANDLER_LOADED')) {
    return;
}
define('ERROR_HANDLER_LOADED', true);

/*
 * ЛР №5. Обработчики ошибок.
 * PHP-ошибки: userErrorHandler(), set_error_handler(), error_get_last().
 * Ошибки MySQL: стандартные функции mysqli_connect_error(), mysqli_connect_errno(),
 * mysqli_error(), mysqli_errno(), mysqli_sqlstate(), mysqli_stmt_error(),
 * mysqli_stmt_errno(), mysqli_stmt_sqlstate().
 */

define('ERROR_LOG_DIR', __DIR__ . '/logs');
define('PHP_ERROR_LOG_FILE', ERROR_LOG_DIR . '/error_log.xml');
define('MYSQL_ERROR_LOG_FILE', ERROR_LOG_DIR . '/mysql_error_log.xml');

/*
 * ПОЛЬЗОВАТЕЛЬСКИЕ/PHP-ОШИБКИ.
 */
function errorTypeLabel(int $errno): string
{
    $errorTypes = [
        E_ERROR => 'Фатальная ошибка PHP (E_ERROR)',
        E_WARNING => 'Предупреждение PHP (E_WARNING)',
        E_PARSE => 'Ошибка разбора кода PHP (E_PARSE)',
        E_NOTICE => 'Уведомление PHP (E_NOTICE)',
        E_CORE_ERROR => 'Фатальная ошибка ядра PHP (E_CORE_ERROR)',
        E_CORE_WARNING => 'Предупреждение ядра PHP (E_CORE_WARNING)',
        E_COMPILE_ERROR => 'Ошибка компиляции PHP (E_COMPILE_ERROR)',
        E_COMPILE_WARNING => 'Предупреждение компиляции PHP (E_COMPILE_WARNING)',
        E_USER_ERROR => 'Пользовательская критическая ошибка (E_USER_ERROR)',
        E_USER_WARNING => 'Пользовательское предупреждение (E_USER_WARNING)',
        E_USER_NOTICE => 'Пользовательское уведомление (E_USER_NOTICE)',
        E_STRICT => 'Предупреждение о строгих стандартах (E_STRICT)',
        E_RECOVERABLE_ERROR => 'Отлавливаемая фатальная ошибка (E_RECOVERABLE_ERROR)',
        E_DEPRECATED => 'Предупреждение об устаревшей функции (E_DEPRECATED)',
        E_USER_DEPRECATED => 'Пользовательское предупреждение об устаревании (E_USER_DEPRECATED)',
    ];

    return $errorTypes[$errno] ?? 'Неизвестная ошибка PHP';
}

function ensureLogDir(): void
{
    if (!is_dir(ERROR_LOG_DIR)) {
        mkdir(ERROR_LOG_DIR, 0777, true);
    }
}

function xmlText(string $value): string
{
    return htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}

function makeEmptyXml(string $rootName): string
{
    return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<" . $rootName . ">\n</" . $rootName . ">\n";
}

function createXmlLogFile(string $file, string $rootName): void
{
    ensureLogDir();
    saveXmlFile($file, makeEmptyXml($rootName));
}

function ensurePhpErrorLogFile(): void
{
    if (!file_exists(PHP_ERROR_LOG_FILE) || trim((string) @file_get_contents(PHP_ERROR_LOG_FILE)) === '') {
        createXmlLogFile(PHP_ERROR_LOG_FILE, 'errorlog');
    }
}

function ensureMysqlErrorLogFile(): void
{
    if (!file_exists(MYSQL_ERROR_LOG_FILE) || trim((string) @file_get_contents(MYSQL_ERROR_LOG_FILE)) === '') {
        createXmlLogFile(MYSQL_ERROR_LOG_FILE, 'mysqllog');
    }
}

/*
 * Простая запись XML-журнала сразу в основной файл.
 * Временные файлы и .lock-файлы не используются: журнал сразу сохраняется
 * в logs/error_log.xml или logs/mysql_error_log.xml.
 */
function saveXmlFile(string $file, string $xml): void
{
    ensureLogDir();
    @file_put_contents($file, $xml, LOCK_EX);
}

/*
 * Общая функция добавления записи в XML-журнал.
 * Она читает текущий XML, добавляет новую запись и сразу сохраняет журнал
 * в основной XML-файл без временных .tmp и .lock-файлов.
 */
function appendXmlEntry(string $file, string $rootName, string $entryName, array $fields): void
{
    ensureLogDir();

    $oldXml = '';
    if (file_exists($file)) {
        $oldXml = (string) @file_get_contents($file);
    }

    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->formatOutput = true;
    $dom->preserveWhiteSpace = false;

    if (trim($oldXml) === '' || !@$dom->loadXML($oldXml)) {
        $dom->appendChild($dom->createElement($rootName));
    }

    if (!$dom->documentElement || $dom->documentElement->tagName !== $rootName) {
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->formatOutput = true;
        $dom->appendChild($dom->createElement($rootName));
    }

    $entry = $dom->createElement($entryName);

    foreach ($fields as $name => $value) {
        $node = $dom->createElement((string) $name);
        $node->appendChild($dom->createTextNode((string) $value));
        $entry->appendChild($node);
    }

    $dom->documentElement->appendChild($entry);
    saveXmlFile($file, (string) $dom->saveXML());
}

/*
 * Запись пользовательской/PHP-ошибки в logs/error_log.xml.
 */
function appendPhpErrorEntry(array $error): void
{
    ensurePhpErrorLogFile();

    appendXmlEntry(PHP_ERROR_LOG_FILE, 'errorlog', 'errorentry', [
        'datetime' => $error['datetime'] ?? '',
        'errornum' => $error['errornum'] ?? '',
        'errortype' => $error['errortype'] ?? '',
        'errormsg' => $error['errormsg'] ?? '',
        'scriptname' => $error['scriptname'] ?? '',
        'scriptlinenum' => $error['scriptlinenum'] ?? '',
    ]);
}

/*
 * Формирование массива пользовательской/PHP-ошибки.
 * Этот массив потом записывается в logs/error_log.xml.
 */
function logPhpError(int $errno, string $errmsg, string $filename, int $linenum): void
{
    $error = [
        'datetime' => date('Y-m-d H:i:s T'),
        'errornum' => $errno,
        'errortype' => errorTypeLabel($errno),
        'errormsg' => $errmsg,
        'scriptname' => $filename,
        'scriptlinenum' => $linenum,
    ];

    appendPhpErrorEntry($error);
}

function appendMysqlErrorEntry(array $mysqlError): void
{
    ensureMysqlErrorLogFile();

    appendXmlEntry(MYSQL_ERROR_LOG_FILE, 'mysqllog', 'mysqlerror', [
        'datetime' => $mysqlError['datetime'] ?? '',
        'function' => $mysqlError['function'] ?? '',
        'sql' => $mysqlError['sql'] ?? '',
        'errno' => $mysqlError['errno'] ?? '',
        'sqlstate' => $mysqlError['sqlstate'] ?? '',
        'message' => $mysqlError['message'] ?? '',
        'scriptname' => $mysqlError['scriptname'] ?? '',
        'scriptlinenum' => $mysqlError['scriptlinenum'] ?? '',
    ]);
}

/*
 * РЕАЛЬНАЯ ОШИБКА MYSQL/MYSQLI.
 * Мы НЕ придумываем текст ошибки сами.
 * В журнал сохраняются данные, которые вернули стандартные функции MySQLi:
 * errno, sqlstate и message. Поле sql — это только запрос, который мы пытались выполнить.
 */
function logMysqlError(string $function, string $sql, int $errno, string $sqlstate, string $message, string $filename, int $linenum): void
{
    $mysqlError = [
        'datetime' => date('Y-m-d H:i:s T'),
        'function' => $function,
        'sql' => $sql,
        'errno' => $errno,
        'sqlstate' => $sqlstate,
        'message' => $message,
        'scriptname' => $filename,
        'scriptlinenum' => $linenum,
    ];

    appendMysqlErrorEntry($mysqlError);
}

/*
 * БЛОК РЕАЛЬНЫХ ОШИБОК MYSQL.
 * Здесь НЕ используется trigger_error() и E_USER_WARNING.
 * Ошибка берётся из стандартных функций MySQLi.
 */
function logMysqliConnectionError(string $filename, int $linenum): void
{
    logMysqlError(
        'mysqli_connect',
        '',
        mysqli_connect_errno(),
        '',
        mysqli_connect_error(),
        $filename,
        $linenum
    );
}

function logMysqliError(mysqli $conn, string $function, string $sql, string $filename, int $linenum): void
{
    logMysqlError(
        $function,
        $sql,
        mysqli_errno($conn),
        mysqli_sqlstate($conn),
        mysqli_error($conn),
        $filename,
        $linenum
    );
}

function logMysqliStmtError(mysqli_stmt $stmt, string $function, string $sql, string $filename, int $linenum): void
{
    logMysqlError(
        $function,
        $sql,
        mysqli_stmt_errno($stmt),
        mysqli_stmt_sqlstate($stmt),
        mysqli_stmt_error($stmt),
        $filename,
        $linenum
    );
}

function showSystemError(): void
{
    if (!headers_sent()) {
        http_response_code(500);
    }

    echo '<!doctype html><html lang="ru"><head><meta charset="UTF-8"><title>Ошибка системы</title>';
    echo '<style>body{margin:0;font-family:Arial,sans-serif;background:#050b1f;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px}';
    echo '.box{max-width:640px;width:100%;background:linear-gradient(180deg,#16203f,#0b1430);border:1px solid rgba(255,255,255,.09);border-radius:24px;padding:32px;box-shadow:0 20px 40px rgba(0,0,0,.35)}';
    echo 'h1{margin:0 0 14px;font-size:34px}p{margin:0 0 12px;font-size:18px;line-height:1.55;color:#cfd6f8}</style></head><body>';
    echo '<div class="box"><h1>Произошла ошибка</h1><p>Система временно не может обработать запрос. Попробуйте обновить страницу или повторите действие позже.</p><p>Подробности сохранены во внутреннем журнале ошибок.</p></div></body></html>';
    exit;
}

/*
 * ГЛАВНЫЙ ПОЛЬЗОВАТЕЛЬСКИЙ ОБРАБОТЧИК ОШИБОК.
 * Сюда попадают PHP-ошибки и пользовательские ошибки из trigger_error().
 * Результат записывается в logs/error_log.xml.
 */
function userErrorHandler(int $errno, string $errstr, string $errfile, int $errline): bool
{
    logPhpError($errno, $errstr, $errfile, $errline);
    return true;
}

function exceptionHandler(Throwable $exception): void
{
    logPhpError(E_USER_ERROR, $exception->getMessage(), $exception->getFile(), $exception->getLine());
    showSystemError();
}

function shutdownHandler(): void
{
    $error = error_get_last();
    if (!$error) {
        return;
    }

    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR];
    if (in_array($error['type'], $fatalTypes, true)) {
        logPhpError((int) $error['type'], (string) $error['message'], (string) $error['file'], (int) $error['line']);
        showSystemError();
    }
}

function registerErrorHandler(): void
{
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '0');

    set_error_handler('userErrorHandler', E_ALL);
    set_exception_handler('exceptionHandler');
    register_shutdown_function('shutdownHandler');
}
