-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 02 2026 г., 14:59
-- Версия сервера: 5.7.39-log
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `computer_club`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `computer_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time NOT NULL DEFAULT '12:00:00',
  `hours` decimal(5,2) NOT NULL,
  `price_per_hour_snapshot` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `computer_id`, `booking_date`, `booking_time`, `hours`, `price_per_hour_snapshot`) VALUES
(8, 11, 3, '2026-04-23', '12:00:00', '2.00', '150.00'),
(9, 11, 2, '2026-04-23', '14:00:00', '2.00', '200.00'),
(10, 11, 2, '2026-04-30', '12:00:00', '2.00', '200.00'),
(14, 13, 3, '2026-04-23', '16:00:00', '2.00', '150.00'),
(15, 13, 3, '2026-04-23', '18:00:00', '2.00', '150.00'),
(16, 15, 2, '2026-06-02', '01:15:00', '2.00', '200.00'),
(17, 15, 1, '2026-06-02', '12:00:00', '2.00', '120.00');

-- --------------------------------------------------------

--
-- Структура таблицы `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time NOT NULL DEFAULT '12:00:00',
  `hours` decimal(5,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `clubs`
--

CREATE TABLE `clubs` (
  `id` int(11) NOT NULL,
  `club_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `clubs`
--

INSERT INTO `clubs` (`id`, `club_name`, `address`) VALUES
(1, 'Cyber Arena Nevsky', 'Санкт-Петербург, Невский проспект, 25'),
(2, 'Cyber Arena Moskovsky', 'Санкт-Петербург, Московский проспект, 18');

-- --------------------------------------------------------

--
-- Структура таблицы `computers`
--

CREATE TABLE `computers` (
  `id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `tariff_id` int(11) NOT NULL,
  `pc_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpu` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gpu` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ram` int(11) NOT NULL,
  `monitor_hz` int(11) DEFAULT NULL,
  `monitor_model` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keyboard_model` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mouse_model` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headset_model` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chair_model` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_year` int(11) NOT NULL,
  `photo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noimage.jpg',
  `is_vip` tinyint(1) NOT NULL DEFAULT '0',
  `is_maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `computers`
--

INSERT INTO `computers` (`id`, `zone_id`, `tariff_id`, `pc_name`, `short_description`, `cpu`, `gpu`, `ram`, `monitor_hz`, `monitor_model`, `keyboard_model`, `mouse_model`, `headset_model`, `chair_model`, `release_year`, `photo`, `is_vip`, `is_maintenance`, `is_active`) VALUES
(1, 1, 1, 'Arena Base #01', 'Сбалансированное место для быстрых матчей и вечерних игровых сессий.', 'Intel Core i5-12400F', 'RTX 3060', 16, 165, 'ASUS TUF VG249Q1A 24\" 165Hz', 'HyperX Alloy Origins', 'Logitech G403 HERO', 'HyperX Cloud III', 'DXRacer Formula', 2023, 'pc1.jpg', 0, 0, 1),
(2, 2, 3, 'VIP Phantom #02', 'VIP-место с быстрым монитором, мощной видеокартой и премиальной периферией.', 'Intel Core i7-13700K', 'RTX 4070', 32, 500, 'Acer XV252Q 24.5\" 500Hz', 'Wooting 60HE+', 'Lamzu Maya X Super Light 8K', 'Logitech G Pro X', 'BRAVE', 2024, 'pc2.jpg', 1, 0, 1),
(3, 3, 4, 'Bootcamp Pro #01', 'Место для тренировок, командной подготовки и турниров.', 'AMD Ryzen 7 7700X', 'RTX 4060 Ti', 32, 300, 'Acer XV272U 27\" 300Hz', 'Dark Project KD87A', 'Lamzu Maya X Super Light 8K', 'Logitech G Pro X', 'BRAVE', 2024, 'pc3.jpg', 0, 0, 1),
(4, 2, 3, 'VIP Titan #01', 'Премиум-выбор для длинных игровых сессий, компании друзей и максимального комфорта.', 'Intel Core i9-14900K', 'RTX 4080', 64, 500, 'Acer XV252Q 24.5\" 500Hz', 'Wooting 60HE+', 'Lamzu Maya X Super Light 8K', 'Logitech G Pro X', 'BRAVE', 2025, 'pc4.jpg', 1, 0, 1),
(5, 1, 2, 'Arena Base #02', 'Ночной тариф для спокойной игры, тренировок и длительных сессий.', 'AMD Ryzen 5 5600', 'RTX 3050', 16, 165, 'AOC 24G2SPAE 24\" 165Hz', 'Dark Project KD87A', 'Logitech G Pro X Superlight', 'HyperX Cloud Alpha', 'Cougar Armor One', 2022, 'pc5.jpg', 0, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `password_reset_requests`
--

CREATE TABLE `password_reset_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `login_or_email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registered_at` date NOT NULL,
  `message_text` text COLLATE utf8mb4_unicode_ci,
  `status` enum('new','processed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL,
  `processed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `site_stats`
--

CREATE TABLE `site_stats` (
  `id` tinyint(4) NOT NULL,
  `visit_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `site_stats`
--

INSERT INTO `site_stats` (`id`, `visit_count`) VALUES
(1, 56);

-- --------------------------------------------------------

--
-- Структура таблицы `tariffs`
--

CREATE TABLE `tariffs` (
  `id` int(11) NOT NULL,
  `tariff_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_per_hour` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tariffs`
--

INSERT INTO `tariffs` (`id`, `tariff_name`, `price_per_hour`) VALUES
(1, 'Day Start', '120.00'),
(2, 'Night Session', '90.00'),
(3, 'Premium Night', '200.00'),
(4, 'Tournament Pass', '150.00');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registered_at` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('client','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'client',
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `full_name`, `phone`, `login`, `email`, `password_hash`, `registered_at`, `created_at`, `role`, `is_super_admin`, `last_login_at`) VALUES
(11, 'Максим Захаров', '+7 (435) 345-24-58', 'qqqqq1', 'maksimzaharov10@yandex.ru', '$2y$10$KCpvgaaNfYTA1kMZrffB.OmqNGqXNday6HwHRF2pJ2oDJ7vpaVCvq', '2026-04-23', '2026-04-23 17:51:42', 'client', 0, NULL),
(13, 'Максим Захаров', '+7 (777) 777-77-77', '7777', '7777777@yandex.ru', '$2y$10$ITl1BDPJ22X31980nch83OEfwOnLhKpkIPg8oCfNX94Z2Zc52Cx6C', '2026-04-23', '2026-04-23 19:08:31', 'admin', 0, '2026-04-26 17:33:52'),
(14, 'Администратор CyberArena', '+7 (000) 000-00-00', 'Admin', 'admin@yandex.ru', '$2y$12$3csNDzhKtl5DkgQx3zcEeuF3zSlCILsqI9/tyIm0iNZbt1cz0HGo2', '2026-04-24', '2026-04-24 19:22:55', 'admin', 1, '2026-04-30 14:05:34'),
(15, 'Максим Захаров', '+7 (235) 123-45-43', 'qqqq', '324341@yandex.ru', '$2y$10$/ccv//K0oAc.2I9MttI8juIJZpoFQEGfKKjT5juESFMK4SQC/98bG', '2026-06-02', '2026-06-02 10:53:55', 'client', 0, '2026-06-02 13:53:58');

-- --------------------------------------------------------

--
-- Структура таблицы `zones`
--

CREATE TABLE `zones` (
  `id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `zone_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `zones`
--

INSERT INTO `zones` (`id`, `club_id`, `zone_name`) VALUES
(1, 1, 'Standard Arena'),
(2, 1, 'VIP Arena'),
(3, 2, 'Bootcamp Zone');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_bookings_computer` (`computer_id`),
  ADD KEY `idx_bookings_user_id` (`user_id`),
  ADD KEY `idx_bookings_date_time` (`booking_date`,`booking_time`);

--
-- Индексы таблицы `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cart_items_cart_id` (`cart_id`),
  ADD KEY `idx_cart_items_user_id` (`user_id`);

--
-- Индексы таблицы `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `computers`
--
ALTER TABLE `computers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_computers_zone` (`zone_id`),
  ADD KEY `fk_computers_tariff` (`tariff_id`),
  ADD KEY `idx_computers_maintenance` (`is_maintenance`),
  ADD KEY `idx_computers_active` (`is_active`);

--
-- Индексы таблицы `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_reset_requests`
--
ALTER TABLE `password_reset_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_password_reset_user_id` (`user_id`),
  ADD KEY `idx_password_reset_status` (`status`);

--
-- Индексы таблицы `site_stats`
--
ALTER TABLE `site_stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tariffs`
--
ALTER TABLE `tariffs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uq_users_phone` (`phone`),
  ADD KEY `idx_users_role` (`role`);

--
-- Индексы таблицы `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_zones_club` (`club_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `clubs`
--
ALTER TABLE `clubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `computers`
--
ALTER TABLE `computers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `password_reset_requests`
--
ALTER TABLE `password_reset_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `tariffs`
--
ALTER TABLE `tariffs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `zones`
--
ALTER TABLE `zones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_bookings_computer` FOREIGN KEY (`computer_id`) REFERENCES `computers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cart_items_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `computers`
--
ALTER TABLE `computers`
  ADD CONSTRAINT `fk_computers_tariff` FOREIGN KEY (`tariff_id`) REFERENCES `tariffs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_computers_zone` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `password_reset_requests`
--
ALTER TABLE `password_reset_requests`
  ADD CONSTRAINT `fk_password_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `zones`
--
ALTER TABLE `zones`
  ADD CONSTRAINT `fk_zones_club` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
